'use strict';

/* ════════════════════════════════════════════════
   PAGE META
════════════════════════════════════════════════ */
var PAGE_META = {
  'dashboard':         { title: 'Dashboard',        subtitle: 'Club overview' },
  'club-details':      { title: 'Club Details',      subtitle: 'Manage your club information' },
  'assign-secretary':  { title: 'Assign Secretary',  subtitle: 'Manage club secretary roles' },
  'members':           { title: 'Members',            subtitle: 'View and manage club members' },
  'announcements':     { title: 'Announcements',      subtitle: 'Post and manage announcements' },
  'attendance':        { title: 'Attendance',         subtitle: 'Track member attendance' },
  'enrollment-key':    { title: 'Enrollment Key',     subtitle: 'Manage club enrollment keys' },
  'upload-reports':    { title: 'Upload Reports',     subtitle: 'Submit club reports' },
  'upload-workplan':   { title: 'Upload Work Plan',   subtitle: 'Submit club work plans' },
  'upload-image':      { title: 'Upload Image',       subtitle: 'Upload club images' },
  'upload-vlog':       { title: 'Upload Vlog',        subtitle: 'Upload club video logs' }
};

document.addEventListener('DOMContentLoaded', function () {

  /* ── Elements ── */
  var sidebar        = document.getElementById('sidebar');
  var sidebarOverlay = document.getElementById('sidebar-overlay');
  var hamburgerBtn   = document.getElementById('hamburger-btn');
  var topbarTitle    = document.getElementById('topbar-title');
  var topbarSubtitle = document.getElementById('topbar-subtitle');
  var notifBadge     = document.getElementById('notif-badge');
  var navItems       = document.querySelectorAll('.nav-item');

  /* ════════════════════════════════════════════════
     SIDEBAR OPEN / CLOSE
  ════════════════════════════════════════════════ */
  function openSidebar() {
    sidebar.classList.add('open');
    sidebarOverlay.style.display = 'block';
    setTimeout(function () { sidebarOverlay.classList.add('active'); }, 10);
    document.body.style.overflow = 'hidden';
  }

  function closeSidebar() {
    sidebar.classList.remove('open');
    sidebarOverlay.classList.remove('active');
    setTimeout(function () { sidebarOverlay.style.display = 'none'; }, 280);
    document.body.style.overflow = '';
  }

  if (hamburgerBtn) {
    hamburgerBtn.addEventListener('click', function () {
      sidebar.classList.contains('open') ? closeSidebar() : openSidebar();
    });
  }
  if (sidebarOverlay) sidebarOverlay.addEventListener('click', closeSidebar);

  /* ════════════════════════════════════════════════
     NAV ITEM CLICK → topbar update
  ════════════════════════════════════════════════ */
  navItems.forEach(function (item) {
    item.addEventListener('click', function (e) {
      var page = item.dataset.page;
      if (page !== 'upload-reports') return;
      e.preventDefault();
      navItems.forEach(function (n) { n.classList.remove('active'); });
      item.classList.add('active');
      var m = PAGE_META[page] || PAGE_META['upload-reports'];
      if (topbarTitle)    topbarTitle.textContent    = m.title;
      if (topbarSubtitle) topbarSubtitle.textContent = m.subtitle;
      if (window.innerWidth <= 768) closeSidebar();
    });
  });

  if (notifBadge) notifBadge.style.display = 'block';

  /* ════════════════════════════════════════════════
     DRAG & DROP / FILE INPUT
  ════════════════════════════════════════════════ */
  var dropZone        = document.getElementById('drop-zone');
  var fileInput       = document.getElementById('file-input');
  var filePreviewRow  = document.getElementById('file-preview-row');
  var filePreviewIcon = document.getElementById('file-preview-icon');
  var filePreviewName = document.getElementById('file-preview-name');
  var filePreviewSize = document.getElementById('file-preview-size');
  var fileRemoveBtn   = document.getElementById('file-remove-btn');
  var sendToRow       = document.getElementById('send-to-row');
  var sendToSelect    = document.getElementById('send-to');
  var sendToHint      = document.getElementById('send-to-hint');
  var sendToWrap      = document.getElementById('send-to-wrap');
  var reportType      = document.getElementById('report-type');
  var auditNotice     = document.getElementById('audit-notice');
  var selectedFile    = null;

  var SEND_TO_HINTS = {
    dsa : 'Submitted officially to DSA office for review',
    me  : 'Saved privately — only visible to you'
  };

  /* ── Check if current report type is Audit ── */
  function isAuditTypeSelected() {
    return reportType && reportType.value === 'Audit Report';
  }

  /* ── Apply / remove audit lock on Send To ── */
  function applySendToLock() {
    if (!sendToRow) return;
    if (isAuditTypeSelected()) {
      if (sendToSelect) {
        sendToSelect.disabled = true;
        sendToSelect.value    = 'dsa';
      }
      if (sendToWrap)  sendToWrap.classList.add('send-to-locked');
      if (sendToHint)  sendToHint.textContent = 'Audit Reports cannot be forwarded or sent to DSA.';
      if (auditNotice) auditNotice.classList.add('show');
    } else {
      if (sendToSelect) {
        sendToSelect.disabled = false;
      }
      if (sendToWrap)  sendToWrap.classList.remove('send-to-locked');
      if (sendToHint)  sendToHint.textContent = SEND_TO_HINTS[sendToSelect ? sendToSelect.value : 'dsa'] || '';
      if (auditNotice) auditNotice.classList.remove('show');
    }
  }

  if (reportType) {
    reportType.addEventListener('change', function () {
      applySendToLock();
    });
  }

  /* ── Drop zone events ── */
  if (dropZone) {
    dropZone.addEventListener('click', function () { fileInput && fileInput.click(); });
    dropZone.addEventListener('keydown', function (e) {
      if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); fileInput && fileInput.click(); }
    });
    dropZone.addEventListener('dragover', function (e) {
      e.preventDefault();
      dropZone.classList.add('dragover');
    });
    dropZone.addEventListener('dragleave', function () { dropZone.classList.remove('dragover'); });
    dropZone.addEventListener('drop', function (e) {
      e.preventDefault();
      dropZone.classList.remove('dragover');
      var files = e.dataTransfer.files;
      if (files && files.length > 0) handleFile(files[0]);
    });
  }

  if (fileInput) {
    fileInput.addEventListener('change', function () {
      if (fileInput.files && fileInput.files.length > 0) handleFile(fileInput.files[0]);
    });
  }

  function formatSize(bytes) {
    if (bytes === 0) return '0.0 MB';
    var mb = bytes / (1024 * 1024);
    return mb < 0.1 ? (bytes / 1024).toFixed(1) + ' KB' : mb.toFixed(1) + ' MB';
  }

  function handleFile(file) {
    var allowed = [
      'application/pdf',
      'application/msword',
      'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
      'application/vnd.ms-excel',
      'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
    ];
    if (allowed.indexOf(file.type) === -1) { alert('Only PDF, Word, or Excel files are allowed.'); return; }
    if (file.size > 30 * 1024 * 1024)      { alert('File size exceeds 30MB limit.'); return; }

    selectedFile = file;

    var iconClass = 'doc-icon';
    if (file.type === 'application/pdf') iconClass = 'pdf-icon';
    else if (file.type.indexOf('excel') !== -1 || file.type.indexOf('sheet') !== -1) iconClass = 'xls-icon';

    if (filePreviewIcon) filePreviewIcon.className = 'file-preview-icon ' + iconClass;
    if (filePreviewName) filePreviewName.textContent = file.name;
    if (filePreviewSize) filePreviewSize.textContent = formatSize(file.size);

    if (dropZone)       dropZone.style.display = 'none';
    if (filePreviewRow) filePreviewRow.classList.add('show');
    if (sendToRow)      sendToRow.classList.add('show');

    applySendToLock();
  }

  if (sendToSelect) {
    sendToSelect.addEventListener('change', function () {
      if (!isAuditTypeSelected() && sendToHint) {
        sendToHint.textContent = SEND_TO_HINTS[sendToSelect.value] || '';
      }
    });
  }

  if (fileRemoveBtn) {
    fileRemoveBtn.addEventListener('click', function () {
      selectedFile = null;
      if (fileInput)      fileInput.value = '';
      if (filePreviewRow) filePreviewRow.classList.remove('show');
      if (sendToRow)      sendToRow.classList.remove('show');
      if (dropZone)       dropZone.style.display = '';
    });
  }

  /* ════════════════════════════════════════════════
     UPLOAD REPORT BUTTON
  ════════════════════════════════════════════════ */
  var uploadBtn    = document.getElementById('upload-btn');
  var reportTitle  = document.getElementById('report-title');
  var successToast = document.getElementById('success-toast');

  if (uploadBtn) {
    uploadBtn.addEventListener('click', function () {
      var title   = reportTitle   ? reportTitle.value.trim() : '';
      var type    = reportType    ? reportType.value         : '';
      var sentTo  = sendToSelect  ? sendToSelect.value       : 'me';
      var isAudit = (type === 'Audit Report');

      if (!selectedFile) { alert('Please select a file to upload.'); return; }
      if (!title)        { alert('Please enter a report title.'); reportTitle && reportTitle.focus(); return; }
      if (!type)         { alert('Please select a report type.'); return; }

      var ext = 'PDF';
      if (selectedFile.type.indexOf('word') !== -1 || selectedFile.type.indexOf('document') !== -1) ext = 'DOC';
      if (selectedFile.type.indexOf('excel') !== -1 || selectedFile.type.indexOf('sheet') !== -1)   ext = 'XLS';
      var iconClass = ext === 'PDF' ? 'pdf' : (ext === 'DOC' ? 'doc' : 'xls');

      var today   = new Date();
      var months  = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
      var dateStr = months[today.getMonth()] + ' ' + today.getDate() + ', ' + today.getFullYear();

      /*
       * FORWARD BUTTON LOGIC:
       * — Audit reports: no Forward button at all (shown as "—")
       * — sentTo === 'dsa': report is already going to DSA, Forward button is FROZEN (forwarded=true)
       * — sentTo === 'me':  report is private, Forward button is ACTIVE so user can forward later
       */
      var isForwarded = !isAudit && (sentTo === 'dsa');

      addReportRow({
        iconClass : iconClass,
        ext       : ext,
        name      : title,
        fname     : selectedFile.name,
        type      : type,
        date      : dateStr,
        sentTo    : isAudit ? null : sentTo,
        forwarded : isForwarded,
        isAudit   : isAudit
      });

      /* Reset form */
      selectedFile = null;
      if (fileInput)      fileInput.value = '';
      if (filePreviewRow) filePreviewRow.classList.remove('show');
      if (sendToRow)      sendToRow.classList.remove('show');
      if (dropZone)       dropZone.style.display = '';
      if (reportTitle)    reportTitle.value = '';
      if (reportType)     reportType.value  = '';
      if (sendToSelect) {
        sendToSelect.disabled = false;
        sendToSelect.value    = 'dsa';
      }
      if (sendToWrap)  sendToWrap.classList.remove('send-to-locked');
      if (sendToHint)  sendToHint.textContent = SEND_TO_HINTS['dsa'];
      if (auditNotice) auditNotice.classList.remove('show');

      if (successToast) {
        successToast.classList.add('show');
        setTimeout(function () { successToast.classList.remove('show'); }, 3500);
      }
      switchTab('all');
    });
  }

  /* ════════════════════════════════════════════════
     TABS
  ════════════════════════════════════════════════ */
  var tabBtns    = document.querySelectorAll('.tab-btn');
  var currentTab = 'all';

  tabBtns.forEach(function (btn) {
    btn.addEventListener('click', function () { switchTab(btn.dataset.tab); });
  });

  function switchTab(tab) {
    currentTab = tab;
    tabBtns.forEach(function (b) { b.classList.toggle('active', b.dataset.tab === tab); });
    filterRows(tab);
    updateForwardButtons(tab);
  }

  function filterRows(tab) {
    var rows = document.querySelectorAll('#reports-tbody tr');
    var any  = false;
    rows.forEach(function (row) {
      var show = false;
      if (tab === 'all') {
        show = true;
      } else if (tab === 'me') {
        /* "Only Me" tab: reports sent to me only (not forwarded, not DSA) */
        show = row.dataset.sentTo === 'me' && row.dataset.forwarded !== 'true';
      } else if (tab === 'dsa') {
        /* "Submitted to DSA" tab: reports sent to dsa OR forwarded */
        show = row.dataset.sentTo === 'dsa' || row.dataset.forwarded === 'true';
      } else if (tab === 'secretary') {
        /* Secretary-uploaded reports — flagged via data-uploaded-by="secretary" */
        show = row.dataset.uploadedBy === 'secretary';
      } else if (tab === 'audit') {
        /* NEW: Audit Report tab — filter by report type */
        show = row.dataset.isAudit === 'true';
      }
      row.style.display = show ? '' : 'none';
      if (show) any = true;
    });
    toggleEmptyState(!any);
  }

  function updateForwardButtons(tab) {
    var rows = document.querySelectorAll('#reports-tbody tr');
    rows.forEach(function (row) {
      var btn = row.querySelector('.forward-btn');
      if (!btn) return;
      var alreadyForwarded = row.dataset.forwarded === 'true';
      if (tab === 'dsa') {
        btn.disabled = true;
        btn.classList.add('forwarded');
        btn.innerHTML = forwardedHTML();
      } else {
        if (alreadyForwarded) {
          btn.disabled = true;
          btn.classList.add('forwarded');
          btn.innerHTML = forwardedHTML();
        } else {
          btn.disabled = false;
          btn.classList.remove('forwarded');
          btn.innerHTML = forwardActiveHTML();
        }
      }
    });
  }

  function forwardedHTML() {
    return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="15 17 20 12 15 7"/><path d="M4 18v-2a4 4 0 0 1 4-4h12"/></svg><span>Forwarded</span>';
  }
  function forwardActiveHTML() {
    return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="15 17 20 12 15 7"/><path d="M4 18v-2a4 4 0 0 1 4-4h12"/></svg><span>Forward</span>';
  }

  function toggleEmptyState(show) {
    var empty = document.getElementById('empty-state');
    if (empty) empty.style.display = show ? '' : 'none';
  }

  /* ════════════════════════════════════════════════
     FORWARD CONFIRMATION MODAL
  ════════════════════════════════════════════════ */
  var forwardModal      = document.getElementById('forward-modal');
  var modalReportName   = document.getElementById('modal-report-name');
  var modalCancel       = document.getElementById('modal-cancel');
  var modalConfirm      = document.getElementById('modal-confirm');
  var pendingForwardRow = null;

  function openForwardModal(row, reportName) {
    pendingForwardRow = row;
    if (modalReportName) modalReportName.textContent = '"' + reportName + '"';
    if (forwardModal) { forwardModal.classList.add('active'); document.body.style.overflow = 'hidden'; }
  }
  function closeForwardModal() {
    if (forwardModal) { forwardModal.classList.remove('active'); document.body.style.overflow = ''; }
    pendingForwardRow = null;
  }

  if (modalCancel) modalCancel.addEventListener('click', closeForwardModal);
  if (forwardModal) {
    forwardModal.addEventListener('click', function (e) { if (e.target === forwardModal) closeForwardModal(); });
  }
  if (modalConfirm) {
    modalConfirm.addEventListener('click', function () {
      if (!pendingForwardRow) { closeForwardModal(); return; }
      pendingForwardRow.dataset.forwarded = 'true';
      pendingForwardRow.dataset.sentTo    = 'dsa';

      var badgeCell = pendingForwardRow.querySelector('td:nth-child(3)');
      if (badgeCell) badgeCell.innerHTML = '<span class="badge badge-dsa">DSA</span>';

      var btn = pendingForwardRow.querySelector('.forward-btn');
      if (btn) { btn.disabled = true; btn.classList.add('forwarded'); btn.innerHTML = forwardedHTML(); }

      closeForwardModal();
      filterRows(currentTab);
      updateForwardButtons(currentTab);
    });
  }

  /* ════════════════════════════════════════════════
     DELETE CONFIRMATION MODAL
  ════════════════════════════════════════════════ */
  var deleteModal      = document.getElementById('delete-modal');
  var deleteReportName = document.getElementById('delete-report-name');
  var deleteCancel     = document.getElementById('delete-cancel');
  var deleteConfirm    = document.getElementById('delete-confirm');
  var pendingDeleteRow = null;

  function openDeleteModal(row, reportName) {
    pendingDeleteRow = row;
    if (deleteReportName) deleteReportName.textContent = '"' + reportName + '"';
    if (deleteModal) { deleteModal.classList.add('active'); document.body.style.overflow = 'hidden'; }
  }
  function closeDeleteModal() {
    if (deleteModal) { deleteModal.classList.remove('active'); document.body.style.overflow = ''; }
    pendingDeleteRow = null;
  }

  if (deleteCancel) deleteCancel.addEventListener('click', closeDeleteModal);
  if (deleteModal) {
    deleteModal.addEventListener('click', function (e) { if (e.target === deleteModal) closeDeleteModal(); });
  }
  if (deleteConfirm) {
    deleteConfirm.addEventListener('click', function () {
      if (!pendingDeleteRow) { closeDeleteModal(); return; }
      pendingDeleteRow.remove();
      closeDeleteModal();
      filterRows(currentTab);
    });
  }

  /* ════════════════════════════════════════════════
     VIEW REPORT MODAL
  ════════════════════════════════════════════════ */
  var viewModal      = document.getElementById('view-modal');
  var viewFileIcon   = document.getElementById('view-file-icon');
  var viewModalTitle = document.getElementById('view-modal-title');
  var viewFileFname  = document.getElementById('view-file-fname');
  var viewReportType = document.getElementById('view-report-type');
  var viewSentTo     = document.getElementById('view-sent-to');
  var viewDate       = document.getElementById('view-date');
  var viewStatus     = document.getElementById('view-status');
  var viewClose      = document.getElementById('view-close');
  var viewCloseBtn   = document.getElementById('view-close-btn');

  function openViewModal(row) {
    var name      = row.dataset.reportName  || (row.querySelector('.file-name')  ? row.querySelector('.file-name').textContent  : 'Report');
    var fname     = row.dataset.reportFname || (row.querySelector('.file-fname') ? row.querySelector('.file-fname').textContent : '');
    var type      = row.dataset.reportType  || (row.querySelector('td:nth-child(2)') ? row.querySelector('td:nth-child(2)').textContent.trim() : '—');
    var date      = row.dataset.reportDate  || (row.querySelector('.file-date')  ? row.querySelector('.file-date').textContent  : '—');
    var ext       = row.dataset.reportExt   || 'DOC';
    var isAudit   = row.dataset.isAudit === 'true';
    var forwarded = row.dataset.forwarded === 'true';
    var sentTo    = row.dataset.sentTo;

    if (viewFileIcon) {
      viewFileIcon.className = 'view-file-icon ' + ext.toLowerCase();
      viewFileIcon.textContent = ext;
    }
    if (viewModalTitle) viewModalTitle.textContent = name;
    if (viewFileFname)  viewFileFname.textContent  = fname;
    if (viewReportType) viewReportType.textContent  = type;

    if (viewSentTo) {
      if (isAudit)               viewSentTo.textContent = '—';
      else if (sentTo === 'dsa') viewSentTo.textContent = 'DSA';
      else if (sentTo === 'me')  viewSentTo.textContent = 'Only Me';
      else                       viewSentTo.textContent = '—';
    }

    if (viewDate)   viewDate.textContent   = date;
    if (viewStatus) {
      if (isAudit)               viewStatus.textContent = 'Audit (Restricted)';
      else if (forwarded)        viewStatus.textContent = 'Forwarded to DSA';
      else if (sentTo === 'dsa') viewStatus.textContent = 'Submitted to DSA';
      else                       viewStatus.textContent = 'Private';
    }

    if (viewModal) { viewModal.classList.add('active'); document.body.style.overflow = 'hidden'; }
  }

  function closeViewModal() {
    if (viewModal) { viewModal.classList.remove('active'); document.body.style.overflow = ''; }
  }

  if (viewClose)    viewClose.addEventListener('click', closeViewModal);
  if (viewCloseBtn) viewCloseBtn.addEventListener('click', closeViewModal);
  if (viewModal) {
    viewModal.addEventListener('click', function (e) { if (e.target === viewModal) closeViewModal(); });
  }

  /* ════════════════════════════════════════════════
     EDIT REPORT MODAL
  ════════════════════════════════════════════════ */
  var editModal        = document.getElementById('edit-modal');
  var editTitleInput   = document.getElementById('edit-report-title');
  var editTypeSelect   = document.getElementById('edit-report-type');
  var editSendToSelect = document.getElementById('edit-send-to');
  var editSendToGroup  = document.getElementById('edit-send-to-group');
  var editAuditNote    = document.getElementById('edit-audit-note');
  var editFileZone     = document.getElementById('edit-file-zone');
  var editFileInput    = document.getElementById('edit-file-input');
  var editFilePreview  = document.getElementById('edit-file-preview');
  var editFilePreviewName = document.getElementById('edit-file-preview-name');
  var editFileRemove   = document.getElementById('edit-file-remove');
  var editCancel       = document.getElementById('edit-cancel');
  var editConfirm      = document.getElementById('edit-confirm');
  var pendingEditRow   = null;
  var editNewFile      = null;

  function applyEditAuditLock() {
    if (!editTypeSelect) return;
    var isAudit = editTypeSelect.value === 'Audit Report';
    if (editSendToSelect) editSendToSelect.disabled = isAudit;
    if (editAuditNote)    editAuditNote.style.display = isAudit ? 'flex' : 'none';
  }

  if (editTypeSelect) {
    editTypeSelect.addEventListener('change', applyEditAuditLock);
  }

  if (editFileZone) {
    editFileZone.addEventListener('click', function () { editFileInput && editFileInput.click(); });
  }
  if (editFileInput) {
    editFileInput.addEventListener('change', function () {
      if (editFileInput.files && editFileInput.files.length > 0) {
        editNewFile = editFileInput.files[0];
        var allowed = ['application/pdf','application/msword','application/vnd.openxmlformats-officedocument.wordprocessingml.document','application/vnd.ms-excel','application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'];
        if (allowed.indexOf(editNewFile.type) === -1) { alert('Only PDF, Word, or Excel files are allowed.'); editNewFile = null; return; }
        if (editNewFile.size > 30 * 1024 * 1024) { alert('File size exceeds 30MB limit.'); editNewFile = null; return; }
        if (editFilePreviewName) editFilePreviewName.textContent = editNewFile.name;
        if (editFileZone)    editFileZone.style.display    = 'none';
        if (editFilePreview) editFilePreview.style.display = 'flex';
      }
    });
  }
  if (editFileRemove) {
    editFileRemove.addEventListener('click', function () {
      editNewFile = null;
      if (editFileInput)   editFileInput.value = '';
      if (editFileZone)    editFileZone.style.display    = '';
      if (editFilePreview) editFilePreview.style.display = 'none';
    });
  }

  function openEditModal(row) {
    pendingEditRow = row;
    editNewFile    = null;

    var name   = row.dataset.reportName || (row.querySelector('.file-name') ? row.querySelector('.file-name').textContent : '');
    var type   = row.dataset.reportType || '';
    var sentTo = row.dataset.sentTo     || 'dsa';

    if (editTitleInput)   editTitleInput.value   = name;
    if (editTypeSelect)   editTypeSelect.value   = type;
    if (editSendToSelect) editSendToSelect.value = (sentTo === 'null' || sentTo === null || !sentTo) ? 'dsa' : sentTo;

    if (editFileInput)   editFileInput.value = '';
    if (editFileZone)    editFileZone.style.display    = '';
    if (editFilePreview) editFilePreview.style.display = 'none';

    applyEditAuditLock();

    if (editModal) { editModal.classList.add('active'); document.body.style.overflow = 'hidden'; }
  }

  function closeEditModal() {
    if (editModal) { editModal.classList.remove('active'); document.body.style.overflow = ''; }
    pendingEditRow = null;
    editNewFile    = null;
  }

  if (editCancel) editCancel.addEventListener('click', closeEditModal);
  if (editModal) {
    editModal.addEventListener('click', function (e) { if (e.target === editModal) closeEditModal(); });
  }

  if (editConfirm) {
    editConfirm.addEventListener('click', function () {
      if (!pendingEditRow) { closeEditModal(); return; }

      var newTitle  = editTitleInput   ? editTitleInput.value.trim() : '';
      var newType   = editTypeSelect   ? editTypeSelect.value        : '';
      var newSentTo = editSendToSelect ? editSendToSelect.value      : 'dsa';
      var isAudit   = (newType === 'Audit Report');

      if (!newTitle) { alert('Please enter a report title.'); editTitleInput && editTitleInput.focus(); return; }
      if (!newType)  { alert('Please select a report type.'); return; }

      pendingEditRow.dataset.reportName = newTitle;
      pendingEditRow.dataset.reportType = newType;
      pendingEditRow.dataset.isAudit    = isAudit ? 'true' : 'false';

      if (isAudit) {
        pendingEditRow.dataset.sentTo    = 'null';
        pendingEditRow.dataset.forwarded = 'false';
      } else {
        pendingEditRow.dataset.sentTo = newSentTo;
        /* If changing TO dsa, mark forwarded so button freezes */
        if (newSentTo === 'dsa') {
          pendingEditRow.dataset.forwarded = 'true';
        }
      }

      if (editNewFile) {
        var newExt = 'PDF';
        if (editNewFile.type.indexOf('word') !== -1 || editNewFile.type.indexOf('document') !== -1) newExt = 'DOC';
        if (editNewFile.type.indexOf('excel') !== -1 || editNewFile.type.indexOf('sheet') !== -1)   newExt = 'XLS';
        var newIconCls = newExt === 'PDF' ? 'pdf' : (newExt === 'DOC' ? 'doc' : 'xls');

        var iconEl = pendingEditRow.querySelector('.file-icon');
        if (iconEl) { iconEl.className = 'file-icon ' + newIconCls; iconEl.textContent = newExt; }

        var fnameEl = pendingEditRow.querySelector('.file-fname');
        if (fnameEl) fnameEl.textContent = editNewFile.name;

        pendingEditRow.dataset.reportFname = editNewFile.name;
        pendingEditRow.dataset.reportExt   = newExt;
      }

      var nameEl = pendingEditRow.querySelector('.file-name');
      if (nameEl) nameEl.textContent = newTitle;

      var typeCell = pendingEditRow.querySelector('td:nth-child(2)');
      if (typeCell) typeCell.textContent = newType;

      var sentToCell = pendingEditRow.querySelector('td:nth-child(3)');
      if (sentToCell) {
        if (isAudit) {
          sentToCell.innerHTML = '<span class="null-cell">—</span>';
        } else if (newSentTo === 'dsa' || pendingEditRow.dataset.forwarded === 'true') {
          sentToCell.innerHTML = '<span class="badge badge-dsa">DSA</span>';
        } else {
          sentToCell.innerHTML = '<span class="badge badge-me">Only Me</span>';
        }
      }

      var fwdCell = pendingEditRow.querySelector('td:nth-child(4)');
      if (fwdCell) {
        if (isAudit) {
          fwdCell.innerHTML = '<span class="null-cell">—</span>';
        } else {
          var isForwarded = pendingEditRow.dataset.forwarded === 'true';
          var fwdBtnHTML = isForwarded
            ? '<button class="forward-btn forwarded" disabled>' + forwardedHTML() + '</button>'
            : '<button class="forward-btn" title="Forward to DSA">' + forwardActiveHTML() + '</button>';
          fwdCell.innerHTML = fwdBtnHTML;

          if (!isForwarded) {
            var newFwdBtn = fwdCell.querySelector('.forward-btn');
            if (newFwdBtn) {
              newFwdBtn.addEventListener('click', function (e) {
                e.stopPropagation();
                var n = pendingEditRow.querySelector('.file-name') ? pendingEditRow.querySelector('.file-name').textContent : 'this report';
                openForwardModal(pendingEditRow, n);
              });
            }
          }
        }
      }

      closeEditModal();
      filterRows(currentTab);
      updateForwardButtons(currentTab);
    });
  }

  /* ════════════════════════════════════════════════
     KEBAB MENU
  ════════════════════════════════════════════════ */
  function closeAllMenus() {
    document.querySelectorAll('.menu-dropdown.open').forEach(function (d) { d.classList.remove('open'); });
  }

  document.addEventListener('click', function (e) {
    if (!e.target.closest('.menu-wrap')) closeAllMenus();
  });

  function wireMenuForRow(row) {
    var menuBtn      = row.querySelector('.menu-btn');
    var menuDropdown = row.querySelector('.menu-dropdown');
    var menuView     = row.querySelector('.menu-item-view');
    var menuEdit     = row.querySelector('.menu-item-edit');
    var menuDelete   = row.querySelector('.menu-item-delete');

    if (menuBtn && menuDropdown) {
      menuBtn.addEventListener('click', function (e) {
        e.stopPropagation();
        var isOpen = menuDropdown.classList.contains('open');
        closeAllMenus();
        if (!isOpen) menuDropdown.classList.add('open');
      });
    }

    if (menuView) {
      menuView.addEventListener('click', function (e) {
        e.stopPropagation();
        closeAllMenus();
        openViewModal(row);
      });
    }

    if (menuEdit) {
      menuEdit.addEventListener('click', function (e) {
        e.stopPropagation();
        closeAllMenus();
        openEditModal(row);
      });
    }

    if (menuDelete) {
      menuDelete.addEventListener('click', function (e) {
        e.stopPropagation();
        closeAllMenus();
        var name = row.querySelector('.file-name') ? row.querySelector('.file-name').textContent : 'this report';
        openDeleteModal(row, name);
      });
    }
  }

  /* ════════════════════════════════════════════════
     ADD ROW TO TABLE
  ════════════════════════════════════════════════ */
  function addReportRow(data) {
    var tbody = document.getElementById('reports-tbody');
    if (!tbody) return;

    var sentToLabel;
    if (data.isAudit) {
      sentToLabel = '<span class="null-cell">—</span>';
    } else if (data.sentTo === 'dsa' || data.forwarded) {
      sentToLabel = '<span class="badge badge-dsa">DSA</span>';
    } else {
      sentToLabel = '<span class="badge badge-me">Only Me</span>';
    }

    var fwdCell;
    if (data.isAudit) {
      /* Audit reports: no Forward button */
      fwdCell = '<span class="null-cell">—</span>';
    } else if (data.forwarded) {
      /* Already sent to DSA: Forward button frozen */
      fwdCell = '<button class="forward-btn forwarded" disabled title="Already submitted to DSA" aria-label="Already submitted to DSA">' + forwardedHTML() + '</button>';
    } else {
      /* Sent to "Only Me": Forward button active */
      fwdCell = '<button class="forward-btn" title="Forward to DSA" aria-label="Forward to DSA">' + forwardActiveHTML() + '</button>';
    }

    var tr = document.createElement('tr');
    tr.dataset.sentTo     = data.isAudit ? 'null' : (data.sentTo || 'me');
    tr.dataset.forwarded  = data.forwarded ? 'true' : 'false';
    tr.dataset.isAudit    = data.isAudit ? 'true' : 'false';
    tr.dataset.reportName = data.name;
    tr.dataset.reportFname= data.fname;
    tr.dataset.reportType = data.type;
    tr.dataset.reportDate = data.date;
    tr.dataset.reportExt  = data.ext;
    tr.classList.add('clickable-row');

    tr.innerHTML =
      '<td>' +
        '<div class="file-cell">' +
          '<div class="file-icon ' + data.iconClass + '">' + data.ext + '</div>' +
          '<div class="file-info">' +
            '<span class="file-name">' + escapeHtml(data.name) + '</span>' +
            '<span class="file-fname">' + escapeHtml(data.fname) + '</span>' +
            '<span class="file-date">' + data.date + '</span>' +
          '</div>' +
        '</div>' +
      '</td>' +
      '<td>' + escapeHtml(data.type) + '</td>' +
      '<td>' + sentToLabel + '</td>' +
      '<td>' + fwdCell + '</td>' +
      '<td>' +
        '<div class="menu-wrap">' +
          '<button class="menu-btn" title="Options" aria-label="Row options">' +
            '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="5" r="1"/><circle cx="12" cy="12" r="1"/><circle cx="12" cy="19" r="1"/></svg>' +
          '</button>' +
          '<div class="menu-dropdown">' +
            '<button class="menu-item menu-item-view"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>View</button>' +
            '<button class="menu-item menu-item-edit"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>Edit</button>' +
            '<button class="menu-item menu-item-delete"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/><path d="M10 11v6"/><path d="M14 11v6"/><path d="M9 6V4a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2"/></svg>Delete</button>' +
          '</div>' +
        '</div>' +
      '</td>';

    /* Wire forward button for "Only Me" reports */
    if (!data.isAudit && !data.forwarded) {
      var fwdBtn = tr.querySelector('.forward-btn');
      if (fwdBtn) {
        fwdBtn.addEventListener('click', function (e) {
          e.stopPropagation();
          var name = tr.querySelector('.file-name') ? tr.querySelector('.file-name').textContent : 'this report';
          openForwardModal(tr, name);
        });
      }
    }

    /* Row click → view */
    tr.addEventListener('click', function (e) {
      if (e.target.closest('button') || e.target.closest('.menu-wrap')) return;
      openViewModal(tr);
    });

    wireMenuForRow(tr);

    tbody.appendChild(tr);
    filterRows(currentTab);
    updateForwardButtons(currentTab);
    toggleEmptyState(false);
  }

  /* ════════════════════════════════════════════════
     WIRE EXISTING ROWS
  ════════════════════════════════════════════════ */
  document.querySelectorAll('#reports-tbody tr').forEach(function (row) {

    var fwdBtn = row.querySelector('.forward-btn');
    if (fwdBtn && !fwdBtn.disabled) {
      fwdBtn.addEventListener('click', function (e) {
        e.stopPropagation();
        var name = row.querySelector('.file-name') ? row.querySelector('.file-name').textContent : 'this report';
        openForwardModal(row, name);
      });
    }

    row.addEventListener('click', function (e) {
      if (e.target.closest('button') || e.target.closest('.menu-wrap')) return;
      openViewModal(row);
    });

    wireMenuForRow(row);
  });

  /* ════════════════════════════════════════════════
     HELPERS
  ════════════════════════════════════════════════ */
  function escapeHtml(str) {
    return String(str)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }

  document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape') {
      closeForwardModal();
      closeDeleteModal();
      closeViewModal();
      closeEditModal();
      closeAllMenus();
    }
  });

  /* Initial tab */
  switchTab('all');

}); // end DOMContentLoaded