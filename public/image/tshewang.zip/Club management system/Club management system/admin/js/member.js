'use strict';

/* ══════════════════════════════════════════════════════════
   MEMBER.JS  —  JNEC Club Management · Members Page
   ══════════════════════════════════════════════════════════ */

/* ══ PAGE META ══ */
var PAGE_META = {
  'dashboard':        { title: 'Dashboard',        subtitle: 'Club overview' },
  'club-details':     { title: 'Club Details',      subtitle: 'Manage your club information' },
  'assign-secretary': { title: 'Assign Secretary',  subtitle: 'Manage club secretary roles' },
  'members':          { title: 'Members',            subtitle: 'View and manage club members' },
  'announcements':    { title: 'Announcements',      subtitle: 'Post and manage announcements' },
  'attendance':       { title: 'Attendance',         subtitle: 'Track member attendance' },
  'enrollment-key':   { title: 'Enrollment Key',     subtitle: 'Manage club enrollment keys' },
  'upload-reports':   { title: 'Upload Reports',     subtitle: 'Submit club reports' },
  'upload-workplan':  { title: 'Upload Work Plan',   subtitle: 'Submit club work plans' },
  'upload-image':     { title: 'Upload Image',       subtitle: 'Upload club images' },
  'upload-vlog':      { title: 'Upload Vlog',        subtitle: 'Upload club video logs' }
};

/* ══ DOM REFERENCES ══ */
var topbarTitle    = document.getElementById('topbar-title');
var topbarSubtitle = document.getElementById('topbar-subtitle');
var notifBadge     = document.getElementById('notif-badge');
var navItems       = document.querySelectorAll('.nav-item');

var tbody          = document.getElementById('members-tbody');
var inactiveTbody  = document.getElementById('inactive-tbody');
var checkAll       = document.getElementById('check-all');
var bulkBanner     = document.getElementById('bulk-banner');
var bulkCount      = document.getElementById('bulk-count');
var btnClear       = document.getElementById('btn-clear');
var btnDeleteAll   = document.getElementById('btn-delete-all');
var searchInput    = document.getElementById('search-input');
var searchWrap     = document.getElementById('search-wrap');
var emptyState     = document.getElementById('empty-state');
var inactiveEmpty  = document.getElementById('inactive-empty');
var statCards      = document.querySelectorAll('.stat-card');
var activeSection  = document.getElementById('active-section');
var inactiveSection= document.getElementById('inactive-section');
var tabActive      = document.getElementById('tab-active');
var tabInactive    = document.getElementById('tab-inactive');
var tabActiveCount = document.getElementById('tab-active-count');
var tabInactiveCount = document.getElementById('tab-inactive-count');

/* ══ MOBILE SIDEBAR ══ */
var hamburgerBtn   = document.getElementById('hamburger-btn');
var sidebar        = document.getElementById('sidebar');
var sidebarOverlay = document.getElementById('sidebar-overlay');

function openSidebar() {
  if (sidebar) sidebar.classList.add('open');
  if (sidebarOverlay) {
    sidebarOverlay.style.display = 'block';
    setTimeout(function () { sidebarOverlay.classList.add('active'); }, 10);
  }
  document.body.style.overflow = 'hidden';
}
function closeSidebar() {
  if (sidebar) sidebar.classList.remove('open');
  if (sidebarOverlay) {
    sidebarOverlay.classList.remove('active');
    setTimeout(function () { sidebarOverlay.style.display = 'none'; }, 280);
  }
  document.body.style.overflow = '';
}
if (hamburgerBtn) hamburgerBtn.addEventListener('click', function () {
  sidebar && sidebar.classList.contains('open') ? closeSidebar() : openSidebar();
});
if (sidebarOverlay) sidebarOverlay.addEventListener('click', closeSidebar);

/* ══ SIDEBAR NAV ══ */
navItems.forEach(function (item) {
  item.addEventListener('click', function (e) {
    var href = item.getAttribute('href');
    if (!href || href === '#') e.preventDefault();
    navItems.forEach(function (n) { n.classList.remove('active'); });
    item.classList.add('active');
    var p = item.dataset.page;
    var m = PAGE_META[p] || PAGE_META['members'];
    if (topbarTitle)    topbarTitle.textContent    = m.title;
    if (topbarSubtitle) topbarSubtitle.textContent = m.subtitle;
    closeSidebar();
  });
});

/* ══ DATA ══ */
var MEMBERS = [
  { id: 1, name: 'Pema Deki',       initials: 'PD', color: '#7c6fcd', year: 3, studentId: 'JNEC2022031', dept: 'Electrical Engg', status: 'Member' },
  { id: 2, name: 'Sonam Yangzom',   initials: 'SY', color: '#4aab8a', year: 3, studentId: 'JNEC2022058', dept: 'IT Engg',         status: 'Member' },
  { id: 3, name: 'Karma Tshering',  initials: 'KT', color: '#e07a4a', year: 4, studentId: 'JNEC2021010', dept: 'Civil Engg',      status: 'Member' },
  { id: 4, name: 'Tenzin Wangdi',   initials: 'TW', color: '#2d5be3', year: 4, studentId: 'JNEC2021034', dept: 'Mechanical Engg', status: 'Member' },
  { id: 5, name: 'Dema Choden',     initials: 'DC', color: '#d44f8a', year: 4, studentId: 'JNEC2021055', dept: 'IT Engg',         status: 'Member' },
  { id: 6, name: 'Rinchen Norbu',   initials: 'RN', color: '#3aabb0', year: 4, studentId: 'JNEC2021072', dept: 'Electrical Engg', status: 'Member' },
  { id: 7, name: 'Tashi Dorji',     initials: 'TD', color: '#e05c5c', year: 2, studentId: 'JNEC2023008', dept: 'Civil Engg',      status: 'Member' },
  { id: 8, name: 'Phuntsho Wangmo', initials: 'PW', color: '#8e5be3', year: 1, studentId: 'JNEC2024002', dept: 'IT Engg',         status: 'Member' }
];

var state = {
  members:      JSON.parse(JSON.stringify(MEMBERS)),
  inactive:     [],                 /* soft-deleted members */
  selectedIds:  [],
  activeYear:   'all',
  query:        '',
  currentTab:   'active'           /* 'active' | 'inactive' */
};

/* ══ HELPERS ══ */
function yearLabel(y) {
  return ['', '1st', '2nd', '3rd', '4th'][y] + ' Year';
}

function formatDate(d) {
  var months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
  return months[d.getMonth()] + ' ' + d.getDate() + ', ' + d.getFullYear();
}

function getFiltered() {
  return state.members.filter(function (m) {
    var yearOk = state.activeYear === 'all' || String(m.year) === String(state.activeYear);
    var q      = state.query;
    var qOk    = !q ||
      m.name.toLowerCase().indexOf(q) > -1 ||
      m.studentId.toLowerCase().indexOf(q) > -1 ||
      m.dept.toLowerCase().indexOf(q) > -1;
    return yearOk && qOk;
  });
}

/* ══ TAB SWITCHING ══ */
function setTab(tab) {
  state.currentTab  = tab;
  state.selectedIds = [];

  if (tab === 'active') {
    tabActive.classList.add('active');
    tabInactive.classList.remove('active');
    activeSection.style.display  = 'block';
    inactiveSection.style.display = 'none';
    searchWrap.style.display     = 'block';
  } else {
    tabInactive.classList.add('active');
    tabActive.classList.remove('active');
    activeSection.style.display  = 'none';
    inactiveSection.style.display = 'block';
    searchWrap.style.display     = 'none';
  }
  render();
}

function statsRow() { return document.getElementById('stats-row'); }

tabActive.addEventListener('click',   function () { setTab('active');   });
tabInactive.addEventListener('click', function () { setTab('inactive'); });

/* ══ YEAR FILTER ══ */
statCards.forEach(function (card) {
  card.addEventListener('click', function () {
    statCards.forEach(function (c) { c.classList.remove('active'); });
    card.classList.add('active');
    state.activeYear  = card.dataset.year;
    state.selectedIds = [];
    render();
  });
});

/* ══ SEARCH ══ */
if (searchInput) {
  searchInput.addEventListener('input', function () {
    state.query       = searchInput.value.trim().toLowerCase();
    state.selectedIds = [];
    render();
  });
}

/* ══ RENDER ══ */
function render() {
  renderActive();
  renderInactive();
  updateBulkBanner();
  updateCheckAll();
  updateStatCounts();
  updateTabCounts();
}

/* ── Active members table ── */
function renderActive() {
  var filtered = getFiltered();
  if (filtered.length === 0) {
    tbody.innerHTML = '';
    emptyState.style.display = 'block';
  } else {
    emptyState.style.display = 'none';
    tbody.innerHTML = filtered.map(function (m) {
      var checked = state.selectedIds.indexOf(m.id) > -1;
      return (
        '<tr class="' + (checked ? 'row-selected' : '') + '" data-id="' + m.id + '">' +
          '<td class="col-check"><input type="checkbox" class="custom-check row-check" data-id="' + m.id + '" ' + (checked ? 'checked' : '') + ' /></td>' +
          '<td><div class="member-cell">' +
            '<div class="member-avatar" style="background:' + m.color + '">' + m.initials + '</div>' +
            '<div>' +
              '<div class="member-name">' + m.name + '</div>' +
              '<div class="member-year">' + yearLabel(m.year) + '</div>' +
            '</div>' +
          '</div></td>' +
          '<td>' + m.studentId + '</td>' +
          '<td>' + m.dept + '</td>' +
          '<td><span class="badge-member">' + m.status + '</span></td>' +
          '<td><button class="btn-delete" data-id="' + m.id + '">Delete</button></td>' +
        '</tr>'
      );
    }).join('');

    tbody.querySelectorAll('.row-check').forEach(function (chk) {
      chk.addEventListener('change', function () {
        var id = parseInt(chk.dataset.id);
        if (chk.checked) {
          if (state.selectedIds.indexOf(id) === -1) state.selectedIds.push(id);
        } else {
          state.selectedIds = state.selectedIds.filter(function (x) { return x !== id; });
        }
        updateBulkBanner();
        updateCheckAll();
        highlightRows();
      });
    });

    tbody.querySelectorAll('.btn-delete').forEach(function (btn) {
      btn.addEventListener('click', function () {
        softDeleteMember(parseInt(btn.dataset.id));
      });
    });
  }
}

/* ── Inactive members table ── */
function renderInactive() {
  if (state.inactive.length === 0) {
    inactiveTbody.innerHTML = '';
    inactiveEmpty.style.display = 'block';
  } else {
    inactiveEmpty.style.display = 'none';
    inactiveTbody.innerHTML = state.inactive.map(function (m) {
      return (
        '<tr data-id="' + m.id + '">' +
          '<td><div class="member-cell">' +
            '<div class="member-avatar" style="background:' + m.color + '">' + m.initials + '</div>' +
            '<div>' +
              '<div class="member-name">' + m.name + '</div>' +
            '</div>' +
          '</div></td>' +
          '<td>' + m.studentId + '</td>' +
          '<td>' + m.dept + '</td>' +
          '<td>' + yearLabel(m.year) + '</td>' +
          '<td><span class="removed-date">' + m.removedOn + '</span></td>' +
          '<td>' +
            '<div style="display:flex;align-items:center;gap:8px;">' +
              '<button class="btn-restore" data-id="' + m.id + '">' +
                '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" width="13" height="13"><polyline points="1 4 1 10 7 10"/><path d="M3.51 15a9 9 0 1 0 .49-3.5"/></svg>' +
                'Restore' +
              '</button>' +
              '<button class="btn-perm-delete" data-id="' + m.id + '" title="Permanently Delete">' +
                '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" width="15" height="15">' +
                  '<polyline points="3 6 5 6 21 6"/>' +
                  '<path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/>' +
                  '<path d="M10 11v6"/><path d="M14 11v6"/>' +
                  '<path d="M9 6V4a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2"/>' +
                '</svg>' +
              '</button>' +
            '</div>' +
          '</td>' +
        '</tr>'
      );
    }).join('');

    inactiveTbody.querySelectorAll('.btn-restore').forEach(function (btn) {
      btn.addEventListener('click', function () { restoreMember(parseInt(btn.dataset.id)); });
    });
    inactiveTbody.querySelectorAll('.btn-perm-delete').forEach(function (btn) {
      btn.addEventListener('click', function () { permanentDelete(parseInt(btn.dataset.id)); });
    });
  }
}

function highlightRows() {
  tbody.querySelectorAll('tr[data-id]').forEach(function (row) {
    var id = parseInt(row.dataset.id);
    row.classList.toggle('row-selected', state.selectedIds.indexOf(id) > -1);
  });
}

/* ══ CHECK ALL ══ */
if (checkAll) {
  checkAll.addEventListener('change', function () {
    var filtered = getFiltered();
    state.selectedIds = checkAll.checked ? filtered.map(function (m) { return m.id; }) : [];
    render();
  });
}
function updateCheckAll() {
  if (!checkAll) return;
  var filtered = getFiltered();
  if (filtered.length === 0) { checkAll.checked = false; checkAll.indeterminate = false; return; }
  var selCount = filtered.filter(function (m) { return state.selectedIds.indexOf(m.id) > -1; }).length;
  if (selCount === 0)                    { checkAll.checked = false; checkAll.indeterminate = false; }
  else if (selCount === filtered.length) { checkAll.checked = true;  checkAll.indeterminate = false; }
  else                                   { checkAll.checked = false; checkAll.indeterminate = true;  }
}

/* ══ BULK BANNER ══ */
function updateBulkBanner() {
  var n = state.selectedIds.length;
  bulkBanner.style.display = (n > 0 && state.currentTab === 'active') ? 'flex' : 'none';
  if (n > 0) bulkCount.textContent = n + ' member' + (n > 1 ? 's' : '') + ' selected';
}

if (btnClear) { btnClear.addEventListener('click', function () { state.selectedIds = []; render(); }); }

/* ══ BULK SOFT DELETE ══ */
if (btnDeleteAll) {
  btnDeleteAll.addEventListener('click', function () {
    var count = state.selectedIds.length;
    Swal.fire({
      title: 'Remove ' + count + ' Member' + (count > 1 ? 's' : '') + '?',
      text: 'They will be moved to Inactive Members. You can restore them anytime.',
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#e53e3e',
      cancelButtonColor: '#6b7f93',
      confirmButtonText: 'Yes, Move to Inactive',
      cancelButtonText: 'Cancel',
      customClass: { popup: 'swal-custom-popup', title: 'swal-custom-title', confirmButton: 'swal-confirm-btn', cancelButton: 'swal-cancel-btn' },
      focusCancel: true
    }).then(function (result) {
      if (result.isConfirmed) {
        var today = formatDate(new Date());
        state.selectedIds.forEach(function (id) {
          var idx = state.members.findIndex(function (m) { return m.id === id; });
          if (idx !== -1) {
            var removed = state.members.splice(idx, 1)[0];
            removed.removedOn = today;
            state.inactive.unshift(removed);
          }
        });
        state.selectedIds = [];
        render();
        Swal.fire({
          title: 'Moved to Inactive',
          text: count + ' member' + (count > 1 ? 's have' : ' has') + ' been moved to Inactive Members.',
          icon: 'success',
          confirmButtonColor: '#2d5be3',
          timer: 2200, timerProgressBar: true,
          customClass: { popup: 'swal-custom-popup', title: 'swal-custom-title' }
        });
      }
    });
  });
}

/* ══ SINGLE SOFT DELETE ══ */
function softDeleteMember(id) {
  var member = state.members.find(function (m) { return m.id === id; });
  if (!member) return;
  Swal.fire({
    title: 'Remove ' + member.name + '?',
    text: member.name + ' will be moved to Inactive Members. You can restore them anytime.',
    icon: 'warning',
    showCancelButton: true,
    confirmButtonColor: '#e53e3e',
    cancelButtonColor: '#6b7f93',
    confirmButtonText: 'Yes, Remove',
    cancelButtonText: 'Cancel',
    customClass: { popup: 'swal-custom-popup', title: 'swal-custom-title', confirmButton: 'swal-confirm-btn', cancelButton: 'swal-cancel-btn' },
    focusCancel: true
  }).then(function (result) {
    if (result.isConfirmed) {
      var idx = state.members.findIndex(function (m) { return m.id === id; });
      if (idx !== -1) {
        var removed = state.members.splice(idx, 1)[0];
        removed.removedOn = formatDate(new Date());
        state.inactive.unshift(removed);
      }
      state.selectedIds = state.selectedIds.filter(function (x) { return x !== id; });
      render();
      Swal.fire({
        title: 'Moved to Inactive',
        text: member.name + ' has been moved to Inactive Members.',
        icon: 'success',
        confirmButtonColor: '#2d5be3',
        timer: 2000, timerProgressBar: true,
        customClass: { popup: 'swal-custom-popup', title: 'swal-custom-title' }
      });
    }
  });
}

/* ══ RESTORE MEMBER ══ */
function restoreMember(id) {
  var member = state.inactive.find(function (m) { return m.id === id; });
  if (!member) return;
  Swal.fire({
    title: 'Restore ' + member.name + '?',
    text: member.name + ' will be moved back to Active Members.',
    icon: 'question',
    showCancelButton: true,
    confirmButtonColor: '#059669',
    cancelButtonColor: '#6b7f93',
    confirmButtonText: 'Yes, Restore',
    cancelButtonText: 'Cancel',
    customClass: { popup: 'swal-custom-popup', title: 'swal-custom-title', confirmButton: 'swal-confirm-btn', cancelButton: 'swal-cancel-btn' },
    focusCancel: true
  }).then(function (result) {
    if (result.isConfirmed) {
      var idx = state.inactive.findIndex(function (m) { return m.id === id; });
      if (idx !== -1) {
        var restored = state.inactive.splice(idx, 1)[0];
        delete restored.removedOn;
        state.members.push(restored);
      }
      render();
      Swal.fire({
        title: 'Restored!',
        text: member.name + ' has been restored to Active Members.',
        icon: 'success',
        confirmButtonColor: '#2d5be3',
        timer: 2000, timerProgressBar: true,
        customClass: { popup: 'swal-custom-popup', title: 'swal-custom-title' }
      });
    }
  });
}

/* ══ PERMANENT DELETE ══ */
function permanentDelete(id) {
  var member = state.inactive.find(function (m) { return m.id === id; });
  if (!member) return;
  Swal.fire({
    title: 'Permanently Delete ' + member.name + '?',
    text: 'This cannot be undone. ' + member.name + ' will be permanently removed from the club.',
    icon: 'warning',
    showCancelButton: true,
    confirmButtonColor: '#e53e3e',
    cancelButtonColor: '#6b7f93',
    confirmButtonText: 'Yes, Delete Permanently',
    cancelButtonText: 'Cancel',
    customClass: { popup: 'swal-custom-popup', title: 'swal-custom-title', confirmButton: 'swal-confirm-btn', cancelButton: 'swal-cancel-btn' },
    focusCancel: true
  }).then(function (result) {
    if (result.isConfirmed) {
      state.inactive = state.inactive.filter(function (m) { return m.id !== id; });
      render();
      Swal.fire({
        title: 'Permanently Deleted',
        text: member.name + ' has been permanently removed.',
        icon: 'success',
        confirmButtonColor: '#2d5be3',
        timer: 2000, timerProgressBar: true,
        customClass: { popup: 'swal-custom-popup', title: 'swal-custom-title' }
      });
    }
  });
}

/* ══ STAT COUNTS ══ */
function updateStatCounts() {
  statCards.forEach(function (card) {
    var yr  = card.dataset.year;
    var val = card.querySelector('.stat-value');
    if (!val) return;
    val.textContent = yr === 'all'
      ? state.members.length
      : state.members.filter(function (m) { return String(m.year) === yr; }).length;
  });
}

function updateTabCounts() {
  tabActiveCount.textContent   = state.members.length;
  tabInactiveCount.textContent = state.inactive.length;
}

/* ══ INIT ══ */
document.addEventListener('DOMContentLoaded', function () {
  if (notifBadge) notifBadge.style.display = 'block';
  render();
});