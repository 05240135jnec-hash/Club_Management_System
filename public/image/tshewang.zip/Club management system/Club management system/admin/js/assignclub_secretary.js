'use strict';

/* ══════════════════════════════════════════════════════════
   JNEC Club Management — Assign Secretary JS
   ─ Replace MEMBERS_DATA with your real API fetch later
══════════════════════════════════════════════════════════ */

/* ─── SAMPLE DATA (swap this with your backend call) ──────
   When connecting to backend, replace this array with:
   const res  = await fetch('/api/members');
   const data = await res.json();
   MEMBERS_DATA = data.members;
   ─────────────────────────────────────────────────────── */
var MEMBERS_DATA = [
  { id: 'STU-2021-001', name: 'Karma Dorji',       dept: 'Computer Science',       avatarColor: '#4f46e5' },
  { id: 'STU-2021-002', name: 'Sonam Wangchuk',    dept: 'Electrical Engineering',  avatarColor: '#0891b2' },
  { id: 'STU-2021-003', name: 'Pema Choden',       dept: 'Civil Engineering',       avatarColor: '#7c3aed' },
  { id: 'STU-2021-004', name: 'Tenzin Norbu',      dept: 'Mechanical Engineering',  avatarColor: '#059669' },
  { id: 'STU-2022-001', name: 'Dawa Zangmo',       dept: 'Information Technology',  avatarColor: '#dc2626' },
  { id: 'STU-2022-002', name: 'Rinzin Wangdi',     dept: 'Computer Science',        avatarColor: '#d97706' },
  { id: 'STU-2022-003', name: 'Yeshi Lhamo',       dept: 'Electronics Engineering', avatarColor: '#be185d' },
  { id: 'STU-2022-004', name: 'Phuntsho Tobgay',   dept: 'Civil Engineering',       avatarColor: '#1d4ed8' },
  { id: 'STU-2023-001', name: 'Namgay Tshering',   dept: 'Mechanical Engineering',  avatarColor: '#0f766e' },
  { id: 'STU-2023-002', name: 'Choden Dema',       dept: 'Computer Science',        avatarColor: '#6d28d9' },
];

/* ─── STATE ─────────────────────────────────────────────── */
var assignedSecretaries = [];   // max 2 objects from MEMBERS_DATA
var selectedMember      = null; // currently highlighted in modal

/* ─── DOM REFS ───────────────────────────────────────────── */
var assignBtn        = document.getElementById('assign-btn');
var assignedList     = document.getElementById('assigned-list');
var emptyState       = document.getElementById('empty-state');
var assignSubtitle   = document.getElementById('assign-subtitle');
var slotPill1        = document.getElementById('slot-pill-1');
var slotPill2        = document.getElementById('slot-pill-2');

var modalBackdrop    = document.getElementById('modal-backdrop');
var modalSearch      = document.getElementById('modal-search');
var modalMemberList  = document.getElementById('modal-member-list');
var btnConfirm       = document.getElementById('btn-confirm');
var btnCancel        = document.getElementById('btn-cancel');
var modalClose       = document.getElementById('modal-close');

var warnBackdrop     = document.getElementById('warn-backdrop');
var btnWarnOk        = document.getElementById('btn-warn-ok');

var toast            = document.getElementById('toast');
var toastMsg         = document.getElementById('toast-msg');
var toastIcon        = document.getElementById('toast-icon');

var hamburgerBtn     = document.getElementById('hamburger-btn');
var sidebar          = document.getElementById('sidebar');
var sidebarOverlay   = document.getElementById('sidebar-overlay');

var toastTimer = null;

/* ══════════════════════════════════════════════════════════
   HELPERS
══════════════════════════════════════════════════════════ */
function getInitials(name) {
  var parts = name.trim().split(/\s+/);
  if (parts.length === 1) return parts[0].substring(0, 2).toUpperCase();
  return (parts[0][0] + parts[parts.length - 1][0]).toUpperCase();
}

function showToast(message, type) {
  // type: 'success' | 'error'
  toast.className = 'toast show toast-' + (type || 'success');
  toastIcon.textContent = type === 'error' ? '⚠️' : '✅';
  toastMsg.textContent  = message;
  if (toastTimer) clearTimeout(toastTimer);
  toastTimer = setTimeout(function() {
    toast.classList.remove('show');
  }, 3200);
}

/* ══════════════════════════════════════════════════════════
   RENDER — Secretary Slots
══════════════════════════════════════════════════════════ */
function renderAssigned() {
  assignedList.innerHTML = '';
  var count = assignedSecretaries.length;

  // Empty state visibility
  if (count === 0) {
    emptyState.classList.remove('hidden');
    assignSubtitle.textContent = 'No secretary assigned yet — select a member below';
  } else {
    emptyState.classList.add('hidden');
    assignSubtitle.textContent =
      count === 1
        ? '1 secretary assigned — 1 slot remaining'
        : '2 secretaries assigned — maximum reached';
  }

  // Assign button state
  if (count >= 2) {
    assignBtn.classList.add('full');
  } else {
    assignBtn.classList.remove('full');
  }

  // Slot pills
  updateSlotPill(slotPill1, assignedSecretaries[0]);
  updateSlotPill(slotPill2, assignedSecretaries[1]);

  // Secretary cards
  assignedSecretaries.forEach(function(member, idx) {
    var card = document.createElement('div');
    card.className = 'assigned-card';
    card.innerHTML =
      '<div class="assigned-avatar" style="background:linear-gradient(135deg,' + member.avatarColor + ',#4f7af8)">'
        + getInitials(member.name) +
      '</div>'
      + '<div class="assigned-info">'
        + '<div class="assigned-name">' + escapeHtml(member.name) + '</div>'
        + '<div class="assigned-id">' + escapeHtml(member.id) + ' &nbsp;·&nbsp; ' + escapeHtml(member.dept) + '</div>'
      + '</div>'
      + '<div class="assigned-badge">'
        + '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>'
        + 'Secretary'
      + '</div>'
      + '<button class="remove-btn" data-idx="' + idx + '" title="Remove secretary">'
        + '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/><path d="M10 11v6"/><path d="M14 11v6"/><path d="M9 6V4a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2"/></svg>'
      + '</button>';

    assignedList.appendChild(card);
  });

  // Remove buttons
  assignedList.querySelectorAll('.remove-btn').forEach(function(btn) {
    btn.addEventListener('click', function() {
      var idx = parseInt(btn.getAttribute('data-idx'), 10);
      var removed = assignedSecretaries.splice(idx, 1)[0];
      renderAssigned();
      showToast(removed.name + ' has been removed as secretary.', 'error');
    });
  });
}

function updateSlotPill(pill, member) {
  var dot = pill.querySelector('.slot-dot');
  if (member) {
    pill.classList.add('filled');
    dot.className = 'slot-dot filled';
    pill.childNodes[0].textContent = getInitials(member.name) + ' ';
  } else {
    pill.classList.remove('filled');
    dot.className = 'slot-dot empty';
    var slotLabel = pill === slotPill1 ? 'Slot 1 ' : 'Slot 2 ';
    pill.childNodes[0].textContent = slotLabel;
  }
}

function escapeHtml(str) {
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

/* ══════════════════════════════════════════════════════════
   MODAL — Open / Close
══════════════════════════════════════════════════════════ */
function openModal() {
  selectedMember = null;
  btnConfirm.disabled = true;
  modalSearch.value = '';
  renderMemberList('');
  modalBackdrop.classList.add('open');
  setTimeout(function() { modalSearch.focus(); }, 180);
}

function closeModal() {
  modalBackdrop.classList.remove('open');
  selectedMember = null;
}

/* ══════════════════════════════════════════════════════════
   MODAL — Render Member List
══════════════════════════════════════════════════════════ */
function renderMemberList(query) {
  modalMemberList.innerHTML = '';
  var q = query.toLowerCase().trim();

  var filtered = MEMBERS_DATA.filter(function(m) {
    return m.name.toLowerCase().includes(q) || m.id.toLowerCase().includes(q);
  });

  if (filtered.length === 0) {
    modalMemberList.innerHTML = '<div class="no-results">No members found matching "<strong>' + escapeHtml(query) + '</strong>"</div>';
    return;
  }

  filtered.forEach(function(member) {
    var isAssigned = assignedSecretaries.some(function(s) { return s.id === member.id; });
    var isSelected = selectedMember && selectedMember.id === member.id;

    var row = document.createElement('div');
    row.className = 'member-row'
      + (isSelected ? ' selected' : '')
      + (isAssigned ? ' disabled' : '');

    row.innerHTML =
      '<div class="member-avatar" style="background:' + member.avatarColor + ';color:#fff">'
        + getInitials(member.name) +
      '</div>'
      + '<div class="member-details">'
        + '<div class="member-name">' + escapeHtml(member.name) + '</div>'
        + '<div class="member-sid">' + escapeHtml(member.id) + ' · ' + escapeHtml(member.dept) + '</div>'
      + '</div>'
      + (isAssigned
          ? '<span class="already-tag">Secretary ✓</span>'
          : '<div class="member-check"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg></div>'
        );

    if (!isAssigned) {
      row.addEventListener('click', function() {
        selectedMember = member;
        btnConfirm.disabled = false;
        renderMemberList(modalSearch.value);
      });
    }

    modalMemberList.appendChild(row);
  });
}

/* ══════════════════════════════════════════════════════════
   ASSIGN SECRETARY — Confirm
══════════════════════════════════════════════════════════ */
function confirmAssign() {
  if (!selectedMember) return;
  assignedSecretaries.push(selectedMember);
  var name = selectedMember.name;
  renderAssigned();
  closeModal();
  showToast(name + ' has been assigned as Club Secretary!', 'success');
}

/* ══════════════════════════════════════════════════════════
   WARNING MODAL
══════════════════════════════════════════════════════════ */
function openWarn() {
  warnBackdrop.classList.add('open');
}
function closeWarn() {
  warnBackdrop.classList.remove('open');
}

/* ══════════════════════════════════════════════════════════
   MOBILE SIDEBAR TOGGLE
══════════════════════════════════════════════════════════ */
function openSidebar() {
  if (sidebar) sidebar.classList.add('open');
  if (sidebarOverlay) {
    sidebarOverlay.style.display = 'block';
    setTimeout(function() { sidebarOverlay.classList.add('active'); }, 10);
  }
  document.body.style.overflow = 'hidden';
}

function closeSidebar() {
  if (sidebar) sidebar.classList.remove('open');
  if (sidebarOverlay) {
    sidebarOverlay.classList.remove('active');
    setTimeout(function() { sidebarOverlay.style.display = 'none'; }, 280);
  }
  document.body.style.overflow = '';
}

/* ══════════════════════════════════════════════════════════
   EVENT LISTENERS
══════════════════════════════════════════════════════════ */

// Assign button (main page)
assignBtn.addEventListener('click', function() {
  if (assignedSecretaries.length >= 2) {
    openWarn();
  } else {
    openModal();
  }
});

// Modal — search
modalSearch.addEventListener('input', function() {
  selectedMember = null;
  btnConfirm.disabled = true;
  renderMemberList(modalSearch.value);
});

// Modal — confirm
btnConfirm.addEventListener('click', confirmAssign);

// Modal — cancel / close
btnCancel.addEventListener('click', closeModal);
modalClose.addEventListener('click', closeModal);
modalBackdrop.addEventListener('click', function(e) {
  if (e.target === modalBackdrop) closeModal();
});

// Warning modal — ok
btnWarnOk.addEventListener('click', closeWarn);
warnBackdrop.addEventListener('click', function(e) {
  if (e.target === warnBackdrop) closeWarn();
});

// Keyboard ESC
document.addEventListener('keydown', function(e) {
  if (e.key === 'Escape') {
    if (modalBackdrop.classList.contains('open')) closeModal();
    if (warnBackdrop.classList.contains('open')) closeWarn();
  }
});

// Hamburger / Sidebar overlay
if (hamburgerBtn) {
  hamburgerBtn.addEventListener('click', function() {
    sidebar && sidebar.classList.contains('open') ? closeSidebar() : openSidebar();
  });
}
if (sidebarOverlay) {
  sidebarOverlay.addEventListener('click', closeSidebar);
}

// Close sidebar on nav click (mobile)
document.querySelectorAll('.nav-item').forEach(function(item) {
  item.addEventListener('click', function() {
    if (window.innerWidth <= 768) closeSidebar();
  });
});

/* ══════════════════════════════════════════════════════════
   INIT
══════════════════════════════════════════════════════════ */
document.addEventListener('DOMContentLoaded', function() {
  renderAssigned();
});