/* ══════════════════════════════════════════
   JNEC Club Directory — script.js
══════════════════════════════════════════ */

/* ── All Club Data ── */
const CLUB_DATA = {
  'Volunteer': {
    icon: 'fas fa-hands-helping',
    clubs: ['Y-Peer', 'Rover Scout', 'Red Cross', 'JNEC Clean Toilet Initiative']
  },
  'Maintenance': {
    icon: 'fas fa-tools',
    clubs: ['Mechanical Maintenance', 'Civil Maintenance', 'DIT Maintenance', 'Maintenance Hobby Club', 'Electrical Maintenance']
  },
  'Social Service': {
    icon: 'fas fa-heart',
    clubs: ['Helping Hand Club', 'JNEC GNH', 'JNEC Salon', 'Thakor Namsung Tshokpa', 'Integrity Club']
  },
  'Entrepreneurship': {
    icon: 'fas fa-lightbulb',
    clubs: ['Entrepreneurship Club']
  },
  'Entertainment': {
    icon: 'fas fa-music',
    clubs: ['JNEC Music Club', 'Culture Club', 'Media Club', 'Radio Club']
  },
  'Sports': {
    icon: 'fas fa-fist-raised',
    clubs: ['JNEC Karate']
  }
};

/* ══════════════════════════════════════════
   HAMBURGER MENU
══════════════════════════════════════════ */
const hamburger = document.getElementById('hamburger');
const navLinks  = document.getElementById('navLinks');

if (hamburger && navLinks) {
  hamburger.addEventListener('click', () => {
    navLinks.classList.toggle('open');
  });
  document.addEventListener('click', (e) => {
    if (!hamburger.contains(e.target) && !navLinks.contains(e.target)) {
      navLinks.classList.remove('open');
    }
  });
}

/* ══════════════════════════════════════════
   CLUBS RENDER
══════════════════════════════════════════ */
const clubsList    = document.getElementById('clubsList');
const clubsHeading = document.getElementById('clubsHeading');
const noResults    = document.getElementById('noResults');
let currentFilter  = 'all';

function renderClubs(filter, searchTerm) {
  clubsList.innerHTML = '';
  let hasResults = false;

  const categoriesToShow = filter === 'all'
    ? Object.keys(CLUB_DATA)
    : [filter];

  categoriesToShow.forEach(category => {
    const data = CLUB_DATA[category];
    if (!data) return;

    let clubs = data.clubs;
    if (searchTerm) {
      clubs = clubs.filter(c => c.toLowerCase().includes(searchTerm.toLowerCase()));
    }
    if (clubs.length === 0) return;
    hasResults = true;

    const block = document.createElement('div');
    block.className = 'category-block';

    const cardItems = clubs.map((club, i) => `
      <div class="club-card">
        <div class="club-card-num">${i + 1}</div>
        <div class="club-card-name">${club}</div>
        <div class="club-card-action">
          View Club <i class="fas fa-arrow-right" style="font-size:10px;"></i>
        </div>
      </div>
    `).join('');

    block.innerHTML = `
      <div class="category-block-header">
        <div class="category-block-icon"><i class="${data.icon}"></i></div>
        <span class="category-block-name">${category}</span>
        <span class="category-block-count">${clubs.length} Club${clubs.length > 1 ? 's' : ''}</span>
      </div>
      <div class="club-cards-grid">${cardItems}</div>
    `;

    clubsList.appendChild(block);
  });

  noResults.style.display = hasResults ? 'none' : 'block';
}
/* ══════════════════════════════════════════
   SEARCH
══════════════════════════════════════════ */
const searchBtn      = document.getElementById('searchBtn');
const searchBarWrap  = document.getElementById('searchBarWrap');
const searchInput    = document.getElementById('searchInput');
const searchCloseBtn = document.getElementById('searchCloseBtn');

if (searchBtn) {
  searchBtn.addEventListener('click', () => {
    searchBarWrap.classList.toggle('open');
    if (searchBarWrap.classList.contains('open')) {
      searchInput && searchInput.focus();
    } else {
      if (searchInput) searchInput.value = '';
      renderClubs(currentFilter, '');
    }
  });
}

if (searchCloseBtn) {
  searchCloseBtn.addEventListener('click', () => {
    searchBarWrap.classList.remove('open');
    if (searchInput) searchInput.value = '';
    renderClubs(currentFilter, '');
  });
}

if (searchInput) {
  searchInput.addEventListener('input', () => {
    const term = searchInput.value.trim();
    clubsHeading.textContent = term
      ? `Search: "${term}"`
      : (currentFilter === 'all' ? 'All Clubs' : currentFilter + ' Clubs');
    renderClubs(currentFilter, term);
  });
}

/* ══════════════════════════════════════════
   ANIMATED STATS COUNTER
══════════════════════════════════════════ */
const counters = document.querySelectorAll('.stat-num');
const observer = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      const el     = entry.target;
      const target = parseInt(el.dataset.target);
      let current  = 0;
      const step   = Math.ceil(target / 40);
      const timer  = setInterval(() => {
        current += step;
        if (current >= target) { current = target; clearInterval(timer); }
        el.textContent = current;
      }, 28);
      observer.unobserve(el);
    }
  });
}, { threshold: 0.5 });
counters.forEach(c => observer.observe(c));

/* ══════════════════════════════════════════
   MY CLUB SECTION
══════════════════════════════════════════ */
const myClubSection = document.getElementById('myClubSection');
const myClubCard    = document.getElementById('myClubCard');
const stored        = localStorage.getItem('myClub');

if (stored) {
  try {
    const club     = JSON.parse(stored);
    const initials = club.name.split(' ').map(w => w[0]).slice(0, 2).join('').toUpperCase();

    myClubCard.innerHTML = `
      <div class="my-club-avatar">${initials}</div>
      <div class="my-club-info">
        <div class="my-club-name">${club.name}</div>
        <div class="my-club-members">0 members</div>
        <span class="my-club-badge">${club.category}</span>
      </div>
      <i class="fas fa-chevron-right" style="color:var(--text-light);font-size:13px;"></i>
    `;

    myClubCard.onclick    = () => { window.location.href = 'dashboard.html'; };
    myClubSection.style.display = 'block';
  } catch(e) {
    localStorage.removeItem('myClub');
  }
}

