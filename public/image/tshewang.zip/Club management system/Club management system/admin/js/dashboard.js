'use strict';

/* ============================================================
   MOCK DATA  –  replace with real API calls later
   ============================================================ */
var CLUB_DATA = {
  totalMembers: 48,
  attendanceRate: 82,
  totalAnnouncements: 12,

  monthlyAttendance: {
    labels: ['October', 'November', 'December', 'January', 'February', 'March'],
    present: [38, 42, 35, 44, 40, 46],
    absent:  [10,  6, 13,  4,  8,  2]
  },

  announcements: [
    { id: 1, title: 'Annual Tech Fest – Registration Open',    date: '28 Mar 2025', type: 'event',   unread: true  },
    { id: 2, title: 'Club Meeting Rescheduled to Friday',      date: '25 Mar 2025', type: 'notice',  unread: true  },
    { id: 3, title: 'Hackathon 2025 – Winners Announced',      date: '20 Mar 2025', type: 'result',  unread: false },
    { id: 4, title: 'New Enrollment Key Released for Sem 6',   date: '18 Mar 2025', type: 'general', unread: false },
    { id: 5, title: 'Photography Workshop – Sign-up Now',      date: '14 Mar 2025', type: 'event',   unread: false }
  ]
};

/* ============================================================
   ADMIN PROFILE STATE
   ============================================================ */
var ADMIN_PROFILE = {
  name:       'Club Advisor',
  email:      'advisor@jnec.edu.bt',
  department: 'Computer Science & Engineering',
  photoUrl:   null   // null = show initials; string = data URL of uploaded photo
};

/* ============================================================
   COUNTER ANIMATION
   ============================================================ */
function animateCounter(el, target, suffix, duration) {
  if (!el) return;
  var start = 0;
  var startTime = null;
  suffix = suffix || '';

  function step(timestamp) {
    if (!startTime) startTime = timestamp;
    var progress = Math.min((timestamp - startTime) / duration, 1);
    var ease = 1 - Math.pow(1 - progress, 3);
    el.textContent = Math.round(start + (target - start) * ease) + suffix;
    if (progress < 1) requestAnimationFrame(step);
  }
  requestAnimationFrame(step);
}

/* ============================================================
   STAT CARDS
   ============================================================ */
function renderStatCards() {
  var d = CLUB_DATA;
  animateCounter(document.getElementById('stat-members'),       d.totalMembers,       '',  900);
  animateCounter(document.getElementById('stat-attendance'),    d.attendanceRate,     '%', 900);
  animateCounter(document.getElementById('stat-announcements'), d.totalAnnouncements, '',  900);
}

/* ============================================================
   ATTENDANCE CHART  (Chart.js)
   ============================================================ */
function renderAttendanceChart() {
  var ctx = document.getElementById('attendanceChart');
  if (!ctx) return;

  var wa = CLUB_DATA.monthlyAttendance;

  new Chart(ctx, {
    type: 'bar',
    data: {
      labels: wa.labels,
      datasets: [
        {
          label: 'Present',
          data: wa.present,
          backgroundColor: 'rgba(45, 91, 227, 0.85)',
          borderRadius: 6,
          borderSkipped: false,
          barPercentage: 0.55,
          categoryPercentage: 0.7
        },
        {
          label: 'Absent',
          data: wa.absent,
          backgroundColor: 'rgba(226, 230, 239, 0.9)',
          borderRadius: 6,
          borderSkipped: false,
          barPercentage: 0.55,
          categoryPercentage: 0.7
        }
      ]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      interaction: { mode: 'index', intersect: false },
      plugins: {
        legend: { display: false },
        tooltip: {
          backgroundColor: '#1a1a2e',
          titleColor: '#fff',
          bodyColor: '#c8d8e4',
          padding: 12,
          cornerRadius: 8,
          callbacks: {
            title: function(items) { return items[0].label; },
            label: function(item) {
              return '  ' + item.dataset.label + ': ' + item.raw + ' members';
            }
          }
        }
      },
      scales: {
        x: {
          stacked: false,
          grid: { display: false },
          border: { display: false },
          ticks: {
            font: { family: "'Inter', sans-serif", size: 12 },
            color: '#8892a4'
          }
        },
        y: {
          beginAtZero: true,
          grid: { color: 'rgba(0,0,0,0.05)', drawBorder: false },
          border: { display: false, dash: [4, 4] },
          ticks: {
            font: { family: "'Inter', sans-serif", size: 12 },
            color: '#8892a4',
            stepSize: 10
          }
        }
      }
    }
  });
}

/* ============================================================
   ANNOUNCEMENT ICON SVG helpers
   ============================================================ */
var ANN_ICONS = {
  event:   '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg>',
  notice:  '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>',
  result:  '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>',
  general: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 0 1-3.46 0"/></svg>'
};

/* ============================================================
   ANNOUNCEMENTS LIST
   ============================================================ */
function renderAnnouncements() {
  var list = document.getElementById('announcements-list');
  if (!list) return;

  var items = CLUB_DATA.announcements;
  if (!items || items.length === 0) {
    list.innerHTML = '<div class="empty-state"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 0 1-3.46 0"/></svg><p>No announcements yet.</p></div>';
    return;
  }

  list.innerHTML = items.map(function(ann) {
    return [
      '<div class="announcement-item">',
        '<div class="ann-icon type-' + ann.type + '">' + (ANN_ICONS[ann.type] || ANN_ICONS.general) + '</div>',
        '<div class="ann-body">',
          '<div class="ann-title">' + escapeHtml(ann.title) + '</div>',
          '<div class="ann-meta">',
            '<span class="ann-date">' + ann.date + '</span>',
            '<span class="ann-badge ' + ann.type + '">' + capitalize(ann.type) + '</span>',
          '</div>',
        '</div>',
        ann.unread ? '<div class="ann-unread"></div>' : '',
      '</div>'
    ].join('');
  }).join('');
}

/* ============================================================
   HELPERS
   ============================================================ */
function escapeHtml(str) {
  return str.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

function capitalize(str) {
  return str.charAt(0).toUpperCase() + str.slice(1);
}

function getInitials(name) {
  var parts = (name || '').trim().split(/\s+/);
  if (parts.length === 1) return parts[0].slice(0, 2).toUpperCase();
  return (parts[0][0] + parts[parts.length - 1][0]).toUpperCase();
}

/* ============================================================
   TOPBAR PROFILE BUTTON  –  sync with ADMIN_PROFILE
   ============================================================ */
function syncTopbarProfile() {
  var initialsEl = document.getElementById('topbar-avatar-initials');
  var nameEl     = document.getElementById('topbar-profile-name');

  if (nameEl) nameEl.textContent = ADMIN_PROFILE.name.split(' ')[0];

  if (initialsEl) {
    if (ADMIN_PROFILE.photoUrl) {
      initialsEl.innerHTML = '<img src="' + ADMIN_PROFILE.photoUrl + '" alt="Profile" />';
      initialsEl.style.fontSize = '0';
    } else {
      initialsEl.innerHTML = getInitials(ADMIN_PROFILE.name);
      initialsEl.style.fontSize = '';
    }
  }
}

/* ============================================================
   PROFILE MODAL
   ============================================================ */
var profileOverlay  = null;
var pendingPhotoUrl = null;   // holds temp photo URL while user is in edit mode

function initProfileModal() {
  profileOverlay = document.getElementById('profile-modal-overlay');

  var profileBtn    = document.getElementById('profile-btn');
  var closeBtn      = document.getElementById('pmodal-close-btn');
  var editBtn       = document.getElementById('pmodal-edit-btn');
  var cancelBtn     = document.getElementById('pform-cancel-btn');
  var saveBtn       = document.getElementById('pform-save-btn');
  var cameraBtn     = document.getElementById('pmodal-camera-btn');
  var avatarInput   = document.getElementById('avatar-file-input');

  if (!profileOverlay) return;

  /* Open modal */
  profileBtn.addEventListener('click', function() {
    renderViewMode();
    profileOverlay.classList.add('open');
    document.body.style.overflow = 'hidden';
  });

  /* Close on overlay backdrop click */
  profileOverlay.addEventListener('click', function(e) {
    if (e.target === profileOverlay) closeProfileModal();
  });

  /* Close button */
  closeBtn.addEventListener('click', closeProfileModal);

  /* Switch to edit mode */
  editBtn.addEventListener('click', function() {
    renderEditMode();
    document.getElementById('pmodal-view').style.display = 'none';
    document.getElementById('pmodal-edit').style.display = 'flex';
  });

  /* Cancel edit */
  cancelBtn.addEventListener('click', function() {
    pendingPhotoUrl = null;
    document.getElementById('pmodal-edit').style.display = 'none';
    document.getElementById('pmodal-view').style.display = 'flex';
    renderViewMode();
  });

  /* Camera button triggers file input */
  cameraBtn.addEventListener('click', function() {
    avatarInput.click();
  });

  /* Handle photo file selection */
  avatarInput.addEventListener('change', function() {
    var file = avatarInput.files[0];
    if (!file) return;
    if (!file.type.startsWith('image/')) {
      alert('Please select an image file.');
      return;
    }
    var reader = new FileReader();
    reader.onload = function(e) {
      pendingPhotoUrl = e.target.result;
      renderEditAvatarCircle();
    };
    reader.readAsDataURL(file);
    avatarInput.value = '';
  });

  /* Save changes */
  saveBtn.addEventListener('click', function() {
    var nameInput  = document.getElementById('edit-name-input');
    var emailInput = document.getElementById('edit-email-input');
    var deptInput  = document.getElementById('edit-dept-input');

    var newName  = nameInput.value.trim();
    var newEmail = emailInput.value.trim();
    var newDept  = deptInput.value.trim();

    /* Validation */
    var valid = true;
    [nameInput, emailInput, deptInput].forEach(function(inp) { inp.classList.remove('error'); });

    if (!newName)  { nameInput.classList.add('error');  nameInput.focus();  valid = false; }
    if (!newEmail) { emailInput.classList.add('error'); if (valid) emailInput.focus(); valid = false; }
    if (!newDept)  { deptInput.classList.add('error');  if (valid) deptInput.focus();  valid = false; }

    if (!valid) return;

    /* Commit changes */
    ADMIN_PROFILE.name       = newName;
    ADMIN_PROFILE.email      = newEmail;
    ADMIN_PROFILE.department = newDept;
    if (pendingPhotoUrl !== null) ADMIN_PROFILE.photoUrl = pendingPhotoUrl;
    pendingPhotoUrl = null;

    /* Update topbar */
    syncTopbarProfile();

    /* Switch back to view mode */
    document.getElementById('pmodal-edit').style.display = 'none';
    document.getElementById('pmodal-view').style.display = 'flex';
    renderViewMode();
  });

  /* Escape key */
  document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape' && profileOverlay.classList.contains('open')) {
      closeProfileModal();
    }
  });
}

function closeProfileModal() {
  if (!profileOverlay) return;
  pendingPhotoUrl = null;
  profileOverlay.classList.remove('open');
  document.body.style.overflow = '';
  /* Reset back to view mode for next open */
  var viewEl = document.getElementById('pmodal-view');
  var editEl = document.getElementById('pmodal-edit');
  if (viewEl) viewEl.style.display = 'flex';
  if (editEl) editEl.style.display = 'none';
}

/* Render the VIEW mode with current profile data */
function renderViewMode() {
  document.getElementById('view-name').textContent       = ADMIN_PROFILE.name;
  document.getElementById('view-email').textContent      = ADMIN_PROFILE.email;
  document.getElementById('view-department').textContent = ADMIN_PROFILE.department;

  var circle = document.getElementById('view-avatar-circle');
  if (circle) {
    if (ADMIN_PROFILE.photoUrl) {
      circle.innerHTML = '<img src="' + ADMIN_PROFILE.photoUrl + '" alt="Profile photo" />';
    } else {
      circle.innerHTML = getInitials(ADMIN_PROFILE.name);
    }
  }
}

/* Render the EDIT mode pre-filled with current profile data */
function renderEditMode() {
  document.getElementById('edit-name-input').value  = ADMIN_PROFILE.name;
  document.getElementById('edit-email-input').value = ADMIN_PROFILE.email;
  document.getElementById('edit-dept-input').value  = ADMIN_PROFILE.department;
  pendingPhotoUrl = null;
  renderEditAvatarCircle();
}

/* Update edit-mode avatar circle (uses pendingPhotoUrl if set, else saved photo / initials) */
function renderEditAvatarCircle() {
  var circle = document.getElementById('edit-avatar-circle');
  if (!circle) return;
  var url = pendingPhotoUrl !== null ? pendingPhotoUrl : ADMIN_PROFILE.photoUrl;
  if (url) {
    circle.innerHTML = '<img src="' + url + '" alt="Profile photo" />';
  } else {
    circle.innerHTML = getInitials(ADMIN_PROFILE.name);
  }
}

/* ============================================================
   SIDEBAR ACTIVE STATE
   ============================================================ */
function initSidebar() {
  var navItems = document.querySelectorAll('.nav-item');
  var current  = window.location.pathname.split('/').pop();

  navItems.forEach(function(item) {
    var href = (item.getAttribute('href') || '').split('/').pop();
    if (href === current) {
      navItems.forEach(function(n) { n.classList.remove('active'); });
      item.classList.add('active');
    }
    item.addEventListener('click', function(e) {
      var dest = item.getAttribute('href');
      if (!dest || dest === '#') e.preventDefault();
    });
  });
}

/* ============================================================
   UPDATED DOMContentLoaded
   Replace your existing DOMContentLoaded block with this one
   ============================================================ */
document.addEventListener('DOMContentLoaded', function () {
  initSidebar();
  renderStatCards();
  renderAttendanceChart();
  renderAnnouncements();
  syncTopbarProfile();
  initProfileModal();
  initNotifPanel();           /* from notification-additions.js */
  initNotifDetailModal();     /* from notification-additions.js */
  updateNotifBadge();         /* from notification-additions.js */
  initSettingsDropdown();     /* ← NEW */
  initResetPwModal();         /* ← NEW */
  initDeactModal();           /* ← NEW */
});
/* ============================================================
   NOTIFICATION DATA  –  add to top of dashboard.js (or replace
   the CLUB_DATA block area). Each notification has:
     id, title, preview, content, type, recipient, date (display),
     datetime (ISO for sorting), unread, sender { name, role }
   ============================================================ */

var NOTIFICATIONS = [
  {
    id: 1,
    title: 'Annual Tech Fest – Registration Open',
    preview: 'Registrations are now open for all students. Deadline is 5 April 2025.',
    content: 'We are excited to announce that registrations for the Annual Tech Fest 2025 are now officially open! This is a great opportunity for all members to showcase their skills in coding, robotics, and design. Please register before the deadline of 5th April 2025. Participation certificates will be awarded to all attendees.',
    type: 'event',
    recipient: 'Mr. Tashi',
    date: '28 Mar 2025',
    time: '09:30 AM',
    datetime: '2025-03-28T09:30:00',
    unread: true,
    sender: { name: 'Mr. Tobgay', role: 'Club Advisor, Media Club', initials: 'MT' }
  },
  {
    id: 2,
    title: 'Club Meeting Rescheduled to Friday',
    preview: 'The weekly club meeting has been moved to Friday at 3:00 PM in Room 204.',
    content: 'Please be informed that due to a scheduling conflict, this week\'s club meeting has been rescheduled from Thursday to Friday, 28 March 2025, at 3:00 PM. The venue remains the same — Room 204, Block B. Attendance is compulsory for all executive committee members. Kindly inform your team leads accordingly.',
    type: 'notice',
    recipient: 'Mr. Tashi',
    date: '25 Mar 2025',
    time: '11:15 AM',
    datetime: '2025-03-25T11:15:00',
    unread: true,
    sender: { name: 'Mr. Dorji', role: 'Club Secretary, IT Club', initials: 'MD' }
  },
  {
    id: 3,
    title: 'Hackathon 2025 – Winners Announced',
    preview: 'Congratulations to all participants! The results are now published.',
    content: 'We are thrilled to announce the results of Hackathon 2025! After two days of intensive coding and innovation, our judges have selected the top three teams. The full list of winners has been published on the club portal. Prizes and certificates will be distributed during the upcoming club assembly. Congratulations to all participants for their outstanding effort and dedication.',
    type: 'result',
    recipient: 'Mr. Tashi',
    date: '20 Mar 2025',
    time: '02:45 PM',
    datetime: '2025-03-20T14:45:00',
    unread: false,
    sender: { name: 'Ms. Pema', role: 'Event Coordinator, Tech Club', initials: 'MP' }
  },
  {
    id: 4,
    title: 'New Enrollment Key Released for Sem 6',
    preview: 'The enrollment key for Semester 6 is now active. Share with eligible students.',
    content: 'The new enrollment key for Semester 6 has been generated and is now active on the club management portal. Please ensure that only eligible Semester 6 students receive this key. The key will remain valid until 30 April 2025. If you encounter any issues during the enrollment process, please contact the club secretariat immediately.',
    type: 'general',
    recipient: 'Mr. Tashi',
    date: '18 Mar 2025',
    time: '10:00 AM',
    datetime: '2025-03-18T10:00:00',
    unread: false,
    sender: { name: 'Mr. Tobgay', role: 'Club Advisor, Media Club', initials: 'MT' }
  },
  {
    id: 5,
    title: 'Photography Workshop – Sign-up Now',
    preview: 'A 2-day photography workshop is being organised. Limited slots available.',
    content: 'The Media Club is proud to organise a 2-day Photography Workshop on 22–23 March 2025. The workshop will be conducted by a professional photographer and will cover fundamentals of composition, lighting, and post-processing. Slots are limited to 20 participants. Members interested in signing up should submit their names to the club secretary by 19 March 2025.',
    type: 'event',
    recipient: 'Mr. Tashi',
    date: '14 Mar 2025',
    time: '03:00 PM',
    datetime: '2025-03-14T15:00:00',
    unread: false,
    sender: { name: 'Ms. Karma', role: 'Club Secretary, Media Club', initials: 'MK' }
  }
];

/* ============================================================
   ICON MAP (same as ANN_ICONS – reused for notifications)
   ============================================================ */
var NOTIF_ICONS = {
  event:   '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg>',
  notice:  '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>',
  result:  '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>',
  general: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 0 1-3.46 0"/></svg>',
  system:  '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>'
};


/* ============================================================
   NOTIFICATION PANEL – RENDER
   ============================================================ */
function renderNotifPanel() {
  var list   = document.getElementById('notif-list');
  var pill   = document.getElementById('notif-unread-count');
  if (!list) return;

  // Sort newest first (by datetime ISO string)
  var sorted = NOTIFICATIONS.slice().sort(function(a, b) {
    return new Date(b.datetime) - new Date(a.datetime);
  });

  var unreadCount = NOTIFICATIONS.filter(function(n) { return n.unread; }).length;
  if (pill) pill.textContent = unreadCount;

  if (sorted.length === 0) {
    list.innerHTML = [
      '<div class="notif-empty">',
        '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5">',
          '<path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/>',
          '<path d="M13.73 21a2 2 0 0 1-3.46 0"/>',
        '</svg>',
        '<p>No notifications yet.</p>',
      '</div>'
    ].join('');
    return;
  }

  list.innerHTML = sorted.map(function(n) {
    return [
      '<div class="notif-item' + (n.unread ? ' unread' : '') + '" data-id="' + n.id + '">',
        n.unread ? '<div class="notif-unread-dot"></div>' : '',
        '<div class="notif-item-icon type-' + n.type + '">' + (NOTIF_ICONS[n.type] || NOTIF_ICONS.general) + '</div>',
        '<div class="notif-item-body">',
          '<div class="notif-item-title">' + escapeHtml(n.title) + '</div>',
          '<div class="notif-item-preview">' + escapeHtml(n.preview) + '</div>',
          '<div class="notif-item-footer">',
            '<span class="notif-item-time">',
              '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>',
              n.date + ' · ' + n.time,
            '</span>',
            '<button class="notif-view-btn" data-id="' + n.id + '">View full notification</button>',
          '</div>',
        '</div>',
      '</div>'
    ].join('');
  }).join('');

  /* Attach "View full" button listeners */
  list.querySelectorAll('.notif-view-btn').forEach(function(btn) {
    btn.addEventListener('click', function(e) {
      e.stopPropagation();
      var id = parseInt(btn.getAttribute('data-id'));
      openNotifDetail(id);
    });
  });

  /* Mark as read on row click */
  list.querySelectorAll('.notif-item').forEach(function(row) {
    row.addEventListener('click', function() {
      var id = parseInt(row.getAttribute('data-id'));
      markAsRead(id);
    });
  });
}


/* ============================================================
   OPEN / CLOSE NOTIFICATION PANEL
   ============================================================ */
function initNotifPanel() {
  var notifBtn   = document.getElementById('notif-btn');
  var panel      = document.getElementById('notif-panel');
  var backdrop   = document.getElementById('notif-backdrop');
  var markAllBtn = document.getElementById('notif-mark-all-btn');
  var clearAllBtn= document.getElementById('notif-clear-all-btn');

  if (!notifBtn || !panel) return;

  notifBtn.addEventListener('click', function(e) {
    e.stopPropagation();
    var isOpen = panel.classList.contains('open');
    if (isOpen) {
      closeNotifPanel();
    } else {
      openNotifPanel();
    }
  });

  if (backdrop) {
    backdrop.addEventListener('click', closeNotifPanel);
  }

  if (markAllBtn) {
    markAllBtn.addEventListener('click', function() {
      NOTIFICATIONS.forEach(function(n) { n.unread = false; });
      updateNotifBadge();
      renderNotifPanel();
    });
  }

  if (clearAllBtn) {
    clearAllBtn.addEventListener('click', function() {
      NOTIFICATIONS.length = 0;
      renderNotifPanel();
      updateNotifBadge();
    });
  }

  /* Escape to close */
  document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') {
      closeNotifPanel();
      closeNotifDetail();
    }
  });
}

function openNotifPanel() {
  var panel    = document.getElementById('notif-panel');
  var backdrop = document.getElementById('notif-backdrop');
  var notifBtn = document.getElementById('notif-btn');
  renderNotifPanel();
  if (panel)    panel.classList.add('open');
  if (backdrop) backdrop.classList.add('open');
  if (notifBtn) notifBtn.classList.add('notif-active');
}

function closeNotifPanel() {
  var panel    = document.getElementById('notif-panel');
  var backdrop = document.getElementById('notif-backdrop');
  var notifBtn = document.getElementById('notif-btn');
  if (panel)    panel.classList.remove('open');
  if (backdrop) backdrop.classList.remove('open');
  if (notifBtn) notifBtn.classList.remove('notif-active');
}

function markAsRead(id) {
  var notif = NOTIFICATIONS.find(function(n) { return n.id === id; });
  if (notif && notif.unread) {
    notif.unread = false;
    updateNotifBadge();
    renderNotifPanel();
  }
}

function updateNotifBadge() {
  var badge = document.querySelector('#notif-btn .notif-badge');
  var pill  = document.getElementById('notif-unread-count');
  var count = NOTIFICATIONS.filter(function(n) { return n.unread; }).length;

  if (badge) badge.style.display = count > 0 ? '' : 'none';
  if (pill)  pill.textContent = count;
}


/* ============================================================
   NOTIFICATION DETAIL MODAL
   ============================================================ */
function initNotifDetailModal() {
  var overlay     = document.getElementById('notif-detail-overlay');
  var closeBtn    = document.getElementById('nd-close-btn');
  var closeFullBtn= document.getElementById('nd-close-full-btn');

  if (!overlay) return;

  if (closeBtn)     closeBtn.addEventListener('click', closeNotifDetail);
  if (closeFullBtn) closeFullBtn.addEventListener('click', closeNotifDetail);

  overlay.addEventListener('click', function(e) {
    if (e.target === overlay) closeNotifDetail();
  });
}

function openNotifDetail(id) {
  var notif = NOTIFICATIONS.find(function(n) { return n.id === id; });
  if (!notif) return;

  /* Mark as read when opening detail */
  notif.unread = false;
  updateNotifBadge();
  renderNotifPanel();

  /* Populate modal fields */
  var typeBadge   = document.getElementById('nd-type-badge');
  var titleEl     = document.getElementById('nd-title');
  var datetimeEl  = document.getElementById('nd-datetime');
  var greetingEl  = document.getElementById('nd-greeting');
  var contentEl   = document.getElementById('nd-content');
  var avatarEl    = document.getElementById('nd-sender-avatar');
  var senderName  = document.getElementById('nd-sender-name');
  var senderRole  = document.getElementById('nd-sender-role');

  if (typeBadge) {
    typeBadge.textContent = capitalize(notif.type);
    typeBadge.className   = 'ndmodal-type-badge ' + notif.type;
  }
  if (titleEl)    titleEl.textContent    = notif.title;
  if (datetimeEl) datetimeEl.textContent = notif.date + ' · ' + notif.time;
  if (greetingEl) greetingEl.textContent = 'Hi ' + notif.recipient + ',';
  if (contentEl)  contentEl.textContent  = notif.content;
  if (avatarEl)   avatarEl.textContent   = notif.sender.initials;
  if (senderName) senderName.textContent = notif.sender.name;
  if (senderRole) senderRole.textContent = notif.sender.role;

  /* Open overlay */
  var overlay = document.getElementById('notif-detail-overlay');
  if (overlay) {
    overlay.classList.add('open');
    document.body.style.overflow = 'hidden';
  }
}

function closeNotifDetail() {
  var overlay = document.getElementById('notif-detail-overlay');
  if (overlay) {
    overlay.classList.remove('open');
    document.body.style.overflow = '';
  }
}


/* ============================================================
   SETTINGS DROPDOWN
   ============================================================ */
function initSettingsDropdown() {
  var settingsBtn  = document.getElementById('settings-btn');
  var dropdown     = document.getElementById('settings-dropdown');
  var backdrop     = document.getElementById('settings-backdrop');
  // var logoutBtn    = document.getElementById('sdd-logout-btn');
  var resetBtn     = document.getElementById('sdd-reset-btn');
  var deactBtn     = document.getElementById('sdd-deact-btn');

  if (!settingsBtn || !dropdown) return;

  function openSettings() {
    dropdown.classList.add('open');
    backdrop.classList.add('open');
    settingsBtn.classList.add('open');
  }

  function closeSettings() {
    dropdown.classList.remove('open');
    backdrop.classList.remove('open');
    settingsBtn.classList.remove('open');
  }

  settingsBtn.addEventListener('click', function (e) {
    e.stopPropagation();
    dropdown.classList.contains('open') ? closeSettings() : openSettings();
  });

  backdrop.addEventListener('click', closeSettings);

  /* ── Log Out ── */
  // logoutBtn.addEventListener('click', function () {
  //   closeSettings();
  //   doLogout();
  // });

  /* ── Reset Password ── */
  resetBtn.addEventListener('click', function () {
    closeSettings();
    openResetPwModal();
  });

  /* ── Deactivate Account ── */
  deactBtn.addEventListener('click', function () {
    closeSettings();
    openDeactModal();
  });

  /* Escape key */
  document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape') closeSettings();
  });
}


/* ============================================================
   LOG OUT  –  loading screen then redirect
   ============================================================ */
// function doLogout() {
//   var overlay    = document.getElementById('logout-overlay');
//   var statusText = document.getElementById('logout-status-text');
//   if (!overlay) return;

//   var steps = [
//     { delay: 0,    text: 'Signing you out securely…' },
//     { delay: 1500, text: 'Saving session data…' },
//     { delay: 3000, text: 'Clearing credentials…' },
//     { delay: 4500, text: 'Almost done…' }
//   ];

//   overlay.classList.add('open');
//   document.body.style.overflow = 'hidden';

//   steps.forEach(function (s) {
//     setTimeout(function () {
//       if (statusText) statusText.textContent = s.text;
//     }, s.delay);
//   });

  /* Random delay between 3 and 6 seconds total */
//   var redirectDelay = 3000 + Math.floor(Math.random() * 3001);
//   setTimeout(function () {
//     window.location.href = '../html/index.html';   /* ← adjust path to your index.html */
//   }, redirectDelay);
// }


/* ============================================================
   RESET PASSWORD MODAL
   ============================================================ */
var EYE_OPEN  = '<path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/>';
var EYE_CLOSE = '<path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24"/><line x1="1" y1="1" x2="23" y2="23"/>';

/* ── Mock current password ────────────────────────────────────
   IMPORTANT: Replace this with a real API/backend check.
   For demo purposes the correct current password is: Admin@2025
   ─────────────────────────────────────────────────────────── */
var CURRENT_PASSWORD = 'Admin@2025';
var MAX_VERIFY_ATTEMPTS = 3;
 
/* Eye SVG paths */
var EYE_OPEN  = '<path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/>';
var EYE_CLOSE = '<path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24"/><line x1="1" y1="1" x2="23" y2="23"/>';
 
 
/* ============================================================
   INIT – called once on DOMContentLoaded
   ============================================================ */
function initResetPwModal() {
 
  /* ── Step 1 elements ── */
  var verifyBtn     = document.getElementById('rpw-verify-btn');
  var currentInput  = document.getElementById('rpw-current-input');
  var eyeCurrentBtn = document.getElementById('rpw-eye-current');
  var cancelBtn     = document.getElementById('rpw-cancel-btn');
 
  /* ── Step 2 elements ── */
  var newInput      = document.getElementById('rpw-new-input');
  var confirmInput  = document.getElementById('rpw-confirm-input');
  var eyeNewBtn     = document.getElementById('rpw-eye-new');
  var eyeConfBtn    = document.getElementById('rpw-eye-confirm');
  var saveBtn       = document.getElementById('rpw-save-btn');
  var cancelBtn2    = document.getElementById('rpw-cancel-btn-2');
 
  /* ── Modal close ── */
  var overlay  = document.getElementById('reset-pw-overlay');
  var closeBtn = document.getElementById('rpw-close-btn');
 
  if (!overlay) return;
 
  /* Close handlers */
  closeBtn.addEventListener('click',   closeResetPwModal);
  cancelBtn.addEventListener('click',  closeResetPwModal);
  cancelBtn2.addEventListener('click', closeResetPwModal);
  overlay.addEventListener('click', function (e) {
    if (e.target === overlay) closeResetPwModal();
  });
 
  /* Eye toggles – Step 1 */
  eyeCurrentBtn.addEventListener('click', function () {
    toggleEye(currentInput, document.getElementById('rpw-eye-current-icon'));
  });
 
  /* Eye toggles – Step 2 */
  eyeNewBtn.addEventListener('click', function () {
    toggleEye(newInput, document.getElementById('rpw-eye-new-icon'));
  });
  eyeConfBtn.addEventListener('click', function () {
    toggleEye(confirmInput, document.getElementById('rpw-eye-confirm-icon'));
  });
 
  /* Enter key on current password field triggers verify */
  currentInput.addEventListener('keydown', function (e) {
    if (e.key === 'Enter') verifyBtn.click();
  });
 
  /* Live condition checker on Step 2 */
  newInput.addEventListener('input',     updateConditions);
  confirmInput.addEventListener('input', updateConditions);
 
  /* Verify button */
  verifyBtn.addEventListener('click', handleVerifyPassword);
 
  /* Save button */
  saveBtn.addEventListener('click', submitPasswordChange);
}
 
 
/* ============================================================
   STEP 1 – VERIFY CURRENT PASSWORD
   ============================================================ */
var rpwVerifyAttempts = 0;
 
function handleVerifyPassword() {
  var currentInput  = document.getElementById('rpw-current-input');
  var verifyBtn     = document.getElementById('rpw-verify-btn');
  var verifyIcon    = document.getElementById('rpw-verify-icon');
  var attemptHint   = document.getElementById('rpw-attempt-hint');
 
  var entered = currentInput.value;
 
  /* Empty check */
  if (!entered) {
    currentInput.classList.add('error-field');
    showVerifyError('Please enter your current password before continuing.');
    currentInput.focus();
    return;
  }
 
  /* Disable button and show spinner */
  verifyBtn.classList.add('loading');
  verifyBtn.disabled = true;
  currentInput.disabled = true;
  verifyIcon.classList.add('checking');
  hideMsg('rpw-verify-error-msg');
 
  /* Simulate API call delay (replace with real fetch) */
  setTimeout(function () {
 
    verifyBtn.classList.remove('loading');
    currentInput.disabled = false;
 
    /* ── CORRECT PASSWORD ── */
    if (entered === CURRENT_PASSWORD) {
      rpwVerifyAttempts = 0;
      verifyIcon.className = 'rpw-verify-icon verified';
      verifyIcon.innerHTML = [
        '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"',
        '     stroke-linecap="round" stroke-linejoin="round">',
        '  <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>',
        '  <polyline points="9 12 11 14 15 10"/>',
        '</svg>'
      ].join('');
 
      /* Short pause so user sees the verified icon, then advance */
      setTimeout(function () {
        advanceToStep2();
      }, 600);
 
    /* ── WRONG PASSWORD ── */
    } else {
      rpwVerifyAttempts++;
      verifyBtn.disabled = false;
      verifyIcon.className = 'rpw-verify-icon failed';
      verifyIcon.innerHTML = [
        '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"',
        '     stroke-linecap="round" stroke-linejoin="round">',
        '  <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>',
        '  <line x1="15" y1="9" x2="9" y2="15"/>',
        '  <line x1="9" y1="9" x2="15" y2="15"/>',
        '</svg>'
      ].join('');
 
      /* Shake the input */
      currentInput.classList.add('error-field', 'shake');
      setTimeout(function () { currentInput.classList.remove('shake'); }, 500);
 
      var remaining = MAX_VERIFY_ATTEMPTS - rpwVerifyAttempts;
 
      if (remaining <= 0) {
        /* Lock out */
        verifyBtn.disabled = true;
        showVerifyError('Too many failed attempts. Please close and try again later.');
        attemptHint.textContent = 'Account temporarily locked for security.';
        attemptHint.classList.add('visible');
 
        /* Auto-close after 4 s */
        setTimeout(closeResetPwModal, 4000);
 
      } else {
        var msg = remaining === 1
          ? 'Incorrect password. 1 attempt remaining before lockout.'
          : 'Incorrect password. ' + remaining + ' attempts remaining.';
        showVerifyError(msg);
 
        if (rpwVerifyAttempts >= 1) {
          attemptHint.textContent = remaining + ' attempt' + (remaining === 1 ? '' : 's') + ' left';
          attemptHint.classList.add('visible');
        }
      }
 
      /* Reset icon back to shield after a moment */
      setTimeout(function () {
        verifyIcon.className = 'rpw-verify-icon';
        verifyIcon.innerHTML = [
          '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"',
          '     stroke-linecap="round" stroke-linejoin="round">',
          '  <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>',
          '</svg>'
        ].join('');
      }, 1200);
    }
 
  }, 900); /* simulated network delay */
}
 
function showVerifyError(message) {
  document.getElementById('rpw-verify-error-text').textContent = message;
  showMsg('rpw-verify-error-msg');
}
 
function advanceToStep2() {
  /* Update step indicators */
  var step1Ind   = document.getElementById('rpw-step-ind-1');
  var step2Ind   = document.getElementById('rpw-step-ind-2');
  var connector  = document.getElementById('rpw-step-connector');
  var panel1     = document.getElementById('rpw-panel-1');
  var panel2     = document.getElementById('rpw-panel-2');
 
  step1Ind.classList.remove('active');
  step1Ind.classList.add('done');
  step2Ind.classList.add('active');
  connector.classList.add('filled');
 
  panel1.classList.remove('active');
  panel2.classList.add('active', 'slide-left');
 
  /* Focus new password field */
  setTimeout(function () {
    var inp = document.getElementById('rpw-new-input');
    if (inp) inp.focus();
  }, 300);
}
 
 
/* ============================================================
   STEP 2 – NEW PASSWORD LOGIC
   ============================================================ */
function updateConditions() {
  var val     = (document.getElementById('rpw-new-input') || {}).value || '';
  var confVal = (document.getElementById('rpw-confirm-input') || {}).value || '';
 
  setCondition('cond-length',  val.length >= 8);
  setCondition('cond-upper',   /[A-Z]/.test(val));
  setCondition('cond-digit',   /[0-9]/.test(val));
  setCondition('cond-special', /[^A-Za-z0-9]/.test(val));
  setCondition('cond-match',   val.length > 0 && val === confVal);
}
 
function setCondition(id, met) {
  var el = document.getElementById(id);
  if (!el) return;
  el.classList.toggle('met', met);
  if (met) el.classList.remove('fail');
}
 
function submitPasswordChange() {
  var newPw  = (document.getElementById('rpw-new-input') || {}).value || '';
  var confPw = (document.getElementById('rpw-confirm-input') || {}).value || '';
 
  hideMsg('rpw-error-msg');
  hideMsg('rpw-success-msg');
 
  var newInput     = document.getElementById('rpw-new-input');
  var confirmInput = document.getElementById('rpw-confirm-input');
  newInput.classList.remove('error-field', 'success-field');
  confirmInput.classList.remove('error-field', 'success-field');
 
  /* Validation */
  if (newPw.length < 8) {
    markCondFail('cond-length');
    newInput.classList.add('error-field');
    return showError('rpw-error-msg', 'rpw-error-text',
      'Password must be at least 8 characters long.');
  }
  if (!/[A-Z]/.test(newPw)) {
    markCondFail('cond-upper');
    newInput.classList.add('error-field');
    return showError('rpw-error-msg', 'rpw-error-text',
      'Password must contain at least one uppercase letter (A–Z).');
  }
  if (!/[0-9]/.test(newPw)) {
    markCondFail('cond-digit');
    newInput.classList.add('error-field');
    return showError('rpw-error-msg', 'rpw-error-text',
      'Password must contain at least one digit (0–9).');
  }
  if (/^[A-Za-z0-9]*$/.test(newPw)) {
    markCondFail('cond-special');
    newInput.classList.add('error-field');
    return showError('rpw-error-msg', 'rpw-error-text',
      'Password must contain at least one special character (e.g. !@#$%^&*).');
  }
  if (newPw !== confPw) {
    confirmInput.classList.add('error-field');
    markCondFail('cond-match');
    return showError('rpw-error-msg', 'rpw-error-text',
      'Passwords do not match. Please re-enter your confirm password.');
  }
 
  /* All valid */
  newInput.classList.add('success-field');
  confirmInput.classList.add('success-field');
 
  var saveBtn = document.getElementById('rpw-save-btn');
  saveBtn.disabled = true;
  saveBtn.textContent = 'Updating…';
 
  setTimeout(function () {
    /* ── Commit: update mock stored password so it matches new one ── */
    CURRENT_PASSWORD = newPw;
 
    showMsg('rpw-success-msg');
    saveBtn.disabled = false;
    saveBtn.innerHTML = [
      '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"',
      '     stroke-linecap="round" stroke-linejoin="round" width="15" height="15">',
      '  <rect x="3" y="11" width="18" height="11" rx="2" ry="2"/>',
      '  <path d="M7 11V7a5 5 0 0 1 10 0v4"/>',
      '</svg> Update Password'
    ].join('');
 
    /* Auto-close after success */
    setTimeout(closeResetPwModal, 2500);
  }, 900);
}
 
function markCondFail(id) {
  var el = document.getElementById(id);
  if (!el) return;
  el.classList.remove('met');
  el.classList.add('fail');
}
 
function showError(msgId, textId, message) {
  document.getElementById(textId).textContent = message;
  showMsg(msgId);
}
 
function showMsg(id) {
  var el = document.getElementById(id);
  if (el) el.classList.add('visible');
}
 
function hideMsg(id) {
  var el = document.getElementById(id);
  if (el) el.classList.remove('visible');
}
 
 
/* ============================================================
   OPEN / CLOSE MODAL
   ============================================================ */
function openResetPwModal() {
  resetResetPwModal();
  var overlay = document.getElementById('reset-pw-overlay');
  if (overlay) {
    overlay.classList.add('open');
    document.body.style.overflow = 'hidden';
    setTimeout(function () {
      var inp = document.getElementById('rpw-current-input');
      if (inp) inp.focus();
    }, 300);
  }
}
 
function closeResetPwModal() {
  var overlay = document.getElementById('reset-pw-overlay');
  if (overlay) {
    overlay.classList.remove('open');
    document.body.style.overflow = '';
  }
  /* Reset after close animation */
  setTimeout(resetResetPwModal, 250);
}
 
function resetResetPwModal() {
  rpwVerifyAttempts = 0;
 
  /* Reset step indicators back to step 1 */
  var step1Ind   = document.getElementById('rpw-step-ind-1');
  var step2Ind   = document.getElementById('rpw-step-ind-2');
  var connector  = document.getElementById('rpw-step-connector');
  var panel1     = document.getElementById('rpw-panel-1');
  var panel2     = document.getElementById('rpw-panel-2');
 
  if (step1Ind)  { step1Ind.className  = 'rpw-step active'; }
  if (step2Ind)  { step2Ind.className  = 'rpw-step'; }
  if (connector) { connector.classList.remove('filled'); }
  if (panel1)    { panel1.className  = 'rpw-step-panel active'; }
  if (panel2)    { panel2.className  = 'rpw-step-panel'; }
 
  /* Reset verify icon */
  var verifyIcon = document.getElementById('rpw-verify-icon');
  if (verifyIcon) {
    verifyIcon.className = 'rpw-verify-icon';
    verifyIcon.innerHTML = [
      '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"',
      '     stroke-linecap="round" stroke-linejoin="round">',
      '  <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>',
      '</svg>'
    ].join('');
  }
 
  /* Clear all inputs */
  ['rpw-current-input', 'rpw-new-input', 'rpw-confirm-input'].forEach(function (id) {
    var inp = document.getElementById(id);
    if (inp) {
      inp.value = '';
      inp.type  = 'password';
      inp.classList.remove('error-field', 'success-field');
      inp.disabled = false;
    }
  });
 
  /* Reset eye icons */
  ['rpw-eye-current-icon', 'rpw-eye-new-icon', 'rpw-eye-confirm-icon'].forEach(function (id) {
    var ic = document.getElementById(id);
    if (ic) ic.innerHTML = EYE_OPEN;
  });
 
  /* Reset attempt hint */
  var hint = document.getElementById('rpw-attempt-hint');
  if (hint) { hint.textContent = ''; hint.classList.remove('visible'); }
 
  /* Reset verify button */
  var vBtn = document.getElementById('rpw-verify-btn');
  if (vBtn) { vBtn.disabled = false; vBtn.classList.remove('loading'); }
 
  /* Reset save button */
  var sBtn = document.getElementById('rpw-save-btn');
  if (sBtn) {
    sBtn.disabled = false;
    sBtn.innerHTML = [
      '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"',
      '     stroke-linecap="round" stroke-linejoin="round" width="15" height="15">',
      '  <rect x="3" y="11" width="18" height="11" rx="2" ry="2"/>',
      '  <path d="M7 11V7a5 5 0 0 1 10 0v4"/>',
      '</svg> Update Password'
    ].join('');
  }
 
  /* Reset conditions */
  ['cond-length','cond-upper','cond-digit','cond-special','cond-match'].forEach(function (id) {
    var el = document.getElementById(id);
    if (el) el.classList.remove('met', 'fail');
  });
 
  /* Hide all messages */
  ['rpw-verify-error-msg','rpw-error-msg','rpw-success-msg'].forEach(hideMsg);
}
 
/* Eye toggle helper */
function toggleEye(inputEl, iconEl) {
  if (!inputEl || !iconEl) return;
  var isPassword = inputEl.type === 'password';
  inputEl.type   = isPassword ? 'text' : 'password';
  iconEl.innerHTML = isPassword ? EYE_CLOSE : EYE_OPEN;
}

/* ============================================================
   DEACTIVATE ACCOUNT MODAL
   ============================================================ */
function initDeactModal() {
  var overlay    = document.getElementById('deact-overlay');
  var closeBtn   = document.getElementById('dact-close-btn');
  var cancelBtn  = document.getElementById('dact-cancel-btn');
  var confirmBtn = document.getElementById('dact-confirm-btn');
  var okBtn      = document.getElementById('dact-ok-btn');

  if (!overlay) return;

  closeBtn.addEventListener('click',  closeDeactModal);
  cancelBtn.addEventListener('click', closeDeactModal);
  okBtn.addEventListener('click',     closeDeactModal);

  overlay.addEventListener('click', function (e) {
    if (e.target === overlay) closeDeactModal();
  });

  confirmBtn.addEventListener('click', function () {
    /* Show the success/result screen */
    document.getElementById('dact-confirm-body').style.display = 'none';
    document.getElementById('dact-close-btn').style.display    = 'none';
    document.getElementById('dact-success-body').classList.add('visible');
  });
}

function openDeactModal() {
  var overlay      = document.getElementById('deact-overlay');
  var confirmBody  = document.getElementById('dact-confirm-body');
  var successBody  = document.getElementById('dact-success-body');
  var closeBtn     = document.getElementById('dact-close-btn');

  /* Reset to confirm state */
  if (confirmBody) confirmBody.style.display = '';
  if (successBody) successBody.classList.remove('visible');
  if (closeBtn)    closeBtn.style.display = '';

  if (overlay) {
    overlay.classList.add('open');
    document.body.style.overflow = 'hidden';
  }
}

function closeDeactModal() {
  var overlay = document.getElementById('deact-overlay');
  if (overlay) {
    overlay.classList.remove('open');
    document.body.style.overflow = '';
  }
}


