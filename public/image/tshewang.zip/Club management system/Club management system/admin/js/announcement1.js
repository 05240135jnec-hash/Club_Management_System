'use strict';

var ANNOUNCEMENTS = [
  { id: 1, type: 'general',  title: 'Campus Maintenance Notice',   content: 'Please be informed that the main library will be closed for maintenance from Oct 25 to Oct 27, 2023. All students and staff are advised to plan accordingly.',                                                           recipients: 'Both',    dateSent: 'Oct 24, 2023 09:15 AM', attachments: [] },
  { id: 2, type: 'reminder', title: 'End of Term Club Reports',    content: 'All club advisers are required to submit their annual club reports by Nov 1, 2023. Please use the standard report template available on the portal.',                                                                          recipients: 'Members', dateSent: 'Oct 20, 2023 02:30 PM', attachments: [] },
  { id: 3, type: 'event',    title: 'Club Registration Open',      content: 'New student club registrations are now open for the upcoming semester. Students interested in forming new clubs should submit their proposals to the admin office.',                                                              recipients: 'Students',dateSent: 'Oct 15, 2023 10:00 AM', attachments: [] }
];
var nextId = 4;

var annTitle       = document.getElementById('ann-title');
var annType        = document.getElementById('ann-type');
var annContent     = document.getElementById('ann-content');
var chkMembers     = document.getElementById('chk-members');
var chkStudents    = document.getElementById('chk-students');
var postBtn        = document.getElementById('post-btn');
var historySearch  = document.getElementById('history-search');
var historyBody    = document.getElementById('history-table-body');
var fileInput      = document.getElementById('file-input');
var fileDropZone   = document.getElementById('file-drop-zone');
var fileListEl     = document.getElementById('file-list');
var hamburgerBtn   = document.getElementById('hamburger-btn');
var sidebar        = document.getElementById('sidebar');
var sidebarOverlay = document.getElementById('sidebar-overlay');
var attachedFiles  = [];

/* ── File list ── */
function renderFileList() {
  if (!attachedFiles.length) { fileListEl.innerHTML = ''; return; }
  var html = '';
  attachedFiles.forEach(function(f, i) {
    html += '<div class="file-item"><span class="file-item-name">'
      + '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">'
      + '<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/>'
      + '<polyline points="14 2 14 8 20 8"/></svg>'
      + f.name + '</span>'
      + '<button class="file-remove-btn" data-idx="' + i + '">'
      + '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">'
      + '<line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>'
      + '</button></div>';
  });
  fileListEl.innerHTML = html;
  fileListEl.querySelectorAll('.file-remove-btn').forEach(function(btn) {
    btn.addEventListener('click', function() {
      attachedFiles.splice(parseInt(btn.dataset.idx, 10), 1);
      renderFileList();
    });
  });
}

if (fileInput) {
  fileInput.addEventListener('change', function() {
    Array.from(fileInput.files).forEach(function(f) { attachedFiles.push(f); });
    fileInput.value = '';
    renderFileList();
  });
}

if (fileDropZone) {
  fileDropZone.addEventListener('dragover', function(e) {
    e.preventDefault();
    fileDropZone.classList.add('dragover');
  });
  fileDropZone.addEventListener('dragleave', function() {
    fileDropZone.classList.remove('dragover');
  });
  fileDropZone.addEventListener('drop', function(e) {
    e.preventDefault();
    fileDropZone.classList.remove('dragover');
    Array.from(e.dataTransfer.files).forEach(function(f) { attachedFiles.push(f); });
    renderFileList();
  });
  fileDropZone.addEventListener('click', function(e) {
    if (e.target.tagName === 'LABEL' || e.target.closest('label')) return;
    fileInput.click();
  });
}

/* ── View detail (triggered by row click) ── */
function showViewModal(ann) {
  var typeLabel = ann.type ? (ann.type.charAt(0).toUpperCase() + ann.type.slice(1)) : '—';
  var attachHTML = ann.attachments && ann.attachments.length
    ? '<div style="margin-top:12px;font-size:12px;color:#8892a4;">Attachments: ' + ann.attachments.join(', ') + '</div>'
    : '';
  Swal.fire({
    title: ann.title,
    html: '<div style="text-align:left;">'
      + '<div style="font-size:12px;color:#8892a4;margin-bottom:10px;">'
      + '<strong>Type:</strong> ' + typeLabel
      + ' &nbsp;|&nbsp; <strong>To:</strong> ' + ann.recipients
      + ' &nbsp;|&nbsp; ' + ann.dateSent
      + '</div>'
      + '<div style="font-size:13.5px;color:#4a5568;line-height:1.7;">' + ann.content + '</div>'
      + attachHTML + '</div>',
    confirmButtonColor: '#2d5be3',
    confirmButtonText: 'Close',
    width: '520px'
  });
}

/* ── Edit modal ── */
function showEditModal(ann) {
  var typeOptions = ['event', 'general', 'reminder'].map(function(t) {
    var label = t.charAt(0).toUpperCase() + t.slice(1);
    var sel = ann.type === t ? ' selected' : '';
    return '<option value="' + t + '"' + sel + '>' + label + '</option>';
  }).join('');

  Swal.fire({
    title: '<span style="font-size:16px;font-weight:700;color:#1a1a2e;">Edit Announcement</span>',
    width: '560px',
    html:
      '<div style="text-align:left;display:flex;flex-direction:column;gap:14px;">'

      /* Title */
      + '<div>'
      + '<label style="display:block;font-size:13px;font-weight:600;color:#4a5568;margin-bottom:6px;">Title</label>'
      + '<input id="edit-title" value="' + escHtml(ann.title) + '" '
      + 'style="width:100%;height:40px;border:1px solid #e2e6ef;border-radius:8px;padding:0 14px;font-size:13px;color:#4a5568;background:#f8f9fb;outline:none;font-family:inherit;">'
      + '</div>'

      /* Type */
      + '<div>'
      + '<label style="display:block;font-size:13px;font-weight:600;color:#4a5568;margin-bottom:6px;">Announcement Type</label>'
      + '<select id="edit-type" style="width:100%;height:40px;border:1px solid #e2e6ef;border-radius:8px;padding:0 14px;font-size:13px;color:#4a5568;background:#f8f9fb;outline:none;font-family:inherit;">'
      + typeOptions
      + '</select>'
      + '</div>'

      /* Content */
      + '<div>'
      + '<label style="display:block;font-size:13px;font-weight:600;color:#4a5568;margin-bottom:6px;">Content</label>'
      + '<textarea id="edit-content" rows="4" '
      + 'style="width:100%;border:1px solid #e2e6ef;border-radius:8px;padding:10px 14px;font-size:13px;color:#4a5568;background:#f8f9fb;outline:none;font-family:inherit;resize:vertical;">'
      + escHtml(ann.content)
      + '</textarea>'
      + '</div>'

      /* Recipients */
      + '<div>'
      + '<label style="display:block;font-size:13px;font-weight:600;color:#4a5568;margin-bottom:8px;">Send To</label>'
      + '<div style="display:flex;gap:20px;">'
      + '<label style="display:flex;align-items:center;gap:7px;font-size:13px;color:#4a5568;cursor:pointer;">'
      + '<input type="checkbox" id="edit-members" ' + (ann.recipients === 'Members' || ann.recipients === 'Both' ? 'checked' : '') + '> Members'
      + '</label>'
      + '<label style="display:flex;align-items:center;gap:7px;font-size:13px;color:#4a5568;cursor:pointer;">'
      + '<input type="checkbox" id="edit-students" ' + (ann.recipients === 'Students' || ann.recipients === 'Both' ? 'checked' : '') + '> Students'
      + '</label>'
      + '</div>'
      + '</div>'

      + '</div>',

    showCancelButton: true,
    confirmButtonColor: '#172D3D',
    cancelButtonColor: '#8892a4',
    confirmButtonText: 'Save Changes',
    cancelButtonText: 'Cancel',
    customClass: { confirmButton: 'swal-confirm-gold' },
    preConfirm: function() {
      var newTitle   = document.getElementById('edit-title').value.trim();
      var newType    = document.getElementById('edit-type').value;
      var newContent = document.getElementById('edit-content').value.trim();
      var toMembers  = document.getElementById('edit-members').checked;
      var toStudents = document.getElementById('edit-students').checked;

      if (!newTitle) {
        Swal.showValidationMessage('Please enter a title.');
        return false;
      }
      if (!newContent) {
        Swal.showValidationMessage('Please enter the announcement content.');
        return false;
      }
      if (!toMembers && !toStudents) {
        Swal.showValidationMessage('Please select at least one recipient group.');
        return false;
      }
      return {
        title:      newTitle,
        type:       newType,
        content:    newContent,
        recipients: toMembers && toStudents ? 'Both' : toMembers ? 'Members' : 'Students'
      };
    }
  }).then(function(result) {
    if (result.isConfirmed && result.value) {
      var idx = ANNOUNCEMENTS.findIndex(function(a) { return a.id === ann.id; });
      if (idx !== -1) {
        ANNOUNCEMENTS[idx].title      = result.value.title;
        ANNOUNCEMENTS[idx].type       = result.value.type;
        ANNOUNCEMENTS[idx].content    = result.value.content;
        ANNOUNCEMENTS[idx].recipients = result.value.recipients;
      }
      renderHistory(historySearch.value);
      Swal.fire({
        title: 'Updated!',
        text: '"' + result.value.title + '" has been updated.',
        icon: 'success',
        confirmButtonColor: '#2bb5a0',
        timer: 2000,
        timerProgressBar: true
      });
    }
  });
}

/* ── Render history table ── */
function renderHistory(filter) {
  filter = (filter || '').toLowerCase().trim();
  var filtered = ANNOUNCEMENTS.filter(function(a) {
    return a.title.toLowerCase().indexOf(filter) !== -1
      || a.content.toLowerCase().indexOf(filter) !== -1
      || a.recipients.toLowerCase().indexOf(filter) !== -1;
  });
  if (!filtered.length) {
    historyBody.innerHTML = '<tr class="empty-row"><td colspan="3">No announcements found</td></tr>';
    return;
  }
  var html = '';
  filtered.forEach(function(ann) {
    var preview = ann.content.length > 60 ? ann.content.substring(0, 60) + '...' : ann.content;
    html += '<tr class="clickable-row" data-id="' + ann.id + '">'

      /* Title + preview + date */
      + '<td>'
      + '<div class="ann-title-text">' + ann.title + '</div>'
      + '<div class="ann-preview">' + preview + '</div>'
      + '<div class="ann-date">'
      + '<svg viewBox="0 0 24 24" width="11" height="11" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">'
      + '<rect x="3" y="4" width="18" height="18" rx="2" ry="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/>'
      + '</svg>'
      + ann.dateSent
      + '</div>'
      + '</td>'

      /* Action buttons */
      + '<td><div class="action-cell">'
      + '<button class="edit-btn" data-id="' + ann.id + '">Edit</button>'
      + '<button class="remove-btn" data-id="' + ann.id + '">Delete</button>'
      + '</div></td>'

      /* Recipient badge */
      + '<td><span class="recipient-badge">' + ann.recipients + '</span></td>'

      + '</tr>';
  });
  historyBody.innerHTML = html;
  attachHistoryEvents();
}

/* ── Attach row / button events ── */
function attachHistoryEvents() {

  /* Row click → view detail (ignore clicks on action buttons) */
  historyBody.querySelectorAll('tr.clickable-row').forEach(function(row) {
    row.addEventListener('click', function(e) {
      if (e.target.closest('button')) return;
      var id = parseInt(row.dataset.id, 10);
      var ann = ANNOUNCEMENTS.find(function(a) { return a.id === id; });
      if (ann) showViewModal(ann);
    });
  });

  /* Edit button */
  historyBody.querySelectorAll('.edit-btn').forEach(function(btn) {
    btn.addEventListener('click', function(e) {
      e.stopPropagation();
      var id = parseInt(btn.dataset.id, 10);
      var ann = ANNOUNCEMENTS.find(function(a) { return a.id === id; });
      if (ann) showEditModal(ann);
    });
  });

  /* Remove button */
  historyBody.querySelectorAll('.remove-btn').forEach(function(btn) {
    btn.addEventListener('click', function(e) {
      e.stopPropagation();
      var id = parseInt(btn.dataset.id, 10);
      var ann = ANNOUNCEMENTS.find(function(a) { return a.id === id; });
      if (!ann) return;
      Swal.fire({
        title: 'Remove Announcement?',
        text: 'Are you sure you want to remove "' + ann.title + '"? This cannot be undone.',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#e53e3e',
        cancelButtonColor: '#8892a4',
        confirmButtonText: 'Yes, remove it',
        cancelButtonText: 'Cancel'
      }).then(function(result) {
        if (result.isConfirmed) {
          var idx = ANNOUNCEMENTS.findIndex(function(a) { return a.id === id; });
          if (idx !== -1) ANNOUNCEMENTS.splice(idx, 1);
          renderHistory(historySearch.value);
          Swal.fire({
            title: 'Removed!',
            text: '"' + ann.title + '" has been removed.',
            icon: 'success',
            confirmButtonColor: '#2bb5a0',
            timer: 2000,
            timerProgressBar: true
          });
        }
      });
    });
  });
}

/* ── Post announcement ── */
if (postBtn) {
  postBtn.addEventListener('click', function() {
    var title      = (annTitle.value   || '').trim();
    var type       = (annType.value    || '').trim();
    var content    = (annContent.value || '').trim();
    var toMembers  = chkMembers.checked;
    var toStudents = chkStudents.checked;

    if (!title) {
      Swal.fire({ icon: 'warning', title: 'Title required', text: 'Please enter an announcement title.', confirmButtonColor: '#2d5be3' });
      return;
    }
    if (!content) {
      Swal.fire({ icon: 'warning', title: 'Content required', text: 'Please enter the announcement content.', confirmButtonColor: '#2d5be3' });
      return;
    }
    if (!toMembers && !toStudents) {
      Swal.fire({ icon: 'warning', title: 'Select recipients', text: 'Please select at least one recipient group.', confirmButtonColor: '#2d5be3' });
      return;
    }

    var recipients = toMembers && toStudents ? 'Both' : toMembers ? 'Members' : 'Students';
    var now = new Date();
    var months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
    var hours = now.getHours();
    var ampm = hours >= 12 ? 'PM' : 'AM';
    hours = hours % 12 || 12;
    var mins = now.getMinutes().toString().padStart(2, '0');
    var dateSent = months[now.getMonth()] + ' ' + now.getDate() + ', ' + now.getFullYear() + ' ' + hours + ':' + mins + ' ' + ampm;

    ANNOUNCEMENTS.unshift({
      id: nextId++,
      type: type || 'general',
      title: title,
      content: content,
      recipients: recipients,
      dateSent: dateSent,
      attachments: attachedFiles.map(function(f) { return f.name; })
    });

    annTitle.value = '';
    annType.value  = '';
    annContent.value = '';
    chkMembers.checked = false;
    chkStudents.checked = false;
    attachedFiles = [];
    renderFileList();
    renderHistory(historySearch.value);

    Swal.fire({
      title: 'Announcement Posted!',
      text: '"' + title + '" has been sent to ' + recipients + '.',
      icon: 'success',
      confirmButtonColor: '#2bb5a0',
      timer: 2500,
      timerProgressBar: true
    });
  });
}

if (historySearch) {
  historySearch.addEventListener('input', function() {
    renderHistory(historySearch.value);
  });
}

/* ── Sidebar ── */
function openSidebar() {
  if (sidebar) sidebar.classList.add('open');
  if (sidebarOverlay) {
    sidebarOverlay.style.display = 'block';
    setTimeout(function() { sidebarOverlay.classList.add('active'); }, 10);
  }
  document.body.style.overflow = 'hidden';
}

function closeSidebar() {
  if (sidebar) sidebar.classList.remove('open');
  if (sidebarOverlay) {
    sidebarOverlay.classList.remove('active');
    setTimeout(function() { sidebarOverlay.style.display = 'none'; }, 280);
  }
  document.body.style.overflow = '';
}

if (hamburgerBtn) {
  hamburgerBtn.addEventListener('click', function() {
    sidebar && sidebar.classList.contains('open') ? closeSidebar() : openSidebar();
  });
}
if (sidebarOverlay) {
  sidebarOverlay.addEventListener('click', closeSidebar);
}

document.querySelectorAll('.nav-item').forEach(function(item) {
  item.addEventListener('click', function(e) {
    if (item.getAttribute('href') === '#') e.preventDefault();
    document.querySelectorAll('.nav-item').forEach(function(n) { n.classList.remove('active'); });
    item.classList.add('active');
    if (window.innerWidth <= 768) closeSidebar();
  });
});

/* ── Utility ── */
function escHtml(str) {
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

document.addEventListener('DOMContentLoaded', function() {
  renderHistory();
});