'use strict';

/* ══════════════════════════════════════════════════════════
   JNEC Club Management — Invite Co-Adviser JS
   Pending rows: email + time + Pending badge + cancel only.
   No Accept button in UI — co-adviser accepts via email link.
   In production, replace state arrays with real API calls.
══════════════════════════════════════════════════════════ */

/* ─── STATE ─────────────────────────────────────────────── */
var pendingInvites   = [];   // { id, email, sentAt }
var activeCoAdvisers = [];   // { id, email, acceptedAt }
var pendingRevoke    = null; // id of row being revoked

/* ─── DOM REFS ───────────────────────────────────────────── */
var emailInput      = document.getElementById('email-input');
var emailError      = document.getElementById('email-error');
var sendBtn         = document.getElementById('send-btn');

var pendingList     = document.getElementById('pending-list');
var pendingEmpty    = document.getElementById('pending-empty');
var activeList      = document.getElementById('active-list');
var activeEmpty     = document.getElementById('active-empty');

var confirmBackdrop = document.getElementById('confirm-backdrop');
var confirmEmail    = document.getElementById('confirm-email');
var btnCancel       = document.getElementById('btn-cancel');
var btnConfirmSend  = document.getElementById('btn-confirm-send');

var revokeBackdrop  = document.getElementById('revoke-backdrop');
var revokeTitle     = document.getElementById('revoke-title');
var revokeDesc      = document.getElementById('revoke-desc');
var btnRevokeCancel = document.getElementById('btn-revoke-cancel');
var btnRevokeConfirm= document.getElementById('btn-revoke-confirm');

var toast           = document.getElementById('toast');
var toastMsg        = document.getElementById('toast-msg');
var toastIcon       = document.getElementById('toast-icon');
var toastTimer      = null;

var hamburgerBtn    = document.getElementById('hamburger-btn');
var sidebar         = document.getElementById('sidebar');
var sidebarOverlay  = document.getElementById('sidebar-overlay');

/* Temp storage for confirm flow */
var pendingForm = { email: '' };

/* ══════════════════════════════════════════════════════════
   HELPERS
══════════════════════════════════════════════════════════ */
function uid() {
  return Date.now().toString(36) + Math.random().toString(36).substr(2, 5);
}

function getInitials(email) {
  var local = email.split('@')[0];
  var parts = local.replace(/[._\-]/g, ' ').trim().split(/\s+/);
  if (parts.length === 1) return parts[0].substring(0, 2).toUpperCase();
  return (parts[0][0] + parts[parts.length - 1][0]).toUpperCase();
}

function formatTime(isoStr) {
  var d = new Date(isoStr);
  return d.toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' })
    + ' at '
    + d.toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' });
}

function escHtml(str) {
  return String(str)
    .replace(/&/g, '&amp;').replace(/</g, '&lt;')
    .replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

function showToast(message, type) {
  toast.className = 'toast show toast-' + (type || 'success');
  toastIcon.textContent = type === 'error' ? '⚠️' : '✅';
  toastMsg.textContent  = message;
  if (toastTimer) clearTimeout(toastTimer);
  toastTimer = setTimeout(function() { toast.classList.remove('show'); }, 3500);
}

function isValidEmail(val) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(val.trim());
}

/* ══════════════════════════════════════════════════════════
   VALIDATION
══════════════════════════════════════════════════════════ */
function clearErrors() {
  emailInput.classList.remove('err');
  emailError.style.display = 'none';
}

function validateForm() {
  clearErrors();
  var emailVal = emailInput.value.trim();

  if (!emailVal) {
    emailInput.classList.add('err');
    emailError.textContent = 'Please enter an email address.';
    emailError.style.display = 'block';
    return false;
  }
  if (!isValidEmail(emailVal)) {
    emailInput.classList.add('err');
    emailError.textContent = 'Please enter a valid email address (e.g. name@jnec.edu.bt).';
    emailError.style.display = 'block';
    return false;
  }

  var alreadyPending = pendingInvites.some(function(p) {
    return p.email.toLowerCase() === emailVal.toLowerCase();
  });
  var alreadyActive = activeCoAdvisers.some(function(a) {
    return a.email.toLowerCase() === emailVal.toLowerCase();
  });

  if (alreadyPending) {
    emailInput.classList.add('err');
    emailError.textContent = 'An invitation has already been sent to this email address.';
    emailError.style.display = 'block';
    return false;
  }
  if (alreadyActive) {
    emailInput.classList.add('err');
    emailError.textContent = 'This person is already an active co-adviser.';
    emailError.style.display = 'block';
    return false;
  }

  return true;
}

/* ══════════════════════════════════════════════════════════
   RENDER — Pending Invitations
   Shows: avatar initials | email + sent time | Pending badge | cancel (×)
   NO Accept button — acceptance happens via email link only
══════════════════════════════════════════════════════════ */
function renderPending() {
  var rows = pendingList.querySelectorAll('.pending-row');
  rows.forEach(function(r) { r.remove(); });

  if (pendingInvites.length === 0) {
    pendingEmpty.classList.remove('hidden');
    return;
  }
  pendingEmpty.classList.add('hidden');

  pendingInvites.forEach(function(inv) {
    var row = document.createElement('div');
    row.className = 'pending-row';
    row.setAttribute('data-id', inv.id);

    row.innerHTML =
      '<div class="pending-avatar">' + escHtml(getInitials(inv.email)) + '</div>'
      + '<div class="pending-info">'
        + '<div class="pending-email">' + escHtml(inv.email) + '</div>'
        + '<div class="pending-time">Sent ' + escHtml(formatTime(inv.sentAt)) + '</div>'
      + '</div>'
      + '<div class="pending-badge">Pending</div>'
      + '<button class="cancel-invite-btn" data-cancel="' + inv.id + '" title="Cancel invitation">'
        + '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">'
          + '<line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>'
        + '</svg>'
      + '</button>';

    pendingList.appendChild(row);

    /* Cancel invitation */
    row.querySelector('[data-cancel]').addEventListener('click', function() {
      var id = this.getAttribute('data-cancel');
      pendingInvites = pendingInvites.filter(function(p) { return p.id !== id; });
      renderPending();
      showToast('Invitation cancelled.', 'error');
    });
  });
}

/* ══════════════════════════════════════════════════════════
   RENDER — Active Co-Advisers
   Shows only after co-adviser accepts via email link (backend sets this).
   Row: avatar initials | email + accepted date | Remove button
   No active badge shown.
══════════════════════════════════════════════════════════ */
function renderActive() {
  var rows = activeList.querySelectorAll('.active-row');
  rows.forEach(function(r) { r.remove(); });

  if (activeCoAdvisers.length === 0) {
    activeEmpty.classList.remove('hidden');
    return;
  }
  activeEmpty.classList.add('hidden');

  activeCoAdvisers.forEach(function(adv) {
    var row = document.createElement('div');
    row.className = 'active-row';
    row.setAttribute('data-id', adv.id);

    row.innerHTML =
      '<div class="active-avatar">' + escHtml(getInitials(adv.email)) + '</div>'
      + '<div class="active-info">'
        + '<div class="active-email">' + escHtml(adv.email) + '</div>'
        + '<div class="active-since">Co-advising since ' + escHtml(formatTime(adv.acceptedAt)) + '</div>'
      + '</div>'
      + '<button class="revoke-btn" data-revoke="' + adv.id + '">'
        + '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">'
          + '<polyline points="3 6 5 6 21 6"/>'
          + '<path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/>'
        + '</svg>'
        + 'Remove'
      + '</button>';

    activeList.appendChild(row);

    /* Revoke access */
    row.querySelector('[data-revoke]').addEventListener('click', function() {
      var id = this.getAttribute('data-revoke');
      var adv = activeCoAdvisers.find(function(a) { return a.id === id; });
      if (!adv) return;
      pendingRevoke = id;
      revokeTitle.textContent = 'Remove Co-Adviser?';
      revokeDesc.innerHTML = 'This will immediately revoke all adviser privileges from <strong>'
        + escHtml(adv.email) + '</strong>. They will no longer be able to manage the club.';
      revokeBackdrop.classList.add('open');
    });
  });
}

/* ══════════════════════════════════════════════════════════
   SEND INVITATION FLOW
══════════════════════════════════════════════════════════ */
sendBtn.addEventListener('click', function() {
  if (!validateForm()) return;
  pendingForm.email = emailInput.value.trim();
  confirmEmail.textContent = pendingForm.email;
  confirmBackdrop.classList.add('open');
});

btnConfirmSend.addEventListener('click', function() {
  var inv = {
    id: uid(),
    email: pendingForm.email,
    sentAt: new Date().toISOString()
  };
  pendingInvites.push(inv);
  renderPending();

  emailInput.value = '';
  clearErrors();

  confirmBackdrop.classList.remove('open');
  showToast('Invitation sent to ' + inv.email + '!', 'success');
});

btnCancel.addEventListener('click', function() {
  confirmBackdrop.classList.remove('open');
});
confirmBackdrop.addEventListener('click', function(e) {
  if (e.target === confirmBackdrop) confirmBackdrop.classList.remove('open');
});

/* ══════════════════════════════════════════════════════════
   REVOKE CO-ADVISER
══════════════════════════════════════════════════════════ */
btnRevokeConfirm.addEventListener('click', function() {
  if (!pendingRevoke) return;
  var adv = activeCoAdvisers.find(function(a) { return a.id === pendingRevoke; });
  activeCoAdvisers = activeCoAdvisers.filter(function(a) { return a.id !== pendingRevoke; });
  pendingRevoke = null;
  revokeBackdrop.classList.remove('open');
  renderActive();
  if (adv) showToast(adv.email + '\'s access has been revoked.', 'error');
});

btnRevokeCancel.addEventListener('click', function() {
  pendingRevoke = null;
  revokeBackdrop.classList.remove('open');
});
revokeBackdrop.addEventListener('click', function(e) {
  if (e.target === revokeBackdrop) {
    pendingRevoke = null;
    revokeBackdrop.classList.remove('open');
  }
});

/* ══════════════════════════════════════════════════════════
   KEYBOARD — Escape closes any open modal
══════════════════════════════════════════════════════════ */
document.addEventListener('keydown', function(e) {
  if (e.key !== 'Escape') return;
  confirmBackdrop.classList.remove('open');
  revokeBackdrop.classList.remove('open');
});

/* ══════════════════════════════════════════════════════════
   MOBILE SIDEBAR
══════════════════════════════════════════════════════════ */
function openSidebar() {
  if (sidebar) sidebar.classList.add('open');
  if (sidebarOverlay) {
    sidebarOverlay.style.display = 'block';
    setTimeout(function() { sidebarOverlay.classList.add('active'); }, 10);
  }
  document.body.style.overflow = 'hidden';
}
function closeSidebar() {
  if (sidebar) sidebar.classList.remove('open');
  if (sidebarOverlay) {
    sidebarOverlay.classList.remove('active');
    setTimeout(function() { sidebarOverlay.style.display = 'none'; }, 280);
  }
  document.body.style.overflow = '';
}
if (hamburgerBtn) {
  hamburgerBtn.addEventListener('click', function() {
    sidebar && sidebar.classList.contains('open') ? closeSidebar() : openSidebar();
  });
}
if (sidebarOverlay) {
  sidebarOverlay.addEventListener('click', closeSidebar);
}
document.querySelectorAll('.nav-item').forEach(function(item) {
  item.addEventListener('click', function() {
    if (window.innerWidth <= 768) closeSidebar();
  });
});

/* ══════════════════════════════════════════════════════════
   INIT
══════════════════════════════════════════════════════════ */
document.addEventListener('DOMContentLoaded', function() {
  renderPending();
  renderActive();
});