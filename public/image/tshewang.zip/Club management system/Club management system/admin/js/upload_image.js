'use strict';

/* ══════════════════════════════════════════════════════
   upload_image.js  –  JNEC Club Management  (v3)
   Album-based gallery with title / caption / viewer
   + 3-dot menu (Edit / Delete), Search & Sort
══════════════════════════════════════════════════════ */

/* ── Element refs ── */
const sidebar        = document.getElementById('sidebar');
const sidebarOverlay = document.getElementById('sidebar-overlay');
const hamburgerBtn   = document.getElementById('hamburger-btn');

const titleInput     = document.getElementById('img-title');
const captionInput   = document.getElementById('img-caption');

const dropZone       = document.getElementById('drop-zone');
const fileInput      = document.getElementById('file-input');
const previewStrip   = document.getElementById('preview-strip');
const previewGrid    = document.getElementById('preview-grid');
const previewCount   = document.getElementById('preview-count');
const clearBtn       = document.getElementById('clear-btn');
const submitBtn      = document.getElementById('upload-submit-btn');

const galleryEmpty   = document.getElementById('gallery-empty');
const albumGrid      = document.getElementById('album-grid');
const photoBadge     = document.getElementById('photo-badge');

// Search & Sort
const searchInput    = document.getElementById('gallery-search');
const sortSelect     = document.getElementById('gallery-sort');

// Album viewer / lightbox
const albumLightbox  = document.getElementById('album-lightbox');
const albOverlay     = document.getElementById('alb-overlay');
const albClose       = document.getElementById('alb-close');
const albImg         = document.getElementById('alb-img');
const albPrev        = document.getElementById('alb-prev');
const albNext        = document.getElementById('alb-next');
const albFooterTitle = document.getElementById('alb-footer-title');
const albCounter     = document.getElementById('alb-counter');
const albDots        = document.getElementById('alb-dots');

// Edit Modal
const editModal         = document.getElementById('edit-modal');
const editOverlay       = document.getElementById('edit-overlay');
const editClose         = document.getElementById('edit-modal-close');
const editTitleInput    = document.getElementById('edit-title');
const editCaptionInput  = document.getElementById('edit-caption');
const editDropZone      = document.getElementById('edit-drop-zone');
const editFileInput     = document.getElementById('edit-file-input');
const editPreviewGrid   = document.getElementById('edit-preview-grid');
const editPreviewStrip  = document.getElementById('edit-preview-strip');
const editPreviewCount  = document.getElementById('edit-preview-count');
const editClearBtn      = document.getElementById('edit-clear-btn');
const editSaveBtn       = document.getElementById('edit-save-btn');

const toast    = document.getElementById('toast');
const toastMsg = document.getElementById('toast-msg');

/* ── State ── */
let selectedFiles  = [];
let albums         = [];

// Viewer state
let viewerImages   = [];
let viewerIndex    = 0;

// Edit state
let editingAlbumId    = null;
let editSelectedFiles = [];
let editExistingSrcs  = [];

/* ══════════════════════════════
   SIDEBAR (mobile)
══════════════════════════════ */
function openSidebar() {
  sidebar.classList.add('open');
  sidebarOverlay.style.display = 'block';
  setTimeout(() => sidebarOverlay.classList.add('active'), 10);
  document.body.style.overflow = 'hidden';
}

function closeSidebar() {
  sidebar.classList.remove('open');
  sidebarOverlay.classList.remove('active');
  setTimeout(() => { sidebarOverlay.style.display = 'none'; }, 280);
  document.body.style.overflow = '';
}

hamburgerBtn.addEventListener('click', () =>
  sidebar.classList.contains('open') ? closeSidebar() : openSidebar()
);
sidebarOverlay.addEventListener('click', closeSidebar);
document.querySelectorAll('.nav-item').forEach(item => {
  item.addEventListener('click', () => { if (window.innerWidth <= 768) closeSidebar(); });
});

/* ══════════════════════════════
   UPLOAD FORM VALIDATION
══════════════════════════════ */
function checkFormValidity() {
  const hasTitle   = titleInput.value.trim().length > 0;
  const hasCaption = captionInput.value.trim().length > 0;
  const hasImages  = selectedFiles.length > 0;
  submitBtn.disabled = !(hasTitle && hasCaption && hasImages);
}

titleInput.addEventListener('input', checkFormValidity);
captionInput.addEventListener('input', checkFormValidity);

/* ══════════════════════════════
   DRAG & DROP / FILE INPUT
══════════════════════════════ */
dropZone.addEventListener('click', () => fileInput.click());
dropZone.addEventListener('dragover', e => { e.preventDefault(); dropZone.classList.add('dragover'); });
dropZone.addEventListener('dragleave', () => dropZone.classList.remove('dragover'));
dropZone.addEventListener('drop', e => {
  e.preventDefault();
  dropZone.classList.remove('dragover');
  const files = Array.from(e.dataTransfer.files).filter(f => f.type.startsWith('image/'));
  if (files.length) addFiles(files);
});
fileInput.addEventListener('change', () => {
  const files = Array.from(fileInput.files);
  if (files.length) addFiles(files);
  fileInput.value = '';
});

/* ══════════════════════════════
   FILE MANAGEMENT (Upload)
══════════════════════════════ */
function addFiles(newFiles) {
  newFiles.forEach(file => {
    const exists = selectedFiles.some(f => f.name === file.name && f.size === file.size);
    if (!exists) selectedFiles.push(file);
  });
  renderPreview();
  checkFormValidity();
}

function removeFile(index) {
  selectedFiles.splice(index, 1);
  renderPreview();
  checkFormValidity();
}

function clearAll() {
  selectedFiles = [];
  renderPreview();
  checkFormValidity();
}

function renderPreview() {
  previewGrid.innerHTML = '';
  if (selectedFiles.length === 0) { previewStrip.style.display = 'none'; return; }
  previewStrip.style.display = 'block';
  previewCount.textContent = `${selectedFiles.length} image${selectedFiles.length > 1 ? 's' : ''} selected`;
  selectedFiles.forEach((file, i) => {
    const reader = new FileReader();
    reader.onload = e => {
      const item = document.createElement('div');
      item.className = 'preview-item';
      item.innerHTML = `<img src="${e.target.result}" alt="${escHtml(file.name)}" /><button class="preview-remove" data-index="${i}" title="Remove">✕</button>`;
      item.querySelector('.preview-remove').addEventListener('click', ev => {
        ev.stopPropagation();
        removeFile(parseInt(ev.currentTarget.dataset.index));
      });
      previewGrid.appendChild(item);
    };
    reader.readAsDataURL(file);
  });
}

clearBtn.addEventListener('click', clearAll);

/* ══════════════════════════════
   UPLOAD → CREATE ALBUM
══════════════════════════════ */
submitBtn.addEventListener('click', () => {
  if (!selectedFiles.length) return;
  const albumTitle   = titleInput.value.trim();
  const albumCaption = captionInput.value.trim();

  submitBtn.disabled = true;
  submitBtn.innerHTML = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" width="16" height="16" style="animation:spin 1s linear infinite"><path d="M21 12a9 9 0 1 1-6.219-8.56"/></svg> Uploading…`;

  if (!document.getElementById('spin-style')) {
    const s = document.createElement('style');
    s.id = 'spin-style';
    s.textContent = '@keyframes spin { to { transform: rotate(360deg); } }';
    document.head.appendChild(s);
  }

  const filesToRead = [...selectedFiles];
  const srcs = [];
  let loaded = 0;

  filesToRead.forEach((file, i) => {
    const reader = new FileReader();
    reader.onload = e => {
      srcs[i] = e.target.result;
      loaded++;
      if (loaded === filesToRead.length) {
        setTimeout(() => {
          addAlbum(albumTitle, albumCaption, srcs);
          selectedFiles = [];
          titleInput.value = '';
          captionInput.value = '';
          renderPreview();
          submitBtn.innerHTML = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" width="16" height="16"><polyline points="16 16 12 12 8 16"/><line x1="12" y1="12" x2="12" y2="21"/><path d="M20.39 18.39A5 5 0 0 0 18 9h-1.26A8 8 0 1 0 3 16.3"/></svg> Upload`;
          checkFormValidity();
          showToast('Album created successfully!');
        }, 1200);
      }
    };
    reader.readAsDataURL(file);
  });
});

/* ══════════════════════════════
   ALBUM DATA STORE
══════════════════════════════ */
function addAlbum(title, caption, srcs) {
  const now = new Date();
  const album = { id: 'album_' + Date.now(), title, caption, srcs, createdAt: now };
  albums.unshift(album);
  renderGallery();
}

function deleteAlbum(id) {
  albums = albums.filter(a => a.id !== id);
  renderGallery();
  showToast('Album deleted.');
}

function updateAlbum(id, title, caption, srcs) {
  const idx = albums.findIndex(a => a.id === id);
  if (idx === -1) return;
  albums[idx] = { ...albums[idx], title, caption, srcs };
  renderGallery();
  showToast('Album updated successfully!');
}

/* ══════════════════════════════
   SEARCH & SORT
══════════════════════════════ */
function getFilteredSortedAlbums() {
  const query = searchInput ? searchInput.value.trim().toLowerCase() : '';
  const sort  = sortSelect  ? sortSelect.value : 'newest';

  let result = [...albums];

  if (query) {
    result = result.filter(a =>
      a.title.toLowerCase().includes(query) ||
      a.caption.toLowerCase().includes(query)
    );
  }

  if (sort === 'newest')      result.sort((a, b) => b.createdAt - a.createdAt);
  else if (sort === 'oldest') result.sort((a, b) => a.createdAt - b.createdAt);
  else if (sort === 'name')   result.sort((a, b) => a.title.localeCompare(b.title));

  return result;
}

if (searchInput) searchInput.addEventListener('input', renderGallery);
if (sortSelect)  sortSelect.addEventListener('change', renderGallery);

/* ══════════════════════════════
   RENDER GALLERY
══════════════════════════════ */
function renderGallery() {
  albumGrid.innerHTML = '';
  const filtered = getFilteredSortedAlbums();
  const isEmpty   = albums.length === 0;
  const noResults = !isEmpty && filtered.length === 0;

  photoBadge.textContent = `${albums.length} album${albums.length !== 1 ? 's' : ''}`;

  const galleryEmptyText = galleryEmpty.querySelector('.gallery-empty-text');
  const galleryEmptyHint = galleryEmpty.querySelector('.gallery-empty-hint');

  if (isEmpty) {
    galleryEmpty.style.display = 'flex';
    albumGrid.style.display    = 'none';
    if (galleryEmptyText) galleryEmptyText.textContent = 'No images uploaded yet';
    if (galleryEmptyHint) galleryEmptyHint.textContent = 'Upload images above and they\'ll appear here as albums.';
    return;
  }

  if (noResults) {
    galleryEmpty.style.display = 'flex';
    albumGrid.style.display    = 'none';
    if (galleryEmptyText) galleryEmptyText.textContent = 'No results found';
    if (galleryEmptyHint) galleryEmptyHint.textContent = 'Try a different search term or clear the search.';
    return;
  }

  galleryEmpty.style.display = 'none';
  albumGrid.style.display    = 'grid';
  filtered.forEach(album => albumGrid.appendChild(createAlbumCard(album)));
}

/* ══════════════════════════════
   CREATE ALBUM CARD (3-dot menu)
══════════════════════════════ */
function createAlbumCard(album) {
  const dateStr = album.createdAt.toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' });
  const timeStr = album.createdAt.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' });
  const dateTimeStr = `${dateStr} · ${timeStr}`;

  const card = document.createElement('div');
  card.className = 'album-card';
  card.dataset.id = album.id;

  card.innerHTML = `
    <div class="album-thumb">
      <img src="${album.srcs[0]}" alt="${escHtml(album.title)}" />
      <div class="album-count-pill">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" width="11" height="11"><rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><polyline points="21 15 16 10 5 21"/></svg>
        ${album.srcs.length} photo${album.srcs.length > 1 ? 's' : ''}
      </div>
      <div class="album-play-overlay">
        <div class="album-play-overlay-inner">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" width="18" height="18"><polygon points="5 3 19 12 5 21 5 3"/></svg>
        </div>
      </div>
    </div>
    <div class="album-info">
      <div class="album-info-row">
        <div class="album-info-title">${escHtml(album.title)}</div>
        <div class="album-menu-wrap">
          <button class="album-menu-btn" title="Options" aria-label="Album options">
            <svg viewBox="0 0 24 24" fill="currentColor" width="16" height="16">
              <circle cx="12" cy="5"  r="1.6"/>
              <circle cx="12" cy="12" r="1.6"/>
              <circle cx="12" cy="19" r="1.6"/>
            </svg>
          </button>
          <div class="album-menu-dropdown">
            <button class="album-menu-item album-menu-edit">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" width="14" height="14"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>
              Edit
            </button>
            <div class="album-menu-divider"></div>
            <button class="album-menu-item album-menu-delete">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" width="14" height="14"><polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/><path d="M10 11v6"/><path d="M14 11v6"/><path d="M9 6V4a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2"/></svg>
              Delete
            </button>
          </div>
        </div>
      </div>
      <div class="album-info-caption">${escHtml(album.caption)}</div>
      <div class="album-info-meta">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" width="11" height="11"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg>
        ${dateTimeStr}
      </div>
    </div>
  `;

  // Thumbnail click → open viewer
  card.querySelector('.album-thumb').addEventListener('click', () => {
    openViewer(album.srcs, album.title, 0);
  });

  // 3-dot menu toggle
  const menuBtn      = card.querySelector('.album-menu-btn');
  const menuDropdown = card.querySelector('.album-menu-dropdown');

  menuBtn.addEventListener('click', e => {
    e.stopPropagation();
    document.querySelectorAll('.album-menu-dropdown.open').forEach(d => {
      if (d !== menuDropdown) d.classList.remove('open');
    });
    menuDropdown.classList.toggle('open');
  });

  // Edit
  card.querySelector('.album-menu-edit').addEventListener('click', e => {
    e.stopPropagation();
    menuDropdown.classList.remove('open');
    openEditModal(album.id);
  });

  // Delete
  card.querySelector('.album-menu-delete').addEventListener('click', e => {
    e.stopPropagation();
    menuDropdown.classList.remove('open');
    card.classList.add('card-removing');
    setTimeout(() => deleteAlbum(album.id), 260);
  });

  return card;
}

// Close open menus on outside click
document.addEventListener('click', () => {
  document.querySelectorAll('.album-menu-dropdown.open').forEach(d => d.classList.remove('open'));
});

/* ══════════════════════════════
   EDIT MODAL
══════════════════════════════ */
function openEditModal(albumId) {
  const album = albums.find(a => a.id === albumId);
  if (!album) return;

  editingAlbumId    = albumId;
  editSelectedFiles = [];
  editExistingSrcs  = [...album.srcs];

  editTitleInput.value   = album.title;
  editCaptionInput.value = album.caption;

  renderEditPreview();
  editModal.classList.add('open');
  document.body.style.overflow = 'hidden';
  checkEditSaveValidity();
}

function closeEditModal() {
  editModal.classList.remove('open');
  document.body.style.overflow = '';
  editingAlbumId    = null;
  editSelectedFiles = [];
  editExistingSrcs  = [];
  editPreviewGrid.innerHTML = '';
}

editClose.addEventListener('click', closeEditModal);
editOverlay.addEventListener('click', closeEditModal);

function checkEditSaveValidity() {
  const hasTitle   = editTitleInput.value.trim().length > 0;
  const hasCaption = editCaptionInput.value.trim().length > 0;
  const totalImages = editExistingSrcs.length + editSelectedFiles.length;
  editSaveBtn.disabled = !(hasTitle && hasCaption && totalImages > 0);
}

editTitleInput.addEventListener('input', checkEditSaveValidity);
editCaptionInput.addEventListener('input', checkEditSaveValidity);

editDropZone.addEventListener('click', () => editFileInput.click());
editDropZone.addEventListener('dragover', e => { e.preventDefault(); editDropZone.classList.add('dragover'); });
editDropZone.addEventListener('dragleave', () => editDropZone.classList.remove('dragover'));
editDropZone.addEventListener('drop', e => {
  e.preventDefault();
  editDropZone.classList.remove('dragover');
  const files = Array.from(e.dataTransfer.files).filter(f => f.type.startsWith('image/'));
  if (files.length) addEditFiles(files);
});
editFileInput.addEventListener('change', () => {
  const files = Array.from(editFileInput.files);
  if (files.length) addEditFiles(files);
  editFileInput.value = '';
});

function addEditFiles(newFiles) {
  newFiles.forEach(file => {
    const exists = editSelectedFiles.some(f => f.name === file.name && f.size === file.size);
    if (!exists) editSelectedFiles.push(file);
  });
  renderEditPreview();
  checkEditSaveValidity();
}

editClearBtn.addEventListener('click', () => {
  editSelectedFiles = [];
  editExistingSrcs  = [];
  renderEditPreview();
  checkEditSaveValidity();
});

function renderEditPreview() {
  editPreviewGrid.innerHTML = '';
  const total = editExistingSrcs.length + editSelectedFiles.length;

  if (total === 0) { editPreviewStrip.style.display = 'none'; return; }

  editPreviewStrip.style.display = 'block';
  editPreviewCount.textContent = `${total} image${total > 1 ? 's' : ''}`;

  // Existing srcs
  editExistingSrcs.forEach((src, i) => {
    const item = document.createElement('div');
    item.className = 'preview-item';
    item.innerHTML = `
      <img src="${src}" alt="existing image" />
      <div class="preview-existing-tag">Existing</div>
      <button class="preview-remove" data-type="existing" data-index="${i}" title="Remove">✕</button>
    `;
    item.querySelector('.preview-remove').addEventListener('click', ev => {
      ev.stopPropagation();
      editExistingSrcs.splice(parseInt(ev.currentTarget.dataset.index), 1);
      renderEditPreview();
      checkEditSaveValidity();
    });
    editPreviewGrid.appendChild(item);
  });

  // New files
  editSelectedFiles.forEach((file, i) => {
    const reader = new FileReader();
    reader.onload = e => {
      const item = document.createElement('div');
      item.className = 'preview-item';
      item.innerHTML = `
        <img src="${e.target.result}" alt="${escHtml(file.name)}" />
        <div class="preview-new-tag">New</div>
        <button class="preview-remove" data-type="new" data-index="${i}" title="Remove">✕</button>
      `;
      item.querySelector('.preview-remove').addEventListener('click', ev => {
        ev.stopPropagation();
        editSelectedFiles.splice(parseInt(ev.currentTarget.dataset.index), 1);
        renderEditPreview();
        checkEditSaveValidity();
      });
      editPreviewGrid.appendChild(item);
    };
    reader.readAsDataURL(file);
  });
}

editSaveBtn.addEventListener('click', () => {
  if (!editingAlbumId) return;
  editSaveBtn.disabled = true;
  editSaveBtn.textContent = 'Saving…';

  if (editSelectedFiles.length === 0) {
    finishSave(editExistingSrcs);
    return;
  }

  const newSrcs = [];
  let loaded = 0;
  editSelectedFiles.forEach((file, i) => {
    const reader = new FileReader();
    reader.onload = e => {
      newSrcs[i] = e.target.result;
      loaded++;
      if (loaded === editSelectedFiles.length) finishSave([...editExistingSrcs, ...newSrcs]);
    };
    reader.readAsDataURL(file);
  });
});

function finishSave(combinedSrcs) {
  setTimeout(() => {
    updateAlbum(editingAlbumId, editTitleInput.value.trim(), editCaptionInput.value.trim(), combinedSrcs);
    editSaveBtn.disabled = false;
    editSaveBtn.textContent = 'Save Changes';
    closeEditModal();
  }, 600);
}

/* ══════════════════════════════
   ALBUM VIEWER (Lightbox)
══════════════════════════════ */
function openViewer(srcs, title, startIndex) {
  viewerImages = srcs;
  viewerIndex  = startIndex;
  albFooterTitle.textContent = title;
  albumLightbox.classList.add('open');
  document.body.style.overflow = 'hidden';
  renderViewerImage();
  buildDots();
}

function closeViewer() {
  albumLightbox.classList.remove('open');
  albImg.src = '';
  document.body.style.overflow = '';
  viewerImages = [];
}

function renderViewerImage() {
  albImg.classList.add('fade-out');
  setTimeout(() => {
    albImg.src = viewerImages[viewerIndex];
    albImg.classList.remove('fade-out');
  }, 120);
  albCounter.textContent = `${viewerIndex + 1} / ${viewerImages.length}`;
  albPrev.classList.toggle('hidden', viewerIndex === 0);
  albNext.classList.toggle('hidden', viewerIndex === viewerImages.length - 1);
  document.querySelectorAll('.alb-dot').forEach((dot, i) => dot.classList.toggle('active', i === viewerIndex));
}

function buildDots() {
  albDots.innerHTML = '';
  if (viewerImages.length <= 20) {
    viewerImages.forEach((_, i) => {
      const dot = document.createElement('button');
      dot.className = 'alb-dot' + (i === viewerIndex ? ' active' : '');
      dot.title = `Image ${i + 1}`;
      dot.addEventListener('click', () => { viewerIndex = i; renderViewerImage(); });
      albDots.appendChild(dot);
    });
  }
}

function prevImage() { if (viewerIndex > 0) { viewerIndex--; renderViewerImage(); } }
function nextImage() { if (viewerIndex < viewerImages.length - 1) { viewerIndex++; renderViewerImage(); } }

albPrev.addEventListener('click', prevImage);
albNext.addEventListener('click', nextImage);
albClose.addEventListener('click', closeViewer);
albOverlay.addEventListener('click', closeViewer);

document.addEventListener('keydown', e => {
  if (editModal && editModal.classList.contains('open')) return;
  if (!albumLightbox.classList.contains('open')) return;
  if (e.key === 'ArrowLeft')  prevImage();
  if (e.key === 'ArrowRight') nextImage();
  if (e.key === 'Escape')     closeViewer();
});

let touchStartX = 0;
albumLightbox.addEventListener('touchstart', e => { touchStartX = e.changedTouches[0].clientX; }, { passive: true });
albumLightbox.addEventListener('touchend', e => {
  const dx = e.changedTouches[0].clientX - touchStartX;
  if (Math.abs(dx) > 40) { dx < 0 ? nextImage() : prevImage(); }
});

/* ══════════════════════════════
   TOAST
══════════════════════════════ */
let toastTimer;
function showToast(msg) {
  toastMsg.textContent = msg;
  toast.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toast.classList.remove('show'), 3200);
}

/* ══════════════════════════════
   UTILS
══════════════════════════════ */
function escHtml(str) {
  return str.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

// Init
renderGallery();