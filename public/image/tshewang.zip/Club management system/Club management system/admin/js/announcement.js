/* ══════════════════════════════════════════
   JNEC — announcement.js
   - Default: newest announcements always on top
   - Filter by month (e.g. November 2026)
   - Filter by club name (e.g. Y-Peer, Red Cross)
   - Active filter tags shown with remove button
══════════════════════════════════════════ */

/* ── Announcement Data ─────────────────────
   Add new announcements at the TOP.
   Each item needs a `club` field matching
   one of the club names in the dropdown.
   date format: "YYYY-MM-DD"
────────────────────────────────────────── */
const ANNOUNCEMENTS = [
  {
    id: 1,
    title: "System Maintenance Scheduled",
    body: "Our central database will undergo routine optimization. Read-only access will be enforced during the 4-hour window to ensure data integrity.",
    date: "2026-11-05",
    author: "IT Department",
    club: "DIT Maintenance",
    tag: "notice"
  },
  {
    id: 2,
    title: "Quarterly Policy Update",
    body: "New guidelines regarding remote work flexibility and hardware procurement have been uploaded to the internal portal. Please review and sign before the weekend.",
    date: "2026-11-02",
    author: "Admin Office",
    club: "Integrity Club",
    tag: "update"
  },
  {
    id: 3,
    title: "Interview Schedule Released",
    body: "Final round interviews for the Senior Engineering positions have been finalized. Candidates will receive their calendar invites by the end of the business day.",
    date: "2026-10-26",
    author: "HR Department",
    club: "Entrepreneurship Club",
    tag: "event"
  },
  {
    id: 4,
    title: "Fiber Migration Notice",
    body: "We are upgrading our core infrastructure to fiber-optic connections. Expect brief intermittent connectivity during the transition window between 02:00 AM and 05:00 AM.",
    date: "2026-10-24",
    author: "IT Department",
    club: "Electrical Maintenance",
    tag: "urgent"
  },
  {
    id: 5,
    title: "Club Registration Deadline",
    body: "All new clubs must complete their registration by the end of this month. Clubs that have not submitted their advisor details will be removed from the directory.",
    date: "2026-09-18",
    author: "Student Affairs",
    club: "Rover Scout",
    tag: "notice"
  },
  {
    id: 6,
    title: "Annual Sports Day 2026",
    body: "The annual inter-departmental sports day is scheduled for November 15. All clubs are encouraged to participate. Registration opens next Monday on the portal.",
    date: "2026-09-10",
    author: "Sports Committee",
    club: "JNEC Karate",
    tag: "event"
  }
];

/* ── Helpers ── */
function formatDateLong(dateStr) {
  const d = new Date(dateStr + 'T00:00:00');
  return d.toLocaleDateString('en-US', {
    month: 'long', day: 'numeric', year: 'numeric'
  }).toUpperCase();
}

function formatDateShort(dateStr) {
  const d = new Date(dateStr + 'T00:00:00');
  return d.toLocaleDateString('en-US', {
    month: 'short', day: 'numeric', year: 'numeric'
  });
}

function getInitials(name) {
  return name.split(' ').map(w => w[0]).slice(0, 2).join('').toUpperCase();
}

function getTagLabel(tag) {
  const map = { notice: 'Notice', update: 'Update', event: 'Event', urgent: 'Urgent', info: 'Info' };
  return map[tag] || tag;
}

/* ── Filter ── */
function applyFilters(data, monthTerm, clubVal) {
  return data.filter(item => {
    // Month: match typed text against full month name e.g. "November 2026"
    let matchMonth = true;
    if (monthTerm.trim()) {
      const d = new Date(item.date + 'T00:00:00');
      const fullMonthYear = d.toLocaleDateString('en-US', { month: 'long', year: 'numeric' }); // "November 2026"
      const monthOnly     = d.toLocaleDateString('en-US', { month: 'long' }); // "November"
      const term = monthTerm.trim().toLowerCase();
      matchMonth = fullMonthYear.toLowerCase().includes(term) || monthOnly.toLowerCase().includes(term);
    }
    const matchClub = !clubVal || item.club === clubVal;
    return matchMonth && matchClub;
  });
}

/* ── Active filter tags UI ── */
function renderFilterTags(monthTerm, clubVal) {
  const container = document.getElementById('activeFilters');
  const resetBtn  = document.getElementById('resetFilters');
  container.innerHTML = '';

  const clubSelect = document.getElementById('clubFilter');
  const hasFilters = monthTerm.trim() || clubVal;
  resetBtn.style.display = hasFilters ? 'flex' : 'none';

  if (monthTerm.trim()) {
    container.appendChild(makeTag(monthTerm.trim(), () => {
      document.getElementById('monthFilter').value = '';
      document.getElementById('clearMonth').classList.remove('visible');
      render();
    }));
  }
  if (clubVal) {
    const label = clubSelect.options[clubSelect.selectedIndex].text;
    container.appendChild(makeTag(label, () => {
      clubSelect.value = '';
      render();
    }));
  }
}

function makeTag(label, onRemove) {
  const tag = document.createElement('span');
  tag.className = 'filter-tag';
  tag.innerHTML = `${label} <button title="Remove"><i class="fas fa-times"></i></button>`;
  tag.querySelector('button').addEventListener('click', onRemove);
  return tag;
}

/* ── Render ── */
function render() {
  const monthTerm = document.getElementById('monthFilter').value;
  const clubVal   = document.getElementById('clubFilter').value;

  // Always sort newest first
  const sorted = [...ANNOUNCEMENTS].sort(
    (a, b) => new Date(b.date) - new Date(a.date)
  );

  const filtered = applyFilters(sorted, monthTerm, clubVal);

  const timeline  = document.getElementById('timeline');
  const empty     = document.getElementById('emptyState');
  const resultBar = document.getElementById('resultBar');

  renderFilterTags(monthTerm, clubVal);

  timeline.innerHTML = '';

  if (filtered.length === 0) {
    empty.classList.remove('hidden');
    timeline.style.display = 'none';
    resultBar.innerHTML = 'No announcements match your filters.';
    return;
  }

  empty.classList.add('hidden');
  timeline.style.display = '';
  resultBar.innerHTML = `
    <span class="result-dot"></span>
    Showing <strong>${filtered.length}</strong> of ${ANNOUNCEMENTS.length} announcements
    ${monthTerm.trim() || clubVal ? '— filtered' : ''}
  `;

  const newestDate = filtered[0].date;

  filtered.forEach((item, index) => {
    const isNewest = index === 0 && item.date === newestDate;
    const el = document.createElement('div');
    el.className = 'tl-item';
    el.style.animationDelay = `${index * 0.06}s`;

    el.innerHTML = `
      <div class="tl-card-wrap">
        <div class="tl-card">
          ${isNewest ? `<div class="tl-newest-badge"><i class="fas fa-star" style="font-size:9px;"></i> Latest</div>` : ''}
          <div class="tl-club-badge">
            <i class="fas fa-users"></i> ${item.club}
          </div>
          <div class="tl-card-header">
            <div class="tl-card-title">${item.title}</div>
            <span class="tl-tag ${item.tag}">${getTagLabel(item.tag)}</span>
          </div>
          <p class="tl-card-body">${item.body}</p>
          <div class="tl-card-footer">
            <div class="tl-author">
              <div class="tl-author-avatar">${getInitials(item.author)}</div>
              <span>${item.author}</span>
            </div>
            <span class="tl-card-time">${formatDateShort(item.date)}</span>
          </div>
        </div>
      </div>
      <div class="tl-center">
        <div class="tl-dot"></div>
        <div class="tl-date-pill">${formatDateLong(item.date)}</div>
      </div>
      <div class="tl-card-wrap"></div>
    `;

    timeline.appendChild(el);
  });
}

/* ══════════════════════════════════════════
   INIT
══════════════════════════════════════════ */
document.addEventListener('DOMContentLoaded', () => {

  // Initial render — newest first, no filters
  render();

  // Month text input
  const monthInput = document.getElementById('monthFilter');
  const clearMonth = document.getElementById('clearMonth');

  monthInput.addEventListener('input', () => {
    clearMonth.classList.toggle('visible', monthInput.value.length > 0);
    render();
  });

  clearMonth.addEventListener('click', () => {
    monthInput.value = '';
    clearMonth.classList.remove('visible');
    render();
  });

  // Club filter
  document.getElementById('clubFilter').addEventListener('change', render);

  // Reset all
  document.getElementById('resetFilters').addEventListener('click', () => {
    monthInput.value = '';
    clearMonth.classList.remove('visible');
    document.getElementById('clubFilter').value = '';
    render();
  });

  // Reset from empty state
  document.getElementById('resetEmpty').addEventListener('click', () => {
    monthInput.value = '';
    clearMonth.classList.remove('visible');
    document.getElementById('clubFilter').value = '';
    render();
  });

  /* ── Navbar: Hamburger ── */
  const hamburger = document.getElementById('hamburger');
  const navLinks  = document.getElementById('navLinks');
  if (hamburger && navLinks) {
    hamburger.addEventListener('click', () => navLinks.classList.toggle('open'));
    document.addEventListener('click', (e) => {
      if (!hamburger.contains(e.target) && !navLinks.contains(e.target)) {
        navLinks.classList.remove('open');
      }
    });
  }

  /* ── Navbar: Search bar toggle ── */
  const searchBtn      = document.getElementById('searchBtn');
  const searchBarWrap  = document.getElementById('searchBarWrap');
  const navSearchInput = document.getElementById('navSearchInput');
  const searchCloseBtn = document.getElementById('searchCloseBtn');

  if (searchBtn) {
    searchBtn.addEventListener('click', () => {
      searchBarWrap.classList.toggle('open');
      if (searchBarWrap.classList.contains('open')) {
        navSearchInput && navSearchInput.focus();
      } else {
        if (navSearchInput) navSearchInput.value = '';
      }
    });
  }
  if (searchCloseBtn) {
    searchCloseBtn.addEventListener('click', () => {
      searchBarWrap.classList.remove('open');
      if (navSearchInput) navSearchInput.value = '';
    });
  }

});