/* ══════════════════════════════════════════
   JNEC — create-club.js  (wizard only)
══════════════════════════════════════════ */

(function () {

  let currentStep = 1;

  /* ── Update tab states ── */
  function updateTabs(to) {
    for (let i = 1; i <= 3; i++) {
      const tab = document.querySelector(`.step-tab[data-step="${i}"]`);
      if (!tab) continue;
      tab.classList.remove('active', 'done');
      const num = tab.querySelector('.step-num');

      if (i < to) {
        tab.classList.add('done');
        num.textContent = '✓';
      } else if (i === to) {
        tab.classList.add('active');
        num.textContent = i;
      } else {
        num.textContent = i;
      }
    }
  }

  /* ── Navigate steps ── */
  window.goToStep = function (step) {
    if (step === 2 && !validateStep1()) return;
    if (step === 3 && !validateStep2()) return;
    if (step === 3) buildPreview();

    document.getElementById(`wizardStep${currentStep}`).classList.add('hidden');
    updateTabs(step);
    currentStep = step;
    document.getElementById(`wizardStep${currentStep}`).classList.remove('hidden');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  /* ── Validation ── */
  function validateStep1() {
    const name     = document.getElementById('clubName').value.trim();
    const category = document.getElementById('clubCategory').value;
    const advisor  = document.getElementById('clubAdvisor').value.trim();
    if (!name)     { highlightError('clubName',     'Please enter a club name.'); return false; }
    if (!category) { highlightError('clubCategory', 'Please select a category.'); return false; }
    if (!advisor)  { highlightError('clubAdvisor',  'Please enter an advisor name.'); return false; }
    return true;
  }

  function validateStep2() {
    const desc = document.getElementById('clubDescription').value.trim();
    const aim  = document.getElementById('clubMainAim').value.trim();
    if (!desc) { highlightError('clubDescription', 'Please enter a description.'); return false; }
    if (!aim)  { highlightError('clubMainAim',     'Please enter the main aim.'); return false; }
    return true;
  }

  function highlightError(id, msg) {
    const el = document.getElementById(id);
    el.style.borderColor = '#e05555';
    el.style.boxShadow   = '0 0 0 3px rgba(224,85,85,0.1)';
    el.focus();
    el.addEventListener('input', () => {
      el.style.borderColor = '';
      el.style.boxShadow   = '';
    }, { once: true });
    showToast(msg);
  }

  function showToast(msg) {
    let toast = document.getElementById('cc-toast');
    if (!toast) {
      toast = document.createElement('div');
      toast.id = 'cc-toast';
      Object.assign(toast.style, {
        position: 'fixed', bottom: '24px', left: '50%',
        transform: 'translateX(-50%)',
        background: '#e05555', color: '#fff',
        padding: '10px 20px', borderRadius: '8px',
        fontSize: '13px', fontWeight: '600',
        zIndex: '9999', fontFamily: "'DM Sans', sans-serif",
        boxShadow: '0 4px 16px rgba(224,85,85,0.3)',
      });
      document.body.appendChild(toast);
    }
    toast.textContent = msg;
    toast.style.display = 'block';
    clearTimeout(toast._timer);
    toast._timer = setTimeout(() => { toast.style.display = 'none'; }, 2800);
  }

  /* ── Build preview ── */
  function buildPreview() {
    const name      = document.getElementById('clubName').value.trim();
    const category  = document.getElementById('clubCategory').value;
    const advisor   = document.getElementById('clubAdvisor').value.trim();
    const secretary = document.getElementById('clubSecretary').value.trim() || 'Not assigned';
    const desc      = document.getElementById('clubDescription').value.trim();
    const aim       = document.getElementById('clubMainAim').value.trim();

    document.getElementById('previewName').textContent        = name;
    document.getElementById('previewCategory').textContent    = category;
    document.getElementById('previewType').textContent        = category;
    document.getElementById('previewAdvisor').textContent     = advisor;
    document.getElementById('previewSecretary').textContent   = secretary;
    document.getElementById('previewDescription').textContent = desc;
    document.getElementById('previewObjName').textContent     = name;

    const objList = document.getElementById('previewObjectivesList');
    objList.innerHTML = '';

    const aimLi = document.createElement('li');
    aimLi.textContent = aim;
    objList.appendChild(aimLi);

    document.querySelectorAll('.objective-input').forEach(input => {
      const val = input.value.trim();
      if (val) {
        const li = document.createElement('li');
        li.textContent = val;
        objList.appendChild(li);
      }
    });
  }

  /* ── Objectives ── */
  window.addObjective = function () {
    const list  = document.getElementById('objectivesList');
    const count = list.querySelectorAll('.objective-row').length + 1;
    const row   = document.createElement('div');
    row.className = 'objective-row';
    row.innerHTML = `
      <span class="obj-num">${count}</span>
      <input type="text" placeholder="Enter an objective…" class="objective-input" />
      <button class="obj-remove" onclick="removeObjective(this)"><i class="fas fa-times"></i></button>
    `;
    list.appendChild(row);
    row.querySelector('input').focus();
  };

  window.removeObjective = function (btn) {
    const list = document.getElementById('objectivesList');
    if (list.querySelectorAll('.objective-row').length > 1) {
      btn.closest('.objective-row').remove();
      list.querySelectorAll('.obj-num').forEach((num, i) => { num.textContent = i + 1; });
    }
  };

  /* ── Submit ── */
  window.submitClub = function () {
    const club = {
      name:        document.getElementById('clubName').value.trim(),
      category:    document.getElementById('clubCategory').value,
      advisor:     document.getElementById('clubAdvisor').value.trim(),
      secretary:   document.getElementById('clubSecretary').value.trim() || 'Not assigned',
      description: document.getElementById('clubDescription').value.trim(),
      mainAim:     document.getElementById('clubMainAim').value.trim(),
      objectives:  Array.from(document.querySelectorAll('.objective-input'))
                        .map(i => i.value.trim()).filter(Boolean),
      createdAt:   new Date().toISOString(),
    };
    localStorage.setItem('myClub', JSON.stringify(club));
    document.getElementById('successOverlay').classList.add('show');
    setTimeout(() => { window.location.href = 'index.html'; }, 2800);
  };

  /* ── Init ── */
  updateTabs(1);

})();