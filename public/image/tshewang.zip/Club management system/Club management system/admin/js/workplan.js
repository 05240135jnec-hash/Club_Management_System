'use strict';

/* ════════════════════════════════════════════════
   PAGE META
════════════════════════════════════════════════ */
var PAGE_META = {
  'dashboard':        { title: 'Dashboard',       subtitle: 'Club overview' },
  'club-details':     { title: 'Club Details',     subtitle: 'Manage your club information' },
  'assign-secretary': { title: 'Assign Secretary', subtitle: 'Manage club secretary roles' },
  'members':          { title: 'Members',           subtitle: 'View and manage club members' },
  'announcements':    { title: 'Announcements',     subtitle: 'Post and manage announcements' },
  'attendance':       { title: 'Attendance',        subtitle: 'Track member attendance' },
  'enrollment-key':   { title: 'Enrollment Key',    subtitle: 'Manage club enrollment keys' },
  'upload-reports':   { title: 'Upload Reports',    subtitle: 'Submit club reports' },
  'upload-workplan':  { title: 'Upload Work Plan',  subtitle: 'Submit club work plans' },
  'upload-image':     { title: 'Upload Image',      subtitle: 'Upload club images' },
  'upload-vlog':      { title: 'Upload Vlog',       subtitle: 'Upload club video logs' }
};

/* ════════════════════════════════════════════════
   SEMESTER LOGIC
════════════════════════════════════════════════ */
var LOOKAHEAD_YEARS = 10;

function isSemesterPast(year, sem, now) {
  if (sem === 1) {
    return now >= new Date(year, 6, 1);
  } else {
    return now >= new Date(year + 1, 0, 1);
  }
}

function semKey(sem, year) {
  return 'Sem ' + sem + ' \u2014 ' + year;
}

function buildSemesterDropdown(usedSemesters) {
  var select = document.getElementById('plan-semester');
  var hint   = document.getElementById('sem-all-used-hint');
  if (!select) return;

  var now         = new Date();
  var currentYear = now.getFullYear();
  var maxYear     = currentYear + LOOKAHEAD_YEARS;

  while (select.options.length > 1) select.remove(1);

  var availableCount = 0;

  for (var year = currentYear; year <= maxYear; year++) {
    for (var sem = 1; sem <= 2; sem++) {
      var key  = semKey(sem, year);
      var past = isSemesterPast(year, sem, now);
      var used = usedSemesters.has(key);

      if (past) continue;

      var opt = document.createElement('option');
      opt.value       = key;
      opt.textContent = key;

      if (used) {
        opt.disabled        = true;
        opt.textContent     = key + ' (already uploaded)';
        opt.className       = 'sem-option-used';
      } else {
        availableCount++;
      }

      select.appendChild(opt);
    }
  }

  if (hint) hint.style.display = availableCount === 0 ? '' : 'none';
}

/* ════════════════════════════════════════════════
   HELPERS
════════════════════════════════════════════════ */
function escapeHtml(str) {
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

function formatSize(bytes) {
  if (bytes === 0) return '0.0 MB';
  var kb = bytes / 1024;
  var mb = kb / 1024;
  return mb >= 0.1 ? mb.toFixed(1) + ' MB' : kb.toFixed(1) + ' KB';
}

/* ════════════════════════════════════════════════
   MAIN
════════════════════════════════════════════════ */
document.addEventListener('DOMContentLoaded', function () {

  /* ── Sidebar / nav elements ── */
  var sidebar        = document.getElementById('sidebar');
  var sidebarOverlay = document.getElementById('sidebar-overlay');
  var hamburgerBtn   = document.getElementById('hamburger-btn');
  var topbarTitle    = document.getElementById('topbar-title');
  var topbarSubtitle = document.getElementById('topbar-subtitle');
  var notifBadge     = document.getElementById('notif-badge');
  var navItems       = document.querySelectorAll('.nav-item');

  /* ── Sidebar open / close ── */
  function openSidebar() {
    sidebar.classList.add('open');
    sidebarOverlay.style.display = 'block';
    setTimeout(function () { sidebarOverlay.classList.add('active'); }, 10);
    document.body.style.overflow = 'hidden';
  }

  function closeSidebar() {
    sidebar.classList.remove('open');
    sidebarOverlay.classList.remove('active');
    setTimeout(function () { sidebarOverlay.style.display = 'none'; }, 280);
    document.body.style.overflow = '';
  }

  if (hamburgerBtn) {
    hamburgerBtn.addEventListener('click', function () {
      sidebar.classList.contains('open') ? closeSidebar() : openSidebar();
    });
  }

  if (sidebarOverlay) {
    sidebarOverlay.addEventListener('click', closeSidebar);
  }

  navItems.forEach(function (item) {
    item.addEventListener('click', function (e) {
      var page = item.dataset.page;
      if (page === 'upload-workplan') {
        e.preventDefault();
        navItems.forEach(function (n) { n.classList.remove('active'); });
        item.classList.add('active');
        var m = PAGE_META[page] || PAGE_META['upload-workplan'];
        if (topbarTitle)    topbarTitle.textContent    = m.title;
        if (topbarSubtitle) topbarSubtitle.textContent = m.subtitle;
      }
      if (window.innerWidth <= 768) closeSidebar();
    });
  });

  if (notifBadge) notifBadge.style.display = 'block';

  /* ════════════════════════════════════════════════
     TRACK USED SEMESTERS
  ════════════════════════════════════════════════ */
  var usedSemesters = new Set();

  document.querySelectorAll('#plans-tbody tr').forEach(function (row) {
    var key = row.dataset.semester;
    if (key) usedSemesters.add(key);
  });

  buildSemesterDropdown(usedSemesters);

  /* ════════════════════════════════════════════════
     CLOSE ALL OPEN MENUS (click outside)
  ════════════════════════════════════════════════ */
  document.addEventListener('click', function (e) {
    if (!e.target.closest('.row-menu-wrap')) {
      document.querySelectorAll('.row-menu-dropdown.open').forEach(function (d) {
        d.classList.remove('open');
      });
    }
  });

  /* ════════════════════════════════════════════════
     DRAG & DROP / FILE INPUT (upload form)
  ════════════════════════════════════════════════ */
  var dropZone        = document.getElementById('drop-zone');
  var fileInput       = document.getElementById('file-input');
  var filePreviewRow  = document.getElementById('file-preview-row');
  var filePreviewIcon = document.getElementById('file-preview-icon');
  var filePreviewName = document.getElementById('file-preview-name');
  var filePreviewSize = document.getElementById('file-preview-size');
  var fileRemoveBtn   = document.getElementById('file-remove-btn');
  var selectedFile    = null;

  if (dropZone) {
    dropZone.addEventListener('click', function () { fileInput && fileInput.click(); });
    dropZone.addEventListener('keydown', function (e) {
      if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); fileInput && fileInput.click(); }
    });
    dropZone.addEventListener('dragover', function (e) {
      e.preventDefault();
      dropZone.classList.add('dragover');
    });
    dropZone.addEventListener('dragleave', function () {
      dropZone.classList.remove('dragover');
    });
    dropZone.addEventListener('drop', function (e) {
      e.preventDefault();
      dropZone.classList.remove('dragover');
      var files = e.dataTransfer.files;
      if (files && files.length > 0) handleFile(files[0]);
    });
  }

  if (fileInput) {
    fileInput.addEventListener('change', function () {
      if (fileInput.files && fileInput.files.length > 0) handleFile(fileInput.files[0]);
    });
  }

  function handleFile(file) {
    var allowed = [
      'application/pdf',
      'application/msword',
      'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
    ];
    if (allowed.indexOf(file.type) === -1) {
      alert('Only PDF or Word files are allowed.');
      return;
    }
    if (file.size > 30 * 1024 * 1024) {
      alert('File size exceeds 30MB limit.');
      return;
    }

    selectedFile = file;

    var iconClass = file.type === 'application/pdf' ? 'pdf-icon' : 'doc-icon';
    if (filePreviewIcon) filePreviewIcon.className = 'file-preview-icon ' + iconClass;
    if (filePreviewName) filePreviewName.textContent = file.name;
    if (filePreviewSize) filePreviewSize.textContent = formatSize(file.size);

    if (dropZone)       dropZone.style.display = 'none';
    if (filePreviewRow) filePreviewRow.classList.add('show');
  }

  if (fileRemoveBtn) {
    fileRemoveBtn.addEventListener('click', function () {
      selectedFile = null;
      if (fileInput)      fileInput.value = '';
      if (filePreviewRow) filePreviewRow.classList.remove('show');
      if (dropZone)       dropZone.style.display = '';
    });
  }

  /* ════════════════════════════════════════════════
     UPLOAD BUTTON
  ════════════════════════════════════════════════ */
  var uploadBtn    = document.getElementById('upload-btn');
  var planTitle    = document.getElementById('plan-title');
  var planSemester = document.getElementById('plan-semester');
  var successToast = document.getElementById('success-toast');

  if (uploadBtn) {
    uploadBtn.addEventListener('click', function () {
      var title    = planTitle    ? planTitle.value.trim() : '';
      var semester = planSemester ? planSemester.value     : '';

      if (!selectedFile) { alert('Please select a file to upload.'); return; }
      if (!title)        { alert('Please enter a work plan title.'); planTitle && planTitle.focus(); return; }

      var ext       = selectedFile.type === 'application/pdf' ? 'PDF' : 'DOC';
      var iconClass = ext === 'PDF' ? 'pdf' : 'doc';

      var today   = new Date();
      var months  = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
      var dateStr = months[today.getMonth()] + ' ' + today.getDate() + ', ' + today.getFullYear();

      usedSemesters.add(semester);

      addPlanRow({
        iconClass : iconClass,
        ext       : ext,
        name      : title,
        fname     : selectedFile.name,
        size      : formatSize(selectedFile.size),
        semester  : semester,
        date      : dateStr,
        fileObj   : selectedFile
      });

      buildSemesterDropdown(usedSemesters);

      /* Reset form */
      selectedFile = null;
      if (fileInput)      fileInput.value = '';
      if (filePreviewRow) filePreviewRow.classList.remove('show');
      if (dropZone)       dropZone.style.display = '';
      if (planTitle)      planTitle.value    = '';

      if (successToast) {
        successToast.classList.add('show');
        setTimeout(function () { successToast.classList.remove('show'); }, 3500);
      }
    });
  }

  /* ════════════════════════════════════════════════
     DELETE MODAL
  ════════════════════════════════════════════════ */
  var deleteModal      = document.getElementById('delete-modal');
  var deleteConfirmBtn = document.getElementById('delete-confirm-btn');
  var deleteCancelBtn  = document.getElementById('delete-cancel-btn');
  var pendingDeleteRow = null;

  function openDeleteModal(row, name) {
    pendingDeleteRow = row;
    var body = document.getElementById('delete-modal-body');
    if (body) body.textContent = 'Are you sure you want to remove "' + name + '"? This action cannot be undone.';
    deleteModal.style.display = 'flex';
  }

  function closeDeleteModal() {
    deleteModal.style.display = 'none';
    pendingDeleteRow = null;
  }

  if (deleteCancelBtn)  deleteCancelBtn.addEventListener('click', closeDeleteModal);
  if (deleteModal) {
    deleteModal.addEventListener('click', function (e) {
      if (e.target === deleteModal) closeDeleteModal();
    });
  }

  if (deleteConfirmBtn) {
    deleteConfirmBtn.addEventListener('click', function () {
      if (!pendingDeleteRow) return;
      var semKey = pendingDeleteRow.dataset.semester;
      if (semKey) usedSemesters.delete(semKey);
      pendingDeleteRow.remove();
      checkEmpty();
      buildSemesterDropdown(usedSemesters);
      closeDeleteModal();
    });
  }

  /* ════════════════════════════════════════════════
     EDIT MODAL
  ════════════════════════════════════════════════ */
  var editModal        = document.getElementById('edit-modal');
  var editCancelBtn    = document.getElementById('edit-cancel-btn');
  var editSaveBtn      = document.getElementById('edit-save-btn');
  var editPlanTitle    = document.getElementById('edit-plan-title');
  var editDropZone     = document.getElementById('edit-drop-zone');
  var editFileInput    = document.getElementById('edit-file-input');
  var editFilePreviewRow  = document.getElementById('edit-file-preview-row');
  var editFilePreviewIcon = document.getElementById('edit-file-preview-icon');
  var editFilePreviewName = document.getElementById('edit-file-preview-name');
  var editFilePreviewSize = document.getElementById('edit-file-preview-size');
  var editFileRemoveBtn   = document.getElementById('edit-file-remove-btn');
  var editDropLabel    = document.getElementById('edit-drop-label');
  var pendingEditRow   = null;
  var editSelectedFile = null;

  function openEditModal(row) {
    pendingEditRow = row;
    editSelectedFile = null;

    var nameEl = row.querySelector('.file-name');
    if (editPlanTitle) editPlanTitle.value = nameEl ? nameEl.textContent : '';

    /* reset file preview in modal */
    if (editFilePreviewRow) editFilePreviewRow.classList.remove('show');
    if (editDropZone)       editDropZone.style.display = '';
    if (editDropLabel)      editDropLabel.textContent = 'Click to replace file or drag & drop';
    if (editFileInput)      editFileInput.value = '';

    editModal.style.display = 'flex';
    if (editPlanTitle) editPlanTitle.focus();
  }

  function closeEditModal() {
    editModal.style.display = 'none';
    pendingEditRow   = null;
    editSelectedFile = null;
  }

  if (editCancelBtn) editCancelBtn.addEventListener('click', closeEditModal);
  if (editModal) {
    editModal.addEventListener('click', function (e) {
      if (e.target === editModal) closeEditModal();
    });
  }

  /* Edit drop zone */
  if (editDropZone) {
    editDropZone.addEventListener('click', function () { editFileInput && editFileInput.click(); });
    editDropZone.addEventListener('dragover', function (e) {
      e.preventDefault(); editDropZone.style.borderColor = '#2d5be3';
    });
    editDropZone.addEventListener('dragleave', function () {
      editDropZone.style.borderColor = '';
    });
    editDropZone.addEventListener('drop', function (e) {
      e.preventDefault();
      editDropZone.style.borderColor = '';
      var files = e.dataTransfer.files;
      if (files && files.length > 0) handleEditFile(files[0]);
    });
  }

  if (editFileInput) {
    editFileInput.addEventListener('change', function () {
      if (editFileInput.files && editFileInput.files.length > 0) handleEditFile(editFileInput.files[0]);
    });
  }

  function handleEditFile(file) {
    var allowed = [
      'application/pdf',
      'application/msword',
      'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
    ];
    if (allowed.indexOf(file.type) === -1) { alert('Only PDF or Word files are allowed.'); return; }
    if (file.size > 30 * 1024 * 1024)      { alert('File size exceeds 30MB limit.'); return; }

    editSelectedFile = file;

    var iconClass = file.type === 'application/pdf' ? 'pdf-icon' : 'doc-icon';
    if (editFilePreviewIcon) editFilePreviewIcon.className = 'file-preview-icon ' + iconClass;
    if (editFilePreviewName) editFilePreviewName.textContent = file.name;
    if (editFilePreviewSize) editFilePreviewSize.textContent = formatSize(file.size);

    if (editDropZone)       editDropZone.style.display = 'none';
    if (editFilePreviewRow) editFilePreviewRow.classList.add('show');
  }

  if (editFileRemoveBtn) {
    editFileRemoveBtn.addEventListener('click', function () {
      editSelectedFile = null;
      if (editFileInput)      editFileInput.value = '';
      if (editFilePreviewRow) editFilePreviewRow.classList.remove('show');
      if (editDropZone)       editDropZone.style.display = '';
    });
  }

  if (editSaveBtn) {
    editSaveBtn.addEventListener('click', function () {
      if (!pendingEditRow) return;
      var newTitle = editPlanTitle ? editPlanTitle.value.trim() : '';
      if (!newTitle) { alert('Please enter a work plan title.'); editPlanTitle && editPlanTitle.focus(); return; }

      /* Update title */
      var nameEl = pendingEditRow.querySelector('.file-name');
      if (nameEl) nameEl.textContent = newTitle;

      /* Update file info if new file selected */
      if (editSelectedFile) {
        var fnameEl = pendingEditRow.querySelector('.file-fname');
        var ext     = editSelectedFile.type === 'application/pdf' ? 'PDF' : 'DOC';
        var iconEl  = pendingEditRow.querySelector('.file-icon');

        if (fnameEl) fnameEl.textContent = editSelectedFile.name + ' \u00b7 ' + formatSize(editSelectedFile.size);
        if (iconEl)  { iconEl.className = 'file-icon ' + ext.toLowerCase(); iconEl.textContent = ext; }

        /* Update file-date to today */
        var dateEl = pendingEditRow.querySelector('.file-date');
        if (dateEl) {
          var today  = new Date();
          var months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
          dateEl.textContent = months[today.getMonth()] + ' ' + today.getDate() + ', ' + today.getFullYear();
        }
      }

      closeEditModal();
    });
  }

  /* ════════════════════════════════════════════════
     VIEW MODAL
  ════════════════════════════════════════════════ */
  var viewModal     = document.getElementById('view-modal');
  var viewCloseBtn  = document.getElementById('view-close-btn');
  var viewModalTitle = document.getElementById('view-modal-title');
  var viewModalMeta  = document.getElementById('view-modal-meta');
  var viewFilename   = document.getElementById('view-filename');

  function openViewModal(row) {
    var nameEl  = row.querySelector('.file-name');
    var fnameEl = row.querySelector('.file-fname');
    var dateEl  = row.querySelector('.file-date');

    if (viewModalTitle) viewModalTitle.textContent = nameEl  ? nameEl.textContent  : 'Work Plan';
    if (viewModalMeta)  viewModalMeta.textContent  = dateEl  ? dateEl.textContent  : '';
    if (viewFilename)   viewFilename.textContent   = fnameEl ? fnameEl.textContent : '';

    viewModal.style.display = 'flex';
  }

  function closeViewModal() {
    viewModal.style.display = 'none';
  }

  if (viewCloseBtn) viewCloseBtn.addEventListener('click', closeViewModal);
  if (viewModal) {
    viewModal.addEventListener('click', function (e) {
      if (e.target === viewModal) closeViewModal();
    });
  }

  /* ════════════════════════════════════════════════
     ADD ROW TO TABLE
  ════════════════════════════════════════════════ */
  function addPlanRow(data) {
    var tbody = document.getElementById('plans-tbody');
    if (!tbody) return;

    var tr = document.createElement('tr');
    tr.classList.add('clickable-row');
    tr.dataset.semester = data.semester || '';

    tr.innerHTML =
      '<td>' +
        '<div class="file-cell">' +
          '<div class="file-icon ' + data.iconClass + '">' + data.ext + '</div>' +
          '<div class="file-info">' +
            '<span class="file-name">'  + escapeHtml(data.name)  + '</span>' +
            '<span class="file-fname">' + escapeHtml(data.fname) + ' \u00b7 ' + data.size + '</span>' +
            '<span class="file-date">'  + data.date + '</span>' +
          '</div>' +
        '</div>' +
      '</td>' +
      '<td><span class="visible-badge">Club Members</span></td>' +
      '<td class="menu-cell">' +
        '<div class="row-menu-wrap">' +
          '<button class="row-menu-btn" title="More options" aria-label="More options">' +
            '<span></span><span></span><span></span>' +
          '</button>' +
          '<div class="row-menu-dropdown">' +
            '<button class="row-menu-item row-menu-view">' +
              '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>' +
              'View' +
            '</button>' +
            '<button class="row-menu-item row-menu-edit">' +
              '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>' +
              'Edit' +
            '</button>' +
            '<button class="row-menu-item row-menu-delete">' +
              '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/><path d="M10 11v6"/><path d="M14 11v6"/><path d="M9 6V4a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2"/></svg>' +
              'Delete' +
            '</button>' +
          '</div>' +
        '</div>' +
      '</td>';

    wireRowMenu(tr, data.name);
    wireRowClick(tr);

    var emptyState = document.getElementById('empty-state');
    if (emptyState) emptyState.style.display = 'none';

    tbody.appendChild(tr);
  }

  /* ════════════════════════════════════════════════
     WIRE ROW MENU BUTTONS
  ════════════════════════════════════════════════ */
  function wireRowMenu(row, nameOverride) {
    var menuBtn    = row.querySelector('.row-menu-btn');
    var dropdown   = row.querySelector('.row-menu-dropdown');
    var viewBtn    = row.querySelector('.row-menu-view');
    var editBtn    = row.querySelector('.row-menu-edit');
    var deleteBtn  = row.querySelector('.row-menu-delete');

    if (menuBtn && dropdown) {
      menuBtn.addEventListener('click', function (e) {
        e.stopPropagation();
        /* Close any other open dropdowns */
        document.querySelectorAll('.row-menu-dropdown.open').forEach(function (d) {
          if (d !== dropdown) d.classList.remove('open');
        });
        dropdown.classList.toggle('open');
      });
    }

    if (viewBtn) {
      viewBtn.addEventListener('click', function (e) {
        e.stopPropagation();
        if (dropdown) dropdown.classList.remove('open');
        openViewModal(row);
      });
    }

    if (editBtn) {
      editBtn.addEventListener('click', function (e) {
        e.stopPropagation();
        if (dropdown) dropdown.classList.remove('open');
        openEditModal(row);
      });
    }

    if (deleteBtn) {
      deleteBtn.addEventListener('click', function (e) {
        e.stopPropagation();
        if (dropdown) dropdown.classList.remove('open');
        var nameEl = row.querySelector('.file-name');
        var label  = nameOverride || (nameEl ? nameEl.textContent : 'this work plan');
        openDeleteModal(row, label);
      });
    }
  }

  /* Row click → view (but not if clicking on menu) */
  function wireRowClick(row) {
    row.addEventListener('click', function (e) {
      if (e.target.closest('.row-menu-wrap')) return;
      openViewModal(row);
    });
  }

  /* ════════════════════════════════════════════════
     WIRE PRE-RENDERED ROWS
  ════════════════════════════════════════════════ */
  document.querySelectorAll('#plans-tbody tr').forEach(function (row) {
    wireRowMenu(row);
    wireRowClick(row);
  });

  /* ════════════════════════════════════════════════
     HELPERS
  ════════════════════════════════════════════════ */
  function checkEmpty() {
    var tbody      = document.getElementById('plans-tbody');
    var emptyState = document.getElementById('empty-state');
    if (!tbody || !emptyState) return;
    emptyState.style.display = tbody.querySelectorAll('tr').length === 0 ? '' : 'none';
  }

}); // end DOMContentLoaded