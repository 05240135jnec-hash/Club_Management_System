'use strict';

/* ══════════════════════════════════════════════════════
   upload_blog.js  –  JNEC Club Management
   Upload Blog page logic
══════════════════════════════════════════════════════ */

const MAX_IMAGE_SIZE_MB    = 5;
const MAX_IMAGE_SIZE_BYTES = MAX_IMAGE_SIZE_MB * 1024 * 1024;
const ACCEPTED_IMAGE_TYPES = ['image/jpeg', 'image/png', 'image/webp', 'image/gif'];

/* ── Element refs ── */
const sidebar        = document.getElementById('sidebar');
const sidebarOverlay = document.getElementById('sidebar-overlay');
const hamburgerBtn   = document.getElementById('hamburger-btn');

const dropZone           = document.getElementById('drop-zone');
const fileInput          = document.getElementById('file-input');
const browseBtn          = document.getElementById('browse-btn');
const imagePreviewWrap   = document.getElementById('image-preview-wrap');
const imagePreviewThumb  = document.getElementById('image-preview-thumb');
const fileNameEl         = document.getElementById('file-name');
const fileSizeEl         = document.getElementById('file-size');
const fileRemoveBtn      = document.getElementById('file-remove-btn');
const submitBtn          = document.getElementById('upload-submit-btn');
const progressWrap       = document.getElementById('progress-wrap');
const progressFill       = document.getElementById('progress-bar-fill');
const progressLabel      = document.getElementById('progress-label');

const blogTitleInput   = document.getElementById('blog-title-input');
const blogAuthorInput  = document.getElementById('blog-author-input');
const blogContentInput = document.getElementById('blog-content-input');
const contentCharCount = document.getElementById('content-char-count');

const blogGrid      = document.getElementById('blog-grid');
const galleryEmpty  = document.getElementById('gallery-empty');
const sortSelect    = document.getElementById('sort-select');
const gallerySearch = document.getElementById('gallery-search');

const blogModal     = document.getElementById('blog-modal');
const modalBackdrop = document.getElementById('modal-backdrop');
const modalClose    = document.getElementById('modal-close');
const blogViewBody  = document.getElementById('blog-view-body');

const editModal        = document.getElementById('edit-modal');
const editModalBdrop   = document.getElementById('edit-modal-backdrop');
const editModalClose   = document.getElementById('edit-modal-close');
const editCancelBtn    = document.getElementById('edit-cancel-btn');
const editSaveBtn      = document.getElementById('edit-save-btn');
const editTitleInput   = document.getElementById('edit-title-input');
const editAuthorInput  = document.getElementById('edit-author-input');
const editContentInput = document.getElementById('edit-content-input');

const toast    = document.getElementById('toast');
const toastMsg = document.getElementById('toast-msg');

/* ── State ── */
let selectedFile      = null;
let selectedImageUrl  = null;
let selectedImageOrientation = 'landscape';
let editingCard       = null;
let activeDropdown    = null;

/* ══════════════════════════════
   SIDEBAR (mobile)
══════════════════════════════ */
function openSidebar() {
  sidebar.classList.add('open');
  sidebarOverlay.style.display = 'block';
  setTimeout(() => sidebarOverlay.classList.add('active'), 10);
  document.body.style.overflow = 'hidden';
}
function closeSidebar() {
  sidebar.classList.remove('open');
  sidebarOverlay.classList.remove('active');
  setTimeout(() => { sidebarOverlay.style.display = 'none'; }, 280);
  document.body.style.overflow = '';
}

hamburgerBtn.addEventListener('click', () =>
  sidebar.classList.contains('open') ? closeSidebar() : openSidebar()
);
sidebarOverlay.addEventListener('click', closeSidebar);
document.querySelectorAll('.nav-item').forEach(item => {
  item.addEventListener('click', () => { if (window.innerWidth <= 768) closeSidebar(); });
});

/* ══════════════════════════════
   SUBMIT BUTTON STATE
══════════════════════════════ */
function refreshSubmitBtn() {
  const hasTitle  = blogTitleInput.value.trim().length > 0;
  const hasAuthor = blogAuthorInput.value.trim().length > 0;
  submitBtn.disabled = !(hasTitle && hasAuthor);
}

blogTitleInput.addEventListener('input', refreshSubmitBtn);
blogAuthorInput.addEventListener('input', refreshSubmitBtn);

/* ══════════════════════════════
   CONTENT CHARACTER COUNT
══════════════════════════════ */
blogContentInput.addEventListener('input', () => {
  const len = blogContentInput.value.length;
  contentCharCount.textContent = `${len} / 5000`;
});

/* ══════════════════════════════
   DRAG & DROP
══════════════════════════════ */
dropZone.addEventListener('click', e => {
  if (e.target === browseBtn || browseBtn.contains(e.target)) return;
  fileInput.click();
});
browseBtn.addEventListener('click', e => { e.stopPropagation(); fileInput.click(); });

dropZone.addEventListener('dragover', e => { e.preventDefault(); dropZone.classList.add('dragover'); });
dropZone.addEventListener('dragleave', () => dropZone.classList.remove('dragover'));
dropZone.addEventListener('drop', e => {
  e.preventDefault();
  dropZone.classList.remove('dragover');
  const file = e.dataTransfer.files[0];
  if (file) handleImageFile(file);
});
fileInput.addEventListener('change', () => {
  if (fileInput.files[0]) handleImageFile(fileInput.files[0]);
  fileInput.value = '';
});

/* ══════════════════════════════
   IMAGE FILE HANDLING
══════════════════════════════ */
function handleImageFile(file) {
  if (!ACCEPTED_IMAGE_TYPES.includes(file.type)) {
    showToast('Only JPG, PNG, WebP, or GIF images are supported.');
    return;
  }
  if (file.size > MAX_IMAGE_SIZE_BYTES) {
    showToast(`Image too large. Max size is ${MAX_IMAGE_SIZE_MB}MB.`);
    return;
  }

  selectedFile = file;
  const url = URL.createObjectURL(file);
  selectedImageUrl = url;

  const img = new Image();
  img.onload = () => {
    selectedImageOrientation = img.naturalWidth >= img.naturalHeight ? 'landscape' : 'portrait';
  };
  img.src = url;

  imagePreviewThumb.src = url;
  fileNameEl.textContent = file.name;
  fileSizeEl.textContent = formatBytes(file.size);
  imagePreviewWrap.style.display = 'flex';
  dropZone.style.display = 'none';
}

function clearImagePreviewUI() {
  imagePreviewThumb.src = '';
  imagePreviewWrap.style.display = 'none';
  dropZone.style.display = 'flex';
}

fileRemoveBtn.addEventListener('click', () => {
  if (selectedImageUrl) URL.revokeObjectURL(selectedImageUrl);
  selectedFile = null;
  selectedImageUrl = null;
  selectedImageOrientation = 'landscape';
  clearImagePreviewUI();
});

/* ══════════════════════════════
   PUBLISH
══════════════════════════════ */
submitBtn.addEventListener('click', () => {
  const title   = blogTitleInput.value.trim();
  const author  = blogAuthorInput.value.trim();
  const content = blogContentInput.value.trim();

  if (!title)  { showToast('Please enter a blog title.');  blogTitleInput.focus();  return; }
  if (!author) { showToast('Please enter the author name.'); blogAuthorInput.focus(); return; }

  const capturedImageUrl         = selectedImageUrl;
  const capturedImageOrientation = selectedImageOrientation;

  submitBtn.disabled = true;
  submitBtn.textContent = 'Publishing…';
  progressWrap.style.display = 'flex';

  let pct = 0;
  const interval = setInterval(() => {
    pct += Math.random() * 18 + 4;
    if (pct >= 100) {
      pct = 100;
      clearInterval(interval);
      progressFill.style.width = '100%';
      progressLabel.textContent = '100%';
      setTimeout(() => {
        clearForm();
        addToGallery(title, author, content, capturedImageUrl, capturedImageOrientation);
        showToast('Blog published successfully!');
        updateEmptyState();
      }, 400);
    } else {
      progressFill.style.width = pct + '%';
      progressLabel.textContent = Math.floor(pct) + '%';
    }
  }, 200);
});

function clearForm() {
  blogTitleInput.value   = '';
  blogAuthorInput.value  = '';
  blogContentInput.value = '';
  contentCharCount.textContent = '0 / 5000';

  if (selectedImageUrl) URL.revokeObjectURL(selectedImageUrl);
  selectedFile = null;
  selectedImageUrl = null;
  selectedImageOrientation = 'landscape';
  clearImagePreviewUI();

  progressWrap.style.display = 'none';
  progressFill.style.width   = '0%';
  progressLabel.textContent  = '0%';
  submitBtn.disabled = true;
  submitBtn.innerHTML = `
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" width="16" height="16">
      <path d="M12 20h9"/>
      <path d="M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z"/>
    </svg>
    Publish Blog
  `;
}

/* ══════════════════════════════
   EMPTY STATE
══════════════════════════════ */
function updateEmptyState() {
  const cards = blogGrid.querySelectorAll('.blog-card');
  galleryEmpty.style.display = cards.length === 0 ? 'flex' : 'none';
}
updateEmptyState();

/* ══════════════════════════════
   ADD TO GALLERY
══════════════════════════════ */
function addToGallery(title, author, content, imageUrl, orientation) {
  const today     = new Date();
  const dateStr   = today.toISOString().split('T')[0];
  const dateLabel = today.toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' });

  const card = createBlogCard({ title, author, content, imageUrl, orientation: orientation || 'landscape', dateStr, dateLabel });
  card.dataset.fullContent = content || '';
  blogGrid.insertBefore(card, blogGrid.firstChild);
}

/* ══════════════════════════════
   CREATE BLOG CARD
   - With image   → normal card with cover strip
   - Without image → fixed-height card, content fills, meta pinned to bottom
══════════════════════════════ */
function createBlogCard({ title, author, content, imageUrl, orientation, dateStr, dateLabel }) {
  const card = document.createElement('div');

  /* Add modifier class for no-image variant so CSS can target it */
  card.className = imageUrl ? 'blog-card' : 'blog-card blog-card--no-image';

  card.dataset.date        = dateStr;
  card.dataset.title       = title.toLowerCase();
  card.dataset.author      = author.toLowerCase();
  card.dataset.content     = (content || '').toLowerCase();
  card.dataset.imageUrl    = imageUrl || '';
  card.dataset.orientation = orientation || 'landscape';

  const authorInitials = getInitials(author);
  const excerpt = content ? (content.length > 120 ? content.slice(0, 120) + '…' : content) : '';

  /* Cover — only rendered when image exists */
  let coverHtml = '';
  if (imageUrl) {
    if (orientation === 'portrait') {
      coverHtml = `
        <div class="blog-cover blog-cover--portrait">
          <img src="${escHtml(imageUrl)}" alt="Cover image" />
        </div>`;
    } else {
      coverHtml = `
        <div class="blog-cover blog-cover--landscape">
          <img src="${escHtml(imageUrl)}" alt="Cover image" />
        </div>`;
    }
  }

  card.innerHTML = `
    ${coverHtml}
    <div class="blog-info">
      <div class="blog-title-row">
        <p class="blog-title">${escHtml(title)}</p>
        <div class="blog-menu-wrap">
          <button class="blog-more-btn" title="More options" aria-label="More options">
            <svg viewBox="0 0 24 24" fill="currentColor" width="16" height="16">
              <circle cx="12" cy="5" r="1.5"/><circle cx="12" cy="12" r="1.5"/><circle cx="12" cy="19" r="1.5"/>
            </svg>
          </button>
          <div class="blog-dropdown">
            <button class="blog-dropdown-btn view-btn">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/>
                <circle cx="12" cy="12" r="3"/>
              </svg>
              View Blog
            </button>
            <button class="blog-dropdown-btn edit-btn">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/>
                <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/>
              </svg>
              Edit Details
            </button>
            <div class="blog-dropdown-divider"></div>
            <button class="blog-dropdown-btn delete-btn">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <polyline points="3 6 5 6 21 6"/>
                <path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/>
                <path d="M10 11v6"/><path d="M14 11v6"/>
                <path d="M9 6V4a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2"/>
              </svg>
              Delete
            </button>
          </div>
        </div>
      </div>

      <div class="blog-author-row">
        <div class="blog-author-avatar">${escHtml(authorInitials)}</div>
        <span class="blog-author-name">${escHtml(author)}</span>
      </div>

      ${excerpt ? `<p class="blog-excerpt">${escHtml(excerpt)}</p>` : ''}

      <div class="blog-meta-row">
        <span class="blog-date">${escHtml(dateLabel)}</span>
        <span class="blog-read-more">Read more →</span>
      </div>
    </div>
  `;

  wireCardEvents(card);
  return card;
}

/* ══════════════════════════════
   WIRE CARD EVENTS
══════════════════════════════ */
function wireCardEvents(card) {
  card.addEventListener('click', e => {
    const isMenuArea = e.target.closest('.blog-menu-wrap');
    if (!isMenuArea) openBlogModal(card);
  });

  const moreBtn  = card.querySelector('.blog-more-btn');
  const dropdown = card.querySelector('.blog-dropdown');

  if (moreBtn && dropdown) {
    moreBtn.addEventListener('click', e => {
      e.stopPropagation();
      const isOpen = dropdown.classList.contains('open');
      closeAllDropdowns();
      if (!isOpen) { dropdown.classList.add('open'); activeDropdown = dropdown; }
    });
  }

  const viewBtn = card.querySelector('.view-btn');
  if (viewBtn) {
    viewBtn.addEventListener('click', e => {
      e.stopPropagation(); closeAllDropdowns(); openBlogModal(card);
    });
  }

  const editBtn = card.querySelector('.edit-btn');
  if (editBtn) {
    editBtn.addEventListener('click', e => {
      e.stopPropagation(); closeAllDropdowns(); openEditModal(card);
    });
  }

  const deleteBtn = card.querySelector('.delete-btn');
  if (deleteBtn) {
    deleteBtn.addEventListener('click', e => {
      e.stopPropagation(); closeAllDropdowns(); deleteCard(card);
    });
  }
}

/* ══════════════════════════════
   CLOSE ALL DROPDOWNS
══════════════════════════════ */
function closeAllDropdowns() {
  document.querySelectorAll('.blog-dropdown.open').forEach(d => d.classList.remove('open'));
  activeDropdown = null;
}
document.addEventListener('click', () => closeAllDropdowns());

/* ══════════════════════════════
   DELETE CARD
══════════════════════════════ */
function deleteCard(card) {
  if (card.dataset.imageUrl && card.dataset.imageUrl.startsWith('blob:')) {
    URL.revokeObjectURL(card.dataset.imageUrl);
  }
  card.classList.add('card-removing');
  setTimeout(() => {
    card.remove();
    showToast('Blog deleted.');
    updateEmptyState();
    applySearch(gallerySearch.value);
  }, 260);
}

/* ══════════════════════════════
   BLOG VIEW MODAL
══════════════════════════════ */
function openBlogModal(card) {
  const title          = card.querySelector('.blog-title')?.textContent || '';
  const author         = card.querySelector('.blog-author-name')?.textContent || '';
  const dateLabel      = card.querySelector('.blog-date')?.textContent || '';
  const imageUrl       = card.dataset.imageUrl || '';
  const orientation    = card.dataset.orientation || 'landscape';
  const fullContent    = card.dataset.fullContent || '';
  const authorInitials = getInitials(author);

  let coverHtml = '';
  if (imageUrl) {
    if (orientation === 'portrait') {
      coverHtml = `<div class="bv-cover bv-cover--portrait"><img src="${escHtml(imageUrl)}" alt="Cover" /></div>`;
    } else {
      coverHtml = `<div class="bv-cover bv-cover--landscape"><img src="${escHtml(imageUrl)}" alt="Cover" /></div>`;
    }
  }

  blogViewBody.innerHTML = `
    ${coverHtml}
    <div class="bv-content">
      <h1 class="bv-title">${escHtml(title)}</h1>
      <div class="bv-meta">
        <div class="bv-author-chip">
          <div class="bv-author-avatar">${escHtml(authorInitials)}</div>
          <span class="bv-author-name">${escHtml(author)}</span>
        </div>
        <span class="bv-date-chip">${escHtml(dateLabel)}</span>
      </div>
      <div class="bv-divider"></div>
      ${fullContent
        ? `<div class="bv-body">${escHtml(fullContent)}</div>`
        : `<p class="bv-no-content">No content written for this blog post.</p>`
      }
    </div>
  `;

  blogModal.classList.add('open');
  document.body.style.overflow = 'hidden';
}

function closeBlogModal() {
  blogModal.classList.remove('open');
  document.body.style.overflow = '';
}

modalClose.addEventListener('click', closeBlogModal);
modalBackdrop.addEventListener('click', closeBlogModal);

/* ══════════════════════════════
   EDIT MODAL
══════════════════════════════ */
function openEditModal(card) {
  editingCard = card;
  editTitleInput.value   = card.querySelector('.blog-title')?.textContent || '';
  editAuthorInput.value  = card.querySelector('.blog-author-name')?.textContent || '';
  editContentInput.value = card.dataset.fullContent || '';
  editModal.classList.add('open');
  document.body.style.overflow = 'hidden';
  editTitleInput.focus();
}

function closeEditModal() {
  editModal.classList.remove('open');
  document.body.style.overflow = '';
  editingCard = null;
}

editModalClose.addEventListener('click', closeEditModal);
editModalBdrop.addEventListener('click', closeEditModal);
editCancelBtn.addEventListener('click', closeEditModal);

editSaveBtn.addEventListener('click', () => {
  if (!editingCard) return;

  const newTitle   = editTitleInput.value.trim();
  const newAuthor  = editAuthorInput.value.trim();
  const newContent = editContentInput.value.trim();

  if (!newTitle) {
    editTitleInput.focus();
    editTitleInput.classList.add('error');
    setTimeout(() => editTitleInput.classList.remove('error'), 1800);
    return;
  }
  if (!newAuthor) {
    editAuthorInput.focus();
    editAuthorInput.classList.add('error');
    setTimeout(() => editAuthorInput.classList.remove('error'), 1800);
    return;
  }

  const titleEl = editingCard.querySelector('.blog-title');
  if (titleEl) titleEl.textContent = newTitle;

  const authorNameEl = editingCard.querySelector('.blog-author-name');
  if (authorNameEl) authorNameEl.textContent = newAuthor;

  const authorAvatarEl = editingCard.querySelector('.blog-author-avatar');
  if (authorAvatarEl) authorAvatarEl.textContent = getInitials(newAuthor);

  let excerptEl = editingCard.querySelector('.blog-excerpt');
  if (newContent) {
    const excerpt = newContent.length > 120 ? newContent.slice(0, 120) + '…' : newContent;
    if (!excerptEl) {
      excerptEl = document.createElement('p');
      excerptEl.className = 'blog-excerpt';
      const authorRow = editingCard.querySelector('.blog-author-row');
      authorRow.insertAdjacentElement('afterend', excerptEl);
    }
    excerptEl.textContent = excerpt;
  } else {
    if (excerptEl) excerptEl.remove();
  }

  editingCard.dataset.title       = newTitle.toLowerCase();
  editingCard.dataset.author      = newAuthor.toLowerCase();
  editingCard.dataset.fullContent = newContent;
  editingCard.dataset.content     = newContent.toLowerCase();

  closeEditModal();
  showToast('Blog updated successfully!');
  applySearch(gallerySearch.value);
});

/* ══════════════════════════════
   SEARCH
══════════════════════════════ */
function applySearch(query) {
  const q = query.toLowerCase().trim();
  const cards = Array.from(blogGrid.querySelectorAll('.blog-card'));
  let visibleCount = 0;

  cards.forEach(card => {
    const match = !q
      || (card.dataset.title   || '').includes(q)
      || (card.dataset.author  || '').includes(q)
      || (card.dataset.content || '').includes(q);
    card.style.display = match ? '' : 'none';
    if (match) visibleCount++;
  });

  let noResults = blogGrid.querySelector('.gallery-no-results');
  if (!noResults) {
    noResults = document.createElement('p');
    noResults.className = 'gallery-no-results';
    noResults.textContent = 'No blogs match your search.';
    blogGrid.appendChild(noResults);
  }
  noResults.classList.toggle('show', q.length > 0 && visibleCount === 0);
}

gallerySearch.addEventListener('input', e => applySearch(e.target.value));

/* ══════════════════════════════
   SORT
══════════════════════════════ */
sortSelect.addEventListener('change', () => {
  const val   = sortSelect.value;
  const cards = Array.from(blogGrid.querySelectorAll('.blog-card'));

  cards.sort((a, b) => {
    if (val === 'new-to-old') return (b.dataset.date || '').localeCompare(a.dataset.date || '');
    if (val === 'old-to-new') return (a.dataset.date || '').localeCompare(b.dataset.date || '');
    if (val === 'name')       return (a.dataset.title || '').localeCompare(b.dataset.title || '');
    return 0;
  });

  cards.forEach(c => blogGrid.appendChild(c));
});

/* ══════════════════════════════
   ESCAPE KEY
══════════════════════════════ */
document.addEventListener('keydown', e => {
  if (e.key === 'Escape') {
    closeBlogModal();
    closeEditModal();
    closeAllDropdowns();
  }
});

/* ══════════════════════════════
   TOAST
══════════════════════════════ */
let toastTimer;
function showToast(msg) {
  toastMsg.textContent = msg;
  toast.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toast.classList.remove('show'), 3200);
}

/* ══════════════════════════════
   UTILS
══════════════════════════════ */
function formatBytes(bytes) {
  if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
  return (bytes / (1024 * 1024)).toFixed(2) + ' MB';
}

function getInitials(name) {
  const parts = name.trim().split(/\s+/);
  if (parts.length === 1) return parts[0].slice(0, 2).toUpperCase();
  return (parts[0][0] + parts[parts.length - 1][0]).toUpperCase();
}

function escHtml(str) {
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}