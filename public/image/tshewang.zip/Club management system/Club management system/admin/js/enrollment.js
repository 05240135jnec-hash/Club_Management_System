'use strict';

/* ══════════════════════════════════════════════════════════
   ENROLLMENT.JS — JNEC Club Management
   ══════════════════════════════════════════════════════════ */

/* ══ DOM ══ */
var hamburgerBtn    = document.getElementById('hamburger-btn');
var sidebar         = document.getElementById('sidebar');
var sidebarOverlay  = document.getElementById('sidebar-overlay');

var keyInput        = document.getElementById('key-input');
var keyEditBtn      = document.getElementById('key-edit-btn');
var maxInput        = document.getElementById('max-input');
var btnCreateKey    = document.getElementById('btn-create-key');

var noKeyState      = document.getElementById('no-key-state');
var activeKeyBox    = document.getElementById('active-key-box');
var keyDisplay      = document.getElementById('key-display');
var btnCopy         = document.getElementById('btn-copy');
var btnRevoke       = document.getElementById('btn-revoke');

var statJoined      = document.getElementById('stat-joined');
var statMax         = document.getElementById('stat-max');
var statSlots       = document.getElementById('stat-slots');

/* ══ STATE ══ */
var activeKey = {
  key: 'music club_2025',
  max: 30,
  joined: 0
};
var hasActiveKey = true;

/* ══ MOBILE SIDEBAR ══ */
function openSidebar() {
  sidebar.classList.add('open');
  sidebarOverlay.style.display = 'block';
  setTimeout(function () { sidebarOverlay.classList.add('active'); }, 10);
  document.body.style.overflow = 'hidden';
}

function closeSidebar() {
  sidebar.classList.remove('open');
  sidebarOverlay.classList.remove('active');
  setTimeout(function () { sidebarOverlay.style.display = 'none'; }, 280);
  document.body.style.overflow = '';
}

if (hamburgerBtn) {
  hamburgerBtn.addEventListener('click', function () {
    sidebar.classList.contains('open') ? closeSidebar() : openSidebar();
  });
}

if (sidebarOverlay) {
  sidebarOverlay.addEventListener('click', closeSidebar);
}

/* Close sidebar on nav click (mobile) */
document.querySelectorAll('.nav-item').forEach(function (item) {
  item.addEventListener('click', function () {
    var href = item.getAttribute('href');
    if (!href || href === '#') return;
    if (window.innerWidth <= 768) closeSidebar();
  });
});

/* ══ RENDER ACTIVE KEY ══ */
function renderActiveKey() {
  if (!hasActiveKey) {
    noKeyState.style.display  = 'flex';
    activeKeyBox.style.display = 'none';
    return;
  }

  noKeyState.style.display   = 'none';
  activeKeyBox.style.display = 'block';

  keyDisplay.textContent     = activeKey.key;
  statJoined.textContent     = activeKey.joined;
  statMax.textContent        = activeKey.max;
  statSlots.textContent      = Math.max(0, activeKey.max - activeKey.joined);
}

/* ══ PENCIL / EDIT BUTTON ══ */
if (keyEditBtn) {
  keyEditBtn.addEventListener('click', function () {
    keyInput.focus();
    keyInput.select();
  });
}

/* ══ CREATE KEY ══ */
if (btnCreateKey) {
  btnCreateKey.addEventListener('click', function () {
    var key = (keyInput.value || '').trim();
    var max = parseInt(maxInput.value, 10);

    /* Validation */
    if (!key) {
      keyInput.style.borderColor = '#dc2626';
      keyInput.focus();
      setTimeout(function () { keyInput.style.borderColor = ''; }, 1500);
      return;
    }

    if (!max || max < 1) {
      maxInput.style.borderColor = '#dc2626';
      maxInput.focus();
      setTimeout(function () { maxInput.style.borderColor = ''; }, 1500);
      return;
    }

    /* Save and display */
    activeKey.key    = key;
    activeKey.max    = max;
    activeKey.joined = 0;
    hasActiveKey     = true;

    /* Clear inputs */
    keyInput.value = '';
    maxInput.value = '';

    renderActiveKey();

    /* Button feedback */
    btnCreateKey.textContent = '✓ Key Created!';
    btnCreateKey.style.background = '#16a34a';
    setTimeout(function () {
      btnCreateKey.textContent = 'Create Key';
      btnCreateKey.style.background = '';
    }, 2200);
  });
}

/* ══ COPY KEY ══ */
if (btnCopy) {
  btnCopy.addEventListener('click', function () {
    var text = activeKey.key;

    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(text).then(function () {
        showCopied();
      }).catch(function () {
        fallbackCopy(text);
      });
    } else {
      fallbackCopy(text);
    }
  });
}

function fallbackCopy(text) {
  var ta = document.createElement('textarea');
  ta.value = text;
  ta.style.position = 'fixed';
  ta.style.opacity  = '0';
  document.body.appendChild(ta);
  ta.focus(); ta.select();
  try { document.execCommand('copy'); } catch (e) {}
  document.body.removeChild(ta);
  showCopied();
}

function showCopied() {
  var orig = btnCopy.innerHTML;
  btnCopy.textContent = '✓ Copied!';
  btnCopy.classList.add('copied');
  setTimeout(function () {
    btnCopy.innerHTML = orig;
    btnCopy.classList.remove('copied');
  }, 2000);
}

/* ══ REVOKE KEY ══ */
if (btnRevoke) {
  btnRevoke.addEventListener('click', function () {
    if (!confirm('Are you sure you want to revoke the enrollment key "' + activeKey.key + '"? Students will no longer be able to join using this key.')) return;

    hasActiveKey = false;
    activeKey    = { key: '', max: 0, joined: 0 };
    renderActiveKey();
  });
}

/* ══ INIT ══ */
document.addEventListener('DOMContentLoaded', function () {
  renderActiveKey();
});