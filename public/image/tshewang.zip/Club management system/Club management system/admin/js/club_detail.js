'use strict';

// ── Club data (in a real app this comes from your backend) ──
var clubData = {
  name:        'JNEC Music Club',
  category:    'Entertainment',
  description: 'The JNEC Music Club brings together students who are passionate about music — from traditional Bhutanese songs to modern genres. Members practice instruments, perform at college events, and organize musical concerts throughout the year.',
  objectives: [
    'To develop skills in music performance and appreciation among JNEC students.',
    'To develop an analytical, creative and intuitive understanding of music as a cultural language.',
    'To enrich the campus through concerts, public events, and provide opportunities for traditional and contemporary musical expression.',
    'To contribute to college life by organizing musical events and building a vibrant campus community.'
  ],
  members:   '32+',         // READ-ONLY — not editable
  advisor:   'Ms. Sonam Choden',
  secretary: 'Tshering Norbu'
};

// ── DOM refs ──
var viewMode    = document.getElementById('view-mode');
var editMode    = document.getElementById('edit-mode');
var editBtn     = document.getElementById('edit-btn');
var cancelBtn   = document.getElementById('cancel-btn');
var saveBtn     = document.getElementById('save-btn');
var toast       = document.getElementById('toast');

// View elements
var viewClubName    = document.getElementById('view-club-name');
var viewCategory    = document.getElementById('view-category');
var viewDescription = document.getElementById('view-description');
var viewObjName     = document.getElementById('view-obj-name');
var viewObjectives  = document.getElementById('view-objectives');
var viewMembers     = document.getElementById('view-members');
var viewType        = document.getElementById('view-type');
var viewAdvisor     = document.getElementById('view-advisor');
var viewSecretary   = document.getElementById('view-secretary');

// Edit inputs
var editClubName    = document.getElementById('edit-club-name');
var editCategory    = document.getElementById('edit-category');
var editDescription = document.getElementById('edit-description');
var editObjectives  = document.getElementById('edit-objectives');
var editAdvisor     = document.getElementById('edit-advisor');
var editSecretary   = document.getElementById('edit-secretary');

// ── Render view mode from data ──
function renderView() {
  viewClubName.textContent    = clubData.name;
  viewCategory.textContent    = clubData.category;
  viewDescription.textContent = clubData.description;
  viewObjName.textContent     = clubData.name;
  viewMembers.textContent     = clubData.members;
  viewType.textContent        = clubData.category;
  viewAdvisor.textContent     = clubData.advisor;
  viewSecretary.textContent   = clubData.secretary;

  // Rebuild objectives list
  viewObjectives.innerHTML = '';
  clubData.objectives.forEach(function(obj) {
    var li = document.createElement('li');
    li.textContent = obj;
    viewObjectives.appendChild(li);
  });
}

// ── Populate edit form from data ──
function populateEditForm() {
  editClubName.value    = clubData.name;
  editCategory.value    = clubData.category;
  editDescription.value = clubData.description;
  editObjectives.value  = clubData.objectives.join('\n');
  editAdvisor.value     = clubData.advisor;
  editSecretary.value   = clubData.secretary;
}

// ── Switch to EDIT mode ──
editBtn.addEventListener('click', function() {
  populateEditForm();
  viewMode.classList.add('hidden');
  editMode.classList.remove('hidden');
  editClubName.focus();
});

// ── Cancel edit ──
cancelBtn.addEventListener('click', function() {
  editMode.classList.add('hidden');
  viewMode.classList.remove('hidden');
});

// ── Save changes ──
saveBtn.addEventListener('click', function() {
  // Basic validation
  var name = editClubName.value.trim();
  if (!name) {
    editClubName.focus();
    editClubName.style.borderColor = '#e53e3e';
    setTimeout(function() { editClubName.style.borderColor = ''; }, 1500);
    return;
  }

  // Commit to data store
  clubData.name        = name;
  clubData.category    = editCategory.value;
  clubData.description = editDescription.value.trim();
  clubData.advisor     = editAdvisor.value.trim() || clubData.advisor;
  clubData.secretary   = editSecretary.value.trim() || clubData.secretary;

  // Parse objectives (split by newline, ignore empty)
  var rawObjectives = editObjectives.value.split('\n')
    .map(function(s) { return s.trim(); })
    .filter(function(s) { return s.length > 0; });

  if (rawObjectives.length > 0) {
    clubData.objectives = rawObjectives;
  }

  // Re-render and switch back to view
  renderView();
  editMode.classList.add('hidden');
  viewMode.classList.remove('hidden');

  // Show toast
  showToast();
});

// ── Toast ──
var toastTimer = null;
function showToast() {
  toast.classList.remove('hidden');
  if (toastTimer) clearTimeout(toastTimer);
  toastTimer = setTimeout(function() {
    toast.classList.add('hidden');
  }, 3000);
}

// ── Initial render ──
renderView();

// ══════════════════════════════════════════════════════
// MOBILE SIDEBAR TOGGLE
// ══════════════════════════════════════════════════════
var hamburgerBtn   = document.getElementById('hamburger-btn');
var sidebar        = document.getElementById('sidebar');
var sidebarOverlay = document.getElementById('sidebar-overlay');

function openSidebar() {
  if (sidebar)        sidebar.classList.add('open');
  if (sidebarOverlay) {
    sidebarOverlay.style.display = 'block';
    setTimeout(function() { sidebarOverlay.classList.add('active'); }, 10);
  }
  document.body.style.overflow = 'hidden';
}

function closeSidebar() {
  if (sidebar)        sidebar.classList.remove('open');
  if (sidebarOverlay) {
    sidebarOverlay.classList.remove('active');
    setTimeout(function() { sidebarOverlay.style.display = 'none'; }, 280);
  }
  document.body.style.overflow = '';
}

if (hamburgerBtn) {
  hamburgerBtn.addEventListener('click', function() {
    sidebar && sidebar.classList.contains('open') ? closeSidebar() : openSidebar();
  });
}

if (sidebarOverlay) {
  sidebarOverlay.addEventListener('click', closeSidebar);
}

// Close sidebar when a nav item is clicked on mobile
var navItems = document.querySelectorAll('.nav-item');
navItems.forEach(function(item) {
  item.addEventListener('click', function() {
    if (window.innerWidth <= 768) {
      closeSidebar();
    }
  });
});