'use strict';

/* ══════════════════════════════════════════════════════════
   ATTENDANCE.JS — JNEC Club Management
   ══════════════════════════════════════════════════════════ */

/* ══ MEMBERS DATA ══ */
var ALL_MEMBERS = [
  { id: 1, name: 'Karma Wangchuk',  initials: 'KW', color: '#e07a4a', year: 4, dept: 'Civil Engg' },
  { id: 2, name: 'Pema Deki',       initials: 'PD', color: '#7c6fcd', year: 3, dept: 'Electrical Engg' },
  { id: 3, name: 'Sonam Yangzom',   initials: 'SY', color: '#4aab8a', year: 3, dept: 'IT Engg' },
  { id: 4, name: 'Tshering Norbu',  initials: 'TN', color: '#2d5be3', year: 4, dept: 'Civil Engg' },
  { id: 5, name: 'Dechen Wangmo',   initials: 'DW', color: '#d44f8a', year: 2, dept: 'IT Engg' },
  { id: 6, name: 'Rinchen Norbu',   initials: 'RN', color: '#3aabb0', year: 4, dept: 'Electrical Engg' },
  { id: 7, name: 'Tashi Dorji',     initials: 'TD', color: '#e05c5c', year: 2, dept: 'Civil Engg' }
];

/* ══ SESSIONS DATA ══ */
var SESSIONS = [
  {
    id: 1, name: 'Jan Meeting', date: '2026-01-15',
    attendance: { 1: true, 2: true, 3: false, 4: true, 5: true, 6: true, 7: false }
  },
  {
    id: 2, name: 'Feb Meeting', date: '2026-02-10',
    attendance: { 1: false, 2: true, 3: true, 4: true, 5: false, 6: true, 7: true }
  },
  {
    id: 3, name: 'Feb Workshop', date: '2026-02-24',
    attendance: { 1: true, 2: true, 3: true, 4: false, 5: true, 6: true, 7: true }
  },
  {
    id: 4, name: 'Mar Meeting', date: '2026-03-18',
    attendance: { 1: true, 2: true, 3: true, 4: true, 5: true, 6: true, 7: true }
  }
];

var nextSessionId = 5;

/* ══ STATE ══ */
var state = {
  activeSessionId: 4,
  sessionSearch: '',
  memberSearch: '',
  currentAbsent: {}
};

/* ══ DOM ══ */
var hamburgerBtn   = document.getElementById('hamburger-btn');
var sidebar        = document.getElementById('sidebar');
var sidebarOverlay = document.getElementById('sidebar-overlay');

var btnNewSession   = document.getElementById('btn-new-session');
var newSessionForm  = document.getElementById('new-session-form');
var sessionNameInput = document.getElementById('session-name-input');
var sessionDateInput = document.getElementById('session-date-input');
var btnCreate       = document.getElementById('btn-create');
var btnCancel       = document.getElementById('btn-cancel');

var sessionsList    = document.getElementById('sessions-list');
var sessionsCount   = document.getElementById('sessions-count');
var sessionSearch   = document.getElementById('session-search');

var detailEmpty     = document.getElementById('detail-empty');
var detailContent   = document.getElementById('detail-content');
var detailSessionName = document.getElementById('detail-session-name');
var detailSessionDate = document.getElementById('detail-session-date');
var memberSearch    = document.getElementById('member-search');
var attTbody        = document.getElementById('att-tbody');
var countPresent    = document.getElementById('count-present');
var countAbsent     = document.getElementById('count-absent');
var countTotal      = document.getElementById('count-total');
var btnSave         = document.getElementById('btn-save');

var statTotal       = document.getElementById('stat-total');
var statFull        = document.getElementById('stat-full');
var statFullSub     = document.getElementById('stat-full-sub');
var statLow         = document.getElementById('stat-low');
var statLowSub      = document.getElementById('stat-low-sub');

/* ══ MOBILE SIDEBAR ══ */
function openSidebar() {
  sidebar.classList.add('open');
  sidebarOverlay.style.display = 'block';
  setTimeout(function () { sidebarOverlay.classList.add('active'); }, 10);
  document.body.style.overflow = 'hidden';
}

function closeSidebar() {
  sidebar.classList.remove('open');
  sidebarOverlay.classList.remove('active');
  setTimeout(function () { sidebarOverlay.style.display = 'none'; }, 280);
  document.body.style.overflow = '';
}

if (hamburgerBtn) {
  hamburgerBtn.addEventListener('click', function () {
    sidebar.classList.contains('open') ? closeSidebar() : openSidebar();
  });
}
if (sidebarOverlay) {
  sidebarOverlay.addEventListener('click', closeSidebar);
}

/* ══ NAV ITEMS ══ */
document.querySelectorAll('.nav-item').forEach(function (item) {
  item.addEventListener('click', function () {
    if (window.innerWidth <= 768) closeSidebar();
  });
});

/* ══ HELPERS ══ */
function formatDate(dateStr) {
  var d = new Date(dateStr + 'T00:00:00');
  var months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
  return months[d.getMonth()] + ' ' + d.getDate() + ', ' + d.getFullYear();
}

function yearLabel(y) {
  return ['','1st','2nd','3rd','4th'][y] + ' Year';
}

function getSessionAttPct(session) {
  var total = ALL_MEMBERS.length;
  var present = ALL_MEMBERS.filter(function (m) { return session.attendance[m.id] !== false; }).length;
  return Math.round((present / total) * 100);
}

function getMemberOverallPct(memberId) {
  if (!SESSIONS.length) return 100;
  var present = SESSIONS.filter(function (s) { return s.attendance[memberId] !== false; }).length;
  return Math.round((present / SESSIONS.length) * 100);
}

function attClass(pct) {
  if (pct >= 90) return 'high';
  if (pct >= 75) return 'medium';
  return 'low';
}

/* ══ STATS ══ */
function updateStats() {
  var total = SESSIONS.length;
  var full  = SESSIONS.filter(function (s) { return getSessionAttPct(s) === 100; }).length;
  var low   = SESSIONS.filter(function (s) { return getSessionAttPct(s) < 75; }).length;

  statTotal.textContent   = total;
  statFull.textContent    = full;
  statLow.textContent     = low;
  statFullSub.textContent = 'Members 100%';
  statLowSub.textContent  = 'Below 75%';
}

/* ══ SESSIONS LIST ══ */
function renderSessions() {
  var q = state.sessionSearch.toLowerCase();
  var filtered = SESSIONS.filter(function (s) {
    return s.name.toLowerCase().indexOf(q) !== -1;
  });

  sessionsCount.textContent = SESSIONS.length + ' session' + (SESSIONS.length !== 1 ? 's' : '');

  if (!filtered.length) {
    sessionsList.innerHTML = '<div style="padding:20px 16px;font-size:13px;color:#8892a4;">No sessions found</div>';
    return;
  }

  sessionsList.innerHTML = filtered.map(function (s) {
    var pct = getSessionAttPct(s);
    var cls = attClass(pct);
    var active = s.id === state.activeSessionId ? 'active' : '';
    return '<div class="session-item ' + active + '" data-id="' + s.id + '">' +
      '<div class="session-item-name">' + s.name + '</div>' +
      '<div class="session-item-date">' + formatDate(s.date) + '</div>' +
      '<div class="session-item-att ' + cls + '">' + pct + '% attendance</div>' +
    '</div>';
  }).join('');

  sessionsList.querySelectorAll('.session-item').forEach(function (item) {
    item.addEventListener('click', function () {
      state.activeSessionId = parseInt(item.dataset.id);
      loadSession();
      renderSessions();
    });
  });
}

/* ══ LOAD SESSION ══ */
function loadSession() {
  var session = SESSIONS.find(function (s) { return s.id === state.activeSessionId; });

  if (!session) {
    detailEmpty.style.display = 'flex';
    detailContent.style.display = 'none';
    return;
  }

  detailEmpty.style.display = 'none';
  detailContent.style.display = 'flex';

  detailSessionName.textContent = session.name;
  detailSessionDate.textContent = formatDate(session.date);

  /* Copy attendance into working state */
  state.currentAbsent = {};
  ALL_MEMBERS.forEach(function (m) {
    if (session.attendance[m.id] === false) {
      state.currentAbsent[m.id] = true;
    }
  });

  renderMembersTable();
}

/* ══ MEMBERS TABLE ══ */
function renderMembersTable() {
  var q = state.memberSearch.toLowerCase();
  var filtered = ALL_MEMBERS.filter(function (m) {
    return m.name.toLowerCase().indexOf(q) !== -1 ||
           m.dept.toLowerCase().indexOf(q) !== -1;
  });

  var totalShown   = filtered.length;
  var absentCount  = filtered.filter(function (m) { return state.currentAbsent[m.id]; }).length;
  var presentCount = totalShown - absentCount;

  countPresent.textContent = presentCount;
  countAbsent.textContent  = absentCount;
  countTotal.textContent   = ALL_MEMBERS.length;

  attTbody.innerHTML = filtered.map(function (m) {
    var isAbsent  = !!state.currentAbsent[m.id];
    var overallPct = getMemberOverallPct(m.id);
    var lowClass   = overallPct < 75 ? 'low' : '';
    var badgeHtml  = isAbsent
      ? '<span class="badge-absent">Absent</span>'
      : '<span class="badge-present">Present</span>';
    var lowLabel   = overallPct < 75 ? ' <span style="color:#dc2626;font-size:11px;font-weight:600;">Low</span>' : '';

    return '<tr data-id="' + m.id + '">' +
      '<td><div class="member-cell">' +
        '<div class="member-avatar" style="background:' + m.color + '">' + m.initials + '</div>' +
        '<div><div class="member-name">' + m.name + '</div>' +
        '<div class="member-dept">' + m.dept + '</div></div>' +
      '</div></td>' +
      '<td class="year-cell">' + yearLabel(m.year) + '</td>' +
      '<td><input type="checkbox" class="absent-check" data-id="' + m.id + '" ' + (isAbsent ? 'checked' : '') + ' /></td>' +
      '<td>' + badgeHtml + '</td>' +
      '<td><div class="overall-cell">' +
        '<div class="overall-bar"><div class="overall-bar-fill" style="width:' + overallPct + '%"></div></div>' +
        '<span class="overall-pct ' + lowClass + '">' + overallPct + '%' + lowLabel + '</span>' +
      '</div></td>' +
    '</tr>';
  }).join('');

  /* Attach absent checkbox listeners */
  attTbody.querySelectorAll('.absent-check').forEach(function (chk) {
    chk.addEventListener('change', function () {
      var id = parseInt(chk.dataset.id);
      if (chk.checked) {
        state.currentAbsent[id] = true;
      } else {
        delete state.currentAbsent[id];
      }
      renderMembersTable();
    });
  });
}

/* ══ NEW SESSION FORM ══ */
btnNewSession.addEventListener('click', function () {
  newSessionForm.style.display = newSessionForm.style.display === 'none' ? 'block' : 'none';
  if (newSessionForm.style.display === 'block') {
    /* Set default date to today */
    var today = new Date();
    var yyyy  = today.getFullYear();
    var mm    = String(today.getMonth() + 1).padStart(2, '0');
    var dd    = String(today.getDate()).padStart(2, '0');
    sessionDateInput.value = yyyy + '-' + mm + '-' + dd;
    sessionNameInput.value = '';
    sessionNameInput.focus();
    btnNewSession.textContent = '✕  Close';
  } else {
    resetNewSessionBtn();
  }
});

function resetNewSessionBtn() {
  btnNewSession.innerHTML =
    '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" width="15" height="15">' +
    '<line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>' +
    ' New Session';
}

btnCancel.addEventListener('click', function () {
  newSessionForm.style.display = 'none';
  resetNewSessionBtn();
});

btnCreate.addEventListener('click', function () {
  var name = (sessionNameInput.value || '').trim();
  var date = sessionDateInput.value;

  if (!name) {
    sessionNameInput.focus();
    sessionNameInput.style.borderColor = '#dc2626';
    setTimeout(function () { sessionNameInput.style.borderColor = ''; }, 1500);
    return;
  }
  if (!date) {
    sessionDateInput.focus();
    sessionDateInput.style.borderColor = '#dc2626';
    setTimeout(function () { sessionDateInput.style.borderColor = ''; }, 1500);
    return;
  }

  /* Default all members present */
  var att = {};
  ALL_MEMBERS.forEach(function (m) { att[m.id] = true; });

  var newSession = {
    id: nextSessionId++,
    name: name,
    date: date,
    attendance: att
  };

  SESSIONS.push(newSession);
  state.activeSessionId = newSession.id;

  newSessionForm.style.display = 'none';
  resetNewSessionBtn();

  updateStats();
  renderSessions();
  loadSession();
});

/* ══ SAVE ATTENDANCE ══ */
btnSave.addEventListener('click', function () {
  var session = SESSIONS.find(function (s) { return s.id === state.activeSessionId; });
  if (!session) return;

  ALL_MEMBERS.forEach(function (m) {
    session.attendance[m.id] = !state.currentAbsent[m.id];
  });

  updateStats();
  renderSessions();

  /* Visual feedback */
  btnSave.textContent = '✓ Saved!';
  btnSave.style.background = '#16a34a';
  setTimeout(function () {
    btnSave.textContent = 'Save Attendance';
    btnSave.style.background = '';
  }, 2000);
});

/* ══ SEARCH ══ */
if (sessionSearch) {
  sessionSearch.addEventListener('input', function () {
    state.sessionSearch = sessionSearch.value;
    renderSessions();
  });
}

if (memberSearch) {
  memberSearch.addEventListener('input', function () {
    state.memberSearch = memberSearch.value;
    renderMembersTable();
  });
}

/* ══ INIT ══ */
document.addEventListener('DOMContentLoaded', function () {
  updateStats();
  renderSessions();
  loadSession();
});