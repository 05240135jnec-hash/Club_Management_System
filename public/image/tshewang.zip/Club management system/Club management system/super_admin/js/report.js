'use strict';

/* ══════════════════════════════════════════════
   DATA — Club reports with categories
══════════════════════════════════════════════ */
var REPORTS = [
  {
    name: 'Annual_Audit_2024.pdf',
    type: 'pdf',
    club: 'Media Club',
    category: 'Entertainment Club',
    date: 'Jan 10, 2025',
    fileUrl: '' /* ← backend: paste file URL here */
  },
  {
    name: 'Inventory_Q4_Checklist.xlsx',
    type: 'xlsx',
    club: 'DIT Maintenance',
    category: 'Maintenance Club',
    date: 'Jan 08, 2025',
    fileUrl: ''
  },
  {
    name: 'Cultural_Fest_Financials.pdf',
    type: 'pdf',
    club: 'Culture Club',
    category: 'Entertainment Club',
    date: 'Jan 05, 2025',
    fileUrl: ''
  },
  {
    name: 'Internal_Audit_Report_v2.pdf',
    type: 'pdf',
    club: 'Integrity Club',
    category: 'Social Service Club',
    date: 'Dec 20, 2024',
    fileUrl: ''
  },
  {
    name: 'Quarterly_Club_Financials.pdf',
    type: 'pdf',
    club: 'Arts Society',
    category: 'Entertainment Club',
    date: 'Dec 15, 2024',
    fileUrl: ''
  },
  {
    name: 'Club_Event_Proposal_v1.docx',
    type: 'docx',
    club: 'Robotics Team',
    category: 'Entrepreneurship Club',
    date: 'Dec 05, 2024',
    fileUrl: ''
  },
  {
    name: 'Volunteer_Activities_Q3.pdf',
    type: 'pdf',
    club: 'Y-Peer',
    category: 'Volunteer Club',
    date: 'Nov 28, 2024',
    fileUrl: ''
  },
  {
    name: 'Scout_Annual_Report.pdf',
    type: 'pdf',
    club: 'Rover Scout',
    category: 'Volunteer Club',
    date: 'Nov 20, 2024',
    fileUrl: ''
  },
  {
    name: 'RedCross_Campaign_Summary.pdf',
    type: 'pdf',
    club: 'Red Cross',
    category: 'Volunteer Club',
    date: 'Nov 15, 2024',
    fileUrl: ''
  },
  {
    name: 'Mechanical_Maintenance_Log.xlsx',
    type: 'xlsx',
    club: 'Mechanical Maintenance',
    category: 'Maintenance Club',
    date: 'Nov 10, 2024',
    fileUrl: ''
  },
  {
    name: 'GNH_Initiative_Report.pdf',
    type: 'pdf',
    club: 'JNEC GNH',
    category: 'Social Service Club',
    date: 'Nov 05, 2024',
    fileUrl: ''
  },
  {
    name: 'Karate_Tournament_Report.pdf',
    type: 'pdf',
    club: 'JNEC Karate',
    category: 'Sports Club',
    date: 'Oct 30, 2024',
    fileUrl: ''
  },
  {
    name: 'Music_Event_Budget.xlsx',
    type: 'xlsx',
    club: 'JNEC Music Club',
    category: 'Entertainment Club',
    date: 'Oct 22, 2024',
    fileUrl: ''
  },
  {
    name: 'Radio_Broadcast_Log.docx',
    type: 'docx',
    club: 'Radio Club',
    category: 'Entertainment Club',
    date: 'Oct 15, 2024',
    fileUrl: ''
  },
  {
    name: 'Entrepreneurship_Summit.pdf',
    type: 'pdf',
    club: 'Entrepreneurship Club',
    category: 'Entrepreneurship Club',
    date: 'Oct 08, 2024',
    fileUrl: ''
  }
];

/* ══════════════════════════════════════════════
   FILE TYPE ICONS
══════════════════════════════════════════════ */
function getDocIcon(type) {
  if (type === 'pdf') {
    return '<div class="doc-icon pdf">' +
      '<svg viewBox="0 0 24 24" fill="currentColor">' +
      '<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/>' +
      '<polyline points="14 2 14 8 20 8" fill="none" stroke="currentColor" stroke-width="2"/>' +
      '<text x="6" y="19" font-size="5" font-family="sans-serif" fill="#fff" font-weight="700">PDF</text>' +
      '</svg></div>';
  }
  if (type === 'xlsx') {
    return '<div class="doc-icon xlsx">' +
      '<svg viewBox="0 0 24 24" fill="currentColor">' +
      '<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/>' +
      '<polyline points="14 2 14 8 20 8" fill="none" stroke="currentColor" stroke-width="2"/>' +
      '<text x="5" y="19" font-size="4.5" font-family="sans-serif" fill="#fff" font-weight="700">XLS</text>' +
      '</svg></div>';
  }
  return '<div class="doc-icon docx">' +
    '<svg viewBox="0 0 24 24" fill="currentColor">' +
    '<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/>' +
    '<polyline points="14 2 14 8 20 8" fill="none" stroke="currentColor" stroke-width="2"/>' +
    '<text x="4" y="19" font-size="4" font-family="sans-serif" fill="#fff" font-weight="700">DOC</text>' +
    '</svg></div>';
}

/* ══════════════════════════════════════════════
   OPEN FILE
   When backend is ready, fileUrl will be the
   real server URL. window.open() opens it in
   a new tab without downloading.
══════════════════════════════════════════════ */
function openFile(fileUrl, fileName) {
  if (fileUrl && fileUrl !== '') {
    /* Backend connected: open in new tab */
    window.open(fileUrl, '_blank');
  } else {
    /* Frontend only: show info toast */
    showToast('Backend not connected yet — ' + fileName);
  }
}

/* ══════════════════════════════════════════════
   RENDER TABLE
══════════════════════════════════════════════ */
function renderTable(data) {
  var tbody      = document.getElementById('table-body');
  var entryCount = document.getElementById('entry-count');
  var emptyState = document.getElementById('empty-state');
  var tableCard  = document.querySelector('.table-card');

  if (!data.length) {
    tableCard.style.display  = 'none';
    emptyState.style.display = 'flex';
    entryCount.textContent   = 'Showing 0 entries';
    return;
  }

  tableCard.style.display  = '';
  emptyState.style.display = 'none';

  var html = '';
  data.forEach(function (r) {
    html +=
      '<tr>' +
        '<td>' +
          '<div class="doc-cell">' +
            getDocIcon(r.type) +
            '<span class="doc-name">' + escHtml(r.name) + '</span>' +
          '</div>' +
        '</td>' +
        '<td>' + escHtml(r.club) + '</td>' +
        '<td class="date-cell">' + escHtml(r.date) + '</td>' +
        '<td>' +
          /* Eye / open icon — opens file in new tab when backend is ready */
          '<button class="open-btn" data-name="' + escHtml(r.name) + '" data-url="' + escHtml(r.fileUrl) + '" title="Open ' + escHtml(r.name) + '">' +
            '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">' +
              '<path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/>' +
              '<circle cx="12" cy="12" r="3"/>' +
            '</svg>' +
          '</button>' +
        '</td>' +
      '</tr>';
  });

  tbody.innerHTML = html;

  var total = data.length;
  entryCount.textContent = 'Showing 1 to ' + total + ' of ' + total + ' entries';

  /* Make entire row clickable to open file */
  tbody.querySelectorAll('tr').forEach(function (row) {
    row.style.cursor = 'pointer';
    row.addEventListener('click', function () {
      var btn = row.querySelector('.open-btn');
      if (btn) openFile(btn.dataset.url, btn.dataset.name);
    });
  });
}

/* ══════════════════════════════════════════════
   FILTER
══════════════════════════════════════════════ */
function getFiltered() {
  var search   = document.getElementById('search-input').value.trim().toLowerCase();
  var category = document.getElementById('category-filter').value;

  return REPORTS.filter(function (r) {
    var matchSearch   = !search ||
      r.name.toLowerCase().indexOf(search) !== -1 ||
      r.club.toLowerCase().indexOf(search) !== -1;
    var matchCategory = !category || r.category === category;
    return matchSearch && matchCategory;
  });
}

function applyFilters() {
  renderTable(getFiltered());
}

/* ══════════════════════════════════════════════
   TOAST
══════════════════════════════════════════════ */
var toastTimer = null;

function showToast(msg) {
  var toast    = document.getElementById('toast');
  var toastMsg = document.getElementById('toast-msg');
  toastMsg.textContent = msg;
  toast.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(function () {
    toast.classList.remove('show');
  }, 2800);
}

/* ══════════════════════════════════════════════
   SIDEBAR TOGGLE (MOBILE)
══════════════════════════════════════════════ */
function openSidebar() {
  document.getElementById('sidebar').classList.add('open');
  var overlay = document.getElementById('sidebar-overlay');
  overlay.style.display = 'block';
  requestAnimationFrame(function () {
    overlay.classList.add('visible');
  });
}

function closeSidebar() {
  document.getElementById('sidebar').classList.remove('open');
  var overlay = document.getElementById('sidebar-overlay');
  overlay.classList.remove('visible');
  setTimeout(function () {
    overlay.style.display = 'none';
  }, 250);
}

/* ══════════════════════════════════════════════
   NAV
══════════════════════════════════════════════ */
function initNav() {
  var navItems = document.querySelectorAll('.nav-item');
  navItems.forEach(function (item) {
    item.addEventListener('click', function (e) {
      if (item.getAttribute('href') === '#') e.preventDefault();
      navItems.forEach(function (n) { n.classList.remove('active'); });
      item.classList.add('active');
      if (window.innerWidth <= 768) closeSidebar();
    });
  });
}

/* ══════════════════════════════════════════════
   ESCAPE HTML
══════════════════════════════════════════════ */
function escHtml(str) {
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

/* ══════════════════════════════════════════════
   INIT
══════════════════════════════════════════════ */
document.addEventListener('DOMContentLoaded', function () {

  renderTable(REPORTS);

  document.getElementById('search-input').addEventListener('input', applyFilters);
  document.getElementById('category-filter').addEventListener('change', applyFilters);

  var hamburger = document.getElementById('hamburger-btn');
  if (hamburger) hamburger.addEventListener('click', openSidebar);

  var overlay = document.getElementById('sidebar-overlay');
  if (overlay) overlay.addEventListener('click', closeSidebar);

  initNav();
});