/* ============================================================
   JNEC Club Management – All Clubs Page  |  allclub.js
   ============================================================ */
'use strict';

/* ── DATA ─────────────────────────────────────────────────── */
var CLUBS = [
  { id: 1,  name: 'Y-Peer',                       category: 'Volunteer',        members: 28, adviser: 'Ms. Dema' },
  { id: 2,  name: 'Rover Scout',                  category: 'Volunteer',        members: 32, adviser: 'Mr. Tenzin' },
  { id: 3,  name: 'Red Cross',                    category: 'Volunteer',        members: 40, adviser: 'Ms. Choki' },
  { id: 4,  name: 'JNEC Clean Toilet Initiative', category: 'Volunteer',        members: 18, adviser: 'Mr. Karma' },
  { id: 5,  name: 'Mechanical Maintenance',       category: 'Maintenance',      members: 22, adviser: 'Mr. Dorji' },
  { id: 6,  name: 'Civil Maintenance',            category: 'Maintenance',      members: 30, adviser: 'Mr. Phuntsho' },
  { id: 7,  name: 'DIT Maintenance',              category: 'Maintenance',      members: 28, adviser: 'Mr. Tshering' },
  { id: 8,  name: 'Maintenance Hobby Club',       category: 'Maintenance',      members: 19, adviser: 'Mr. Namgay' },
  { id: 9,  name: 'Electrical Maintenance',       category: 'Maintenance',      members: 24, adviser: 'Ms. Peldon' },
  { id: 10, name: 'Helping Hand Club',            category: 'Social Service',   members: 55, adviser: 'Ms. Dechen' },
  { id: 11, name: 'JNEC GNH',                     category: 'Social Service',   members: 36, adviser: 'Mr. Sonam' },
  { id: 12, name: 'JNEC Salon',                   category: 'Social Service',   members: 34, adviser: 'Ms. Yangzom' },
  { id: 13, name: 'Thakor Namsung Tshokpa',       category: 'Social Service',   members: 27, adviser: 'Mr. Ugyen' },
  { id: 14, name: 'Integrity Club',               category: 'Social Service',   members: 31, adviser: 'Ms. Pem' },
  { id: 15, name: 'Entrepreneurship Club',        category: 'Entrepreneurship', members: 45, adviser: 'Mr. Rinzin' },
  { id: 16, name: 'JNEC Music Club',              category: 'Entertainment',    members: 38, adviser: 'Ms. Zangmo' },
  { id: 17, name: 'Culture Club',                 category: 'Cultural',         members: 42, adviser: 'Mr. Tandin' },
  { id: 18, name: 'Media Club',                   category: 'Entertainment',    members: 29, adviser: 'Mr. Karma' },
  { id: 19, name: 'Radio Club',                   category: 'Entertainment',    members: 14, adviser: 'Mr. Karma' },
  { id: 20, name: 'JNEC Karate',                  category: 'Sports',           members: 25, adviser: 'Mr. Wangchuk' }
];

/* ── DOM REFS ─────────────────────────────────────────────── */
var tableBody      = document.getElementById('club-table-body');
var searchInput    = document.getElementById('club-search');
var categoryFilter = document.getElementById('category-filter');
var footerCount    = document.getElementById('footer-count');
var hamburgerBtn   = document.getElementById('hamburger-btn');
var sidebar        = document.getElementById('sidebar');
var sidebarOverlay = document.getElementById('sidebar-overlay');

/* ── RENDER TABLE ─────────────────────────────────────────── */
function renderTable() {
  var search   = (searchInput.value || '').toLowerCase().trim();
  var category = categoryFilter.value;

  var filtered = CLUBS.filter(function(c) {
    var matchSearch   = c.name.toLowerCase().indexOf(search) !== -1 ||
                        c.adviser.toLowerCase().indexOf(search) !== -1;
    var matchCategory = !category || c.category === category;
    return matchSearch && matchCategory;
  });

  if (!filtered.length) {
    tableBody.innerHTML = '<tr class="empty-row"><td colspan="5">No clubs found</td></tr>';
    footerCount.textContent = 'Showing 0 clubs';
    return;
  }

  var html = '';
  filtered.forEach(function(club) {
    html +=
      '<tr class="data-row" data-id="' + club.id + '">' +
        '<td><span class="club-name-text">' + club.name + '</span></td>' +
        '<td><span class="cat-badge">' + club.category + '</span></td>' +
        '<td>' + club.members + ' members</td>' +
        '<td>' + club.adviser + '</td>' +
        '<td class="actions-cell">' +
          '<button class="delete-btn" data-id="' + club.id + '" title="Delete">' +
            '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">' +
              '<polyline points="3 6 5 6 21 6"/>' +
              '<path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/>' +
              '<path d="M10 11v6"/><path d="M14 11v6"/>' +
              '<path d="M9 6V4a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2"/>' +
            '</svg>' +
          '</button>' +
        '</td>' +
      '</tr>';
  });

  tableBody.innerHTML = html;
  footerCount.textContent = 'Showing ' + filtered.length + ' club' + (filtered.length !== 1 ? 's' : '');
  attachRowEvents();
}

/* ── DELETE CONFIRMATION ──────────────────────────────────── */
function confirmDelete(clubId) {
  var club = CLUBS.find(function(c) { return c.id === clubId; });
  if (!club) return;

  var isMobile = window.innerWidth <= 768;

  if (isMobile) {
    /* ── Mobile: WhatsApp-style bottom sheet ── */
    showBottomSheet(club);
  } else {
    /* ── Desktop: SweetAlert2 ── */
    Swal.fire({
      title: 'Delete ' + club.name + '?',
      text: 'Are you sure you want to delete this club? This action cannot be undone.',
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#e53e3e',
      cancelButtonColor: '#8892a4',
      confirmButtonText: 'Yes, delete it',
      cancelButtonText: 'Cancel'
    }).then(function(result) {
      if (result.isConfirmed) deleteClub(club);
    });
  }
}

/* ── BOTTOM SHEET (mobile) ────────────────────────────────── */
function showBottomSheet(club) {
  /* Remove any existing sheet */
  var existing = document.getElementById('delete-sheet');
  if (existing) existing.remove();

  var sheet = document.createElement('div');
  sheet.id = 'delete-sheet';
  sheet.innerHTML =
    '<div class="sheet-backdrop" id="sheet-backdrop"></div>' +
    '<div class="sheet-box" id="sheet-box">' +
      '<div class="sheet-handle"></div>' +
      '<div class="sheet-title">Delete ' + club.name + '?</div>' +
      '<div class="sheet-msg">Are you sure you want to delete this club? This action cannot be undone.</div>' +
      '<div class="sheet-actions">' +
        '<button class="sheet-btn-cancel" id="sheet-cancel">Cancel</button>' +
        '<button class="sheet-btn-delete" id="sheet-confirm">Delete club</button>' +
      '</div>' +
    '</div>';

  document.body.appendChild(sheet);

  /* Animate in */
  requestAnimationFrame(function() {
    requestAnimationFrame(function() {
      sheet.querySelector('.sheet-box').classList.add('sheet-open');
      sheet.querySelector('.sheet-backdrop').classList.add('sheet-open');
    });
  });

  function closeSheet() {
    var box = sheet.querySelector('.sheet-box');
    var bd  = sheet.querySelector('.sheet-backdrop');
    box.classList.remove('sheet-open');
    bd.classList.remove('sheet-open');
    setTimeout(function() { sheet.remove(); }, 300);
  }

  document.getElementById('sheet-cancel').addEventListener('click', closeSheet);
  document.getElementById('sheet-backdrop').addEventListener('click', closeSheet);
  document.getElementById('sheet-confirm').addEventListener('click', function() {
    closeSheet();
    setTimeout(function() { deleteClub(club); }, 320);
  });
}

/* ── DO DELETE ────────────────────────────────────────────── */
function deleteClub(club) {
  var idx = CLUBS.findIndex(function(c) { return c.id === club.id; });
  if (idx !== -1) CLUBS.splice(idx, 1);
  renderTable();

  if (window.innerWidth <= 768) {
    /* Mobile: small toast instead of Swal */
    showToast(club.name + ' deleted');
  } else {
    Swal.fire({
      title: 'Deleted!',
      text: club.name + ' has been deleted.',
      icon: 'success',
      confirmButtonColor: '#2d5be3',
      timer: 2000,
      timerProgressBar: true
    });
  }
}

/* ── ATTACH ROW & BUTTON EVENTS ───────────────────────────── */
function attachRowEvents() {
  tableBody.querySelectorAll('.data-row').forEach(function(row) {
    row.addEventListener('click', function(e) {
      if (e.target.closest('.delete-btn')) return;
      var id = parseInt(row.dataset.id, 10);
      confirmDelete(id);
    });
  });

  tableBody.querySelectorAll('.delete-btn').forEach(function(btn) {
    btn.addEventListener('click', function(e) {
      e.stopPropagation();
      var id = parseInt(btn.dataset.id, 10);
      confirmDelete(id);
    });
  });
}

/* ── SEARCH & FILTER ──────────────────────────────────────── */
if (searchInput)    searchInput.addEventListener('input', renderTable);
if (categoryFilter) categoryFilter.addEventListener('change', renderTable);

/* ── SIDEBAR MOBILE ───────────────────────────────────────── */
function openSidebar() {
  if (sidebar) sidebar.classList.add('open');
  if (sidebarOverlay) {
    sidebarOverlay.style.display = 'block';
    setTimeout(function() { sidebarOverlay.classList.add('active'); }, 10);
  }
  document.body.style.overflow = 'hidden';
}

function closeSidebar() {
  if (sidebar) sidebar.classList.remove('open');
  if (sidebarOverlay) {
    sidebarOverlay.classList.remove('active');
    setTimeout(function() { sidebarOverlay.style.display = 'none'; }, 280);
  }
  document.body.style.overflow = '';
}

if (hamburgerBtn) {
  hamburgerBtn.addEventListener('click', function() {
    sidebar && sidebar.classList.contains('open') ? closeSidebar() : openSidebar();
  });
}
if (sidebarOverlay) sidebarOverlay.addEventListener('click', closeSidebar);

document.querySelectorAll('.nav-item').forEach(function(item) {
  item.addEventListener('click', function(e) {
    var href = item.getAttribute('href');
    if (!href || href === '#') e.preventDefault();
    if (window.innerWidth <= 768) closeSidebar();
  });
});

/* ── TOAST (mobile success) ───────────────────────────────── */
function showToast(msg) {
  var t = document.getElementById('app-toast');
  if (!t) {
    t = document.createElement('div');
    t.id = 'app-toast';
    Object.assign(t.style, {
      position:'fixed', bottom:'24px', left:'50%', transform:'translateX(-50%) translateY(20px)',
      background:'#172D3D', color:'#fff', padding:'10px 20px',
      borderRadius:'20px', fontSize:'13px', fontWeight:'500',
      boxShadow:'0 4px 14px rgba(0,0,0,0.2)', zIndex:'9999',
      opacity:'0', transition:'opacity 0.2s, transform 0.2s',
      pointerEvents:'none', whiteSpace:'nowrap'
    });
    document.body.appendChild(t);
  }
  clearTimeout(t._timer);
  t.textContent = msg;
  t.style.opacity = '1';
  t.style.transform = 'translateX(-50%) translateY(0)';
  t._timer = setTimeout(function() {
    t.style.opacity = '0';
    t.style.transform = 'translateX(-50%) translateY(20px)';
  }, 2500);
}

/* ── INIT ─────────────────────────────────────────────────── */
document.addEventListener('DOMContentLoaded', function() {
  renderTable();
});