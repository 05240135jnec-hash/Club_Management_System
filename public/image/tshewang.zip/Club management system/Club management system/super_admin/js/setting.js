/* ============================================================
   JNEC Club Management – Settings Page
   settings.js
   ============================================================ */
'use strict';

/* ══════════════════════════════════════════════════════════
   DOM REFS
   ══════════════════════════════════════════════════════════ */

var editProfileRow    = document.getElementById('edit-profile-row');
var changePasswordRow = document.getElementById('change-password-row');
var hamburgerBtn      = document.getElementById('hamburger-btn');
var sidebar           = document.getElementById('sidebar');
var sidebarOverlay    = document.getElementById('sidebar-overlay');

/* ── Current profile data ── */
var profileData = {
  name:        'Yoesel Dorji',
  email:       'yoesel@jnec.edu.bt',
  phone:       '17xxxxxx',
  staffId:     'JNEC-001',
  designation: 'Super Admin'
};

/* ══════════════════════════════════════════════════════════
   EDIT PROFILE POPUP
   ══════════════════════════════════════════════════════════ */

function openEditProfile() {
  Swal.fire({
    title: 'Edit Profile',
    width: '480px',
    html:
      '<div class="swal-form-group">' +
        '<label>Full Name</label>' +
        '<input id="swal-name" class="swal2-input" style="margin:0;height:40px;font-size:13px;border-radius:8px;border:1px solid #e2e6ef;padding:0 14px;width:100%;box-sizing:border-box;background:#f8f9fb;" placeholder="Full name" value="' + profileData.name + '" />' +
      '</div>' +
      '<div class="swal-form-group">' +
        '<label>Email</label>' +
        '<input id="swal-email" class="swal2-input" style="margin:0;height:40px;font-size:13px;border-radius:8px;border:1px solid #e2e6ef;padding:0 14px;width:100%;box-sizing:border-box;background:#f8f9fb;" placeholder="Email address" value="' + profileData.email + '" />' +
      '</div>' +
      '<div class="swal-form-group">' +
        '<label>Phone</label>' +
        '<input id="swal-phone" class="swal2-input" style="margin:0;height:40px;font-size:13px;border-radius:8px;border:1px solid #e2e6ef;padding:0 14px;width:100%;box-sizing:border-box;background:#f8f9fb;" placeholder="Phone number" value="' + profileData.phone + '" />' +
      '</div>' +
      '<div class="swal-form-group">' +
        '<label>Staff ID</label>' +
        '<input id="swal-staffid" class="swal2-input" style="margin:0;height:40px;font-size:13px;border-radius:8px;border:1px solid #e2e6ef;padding:0 14px;width:100%;box-sizing:border-box;background:#f8f9fb;" placeholder="Staff ID" value="' + profileData.staffId + '" />' +
      '</div>' +
      '<div class="swal-form-group">' +
        '<label>Designation</label>' +
        '<input id="swal-designation" class="swal2-input" style="margin:0;height:40px;font-size:13px;border-radius:8px;border:1px solid #e2e6ef;padding:0 14px;width:100%;box-sizing:border-box;background:#f8f9fb;" placeholder="Designation" value="' + profileData.designation + '" />' +
      '</div>',
    showCancelButton: true,
    confirmButtonText: 'Save Changes',
    cancelButtonText: 'Cancel',
    confirmButtonColor: ' #172D3D',
    cancelButtonColor: '#8892a4',
    focusConfirm: false,
    didOpen: function () {
      /* Style labels */
      document.querySelectorAll('.swal-form-group label').forEach(function (lbl) {
        lbl.style.cssText = 'display:block;font-size:12.5px;font-weight:600;color:#4a5568;margin-bottom:5px;text-align:left;';
      });
      document.querySelectorAll('.swal-form-group').forEach(function (grp) {
        grp.style.cssText = 'display:flex;flex-direction:column;margin-bottom:14px;text-align:left;';
      });
    },
    preConfirm: function () {
      var name        = document.getElementById('swal-name').value.trim();
      var email       = document.getElementById('swal-email').value.trim();
      var phone       = document.getElementById('swal-phone').value.trim();
      var staffId     = document.getElementById('swal-staffid').value.trim();
      var designation = document.getElementById('swal-designation').value.trim();

      if (!name || !email || !phone || !staffId || !designation) {
        Swal.showValidationMessage('Please fill in all fields');
        return false;
      }

      /* Basic email check */
      if (email.indexOf('@') === -1) {
        Swal.showValidationMessage('Please enter a valid email address');
        return false;
      }

      return { name: name, email: email, phone: phone, staffId: staffId, designation: designation };
    }
  }).then(function (result) {
    if (result.isConfirmed) {
      /* Save to profileData */
      profileData.name        = result.value.name;
      profileData.email       = result.value.email;
      profileData.phone       = result.value.phone;
      profileData.staffId     = result.value.staffId;
      profileData.designation = result.value.designation;

      Swal.fire({
        title: 'Profile Updated!',
        text: 'Your profile details have been saved successfully.',
        icon: 'success',
        confirmButtonColor: ' #172D3D',
        timer: 2000,
        timerProgressBar: true
      });
    }
  });
}

/* ══════════════════════════════════════════════════════════
   CHANGE PASSWORD POPUP
   ══════════════════════════════════════════════════════════ */

function openChangePassword() {
  Swal.fire({
    title: 'Change Password',
    width: '440px',
    html:
      '<div class="swal-form-group">' +
        '<label>Current Password</label>' +
        '<input id="swal-current-pw" type="password" class="swal2-input" style="margin:0;height:40px;font-size:13px;border-radius:8px;border:1px solid #e2e6ef;padding:0 14px;width:100%;box-sizing:border-box;background:#f8f9fb;" placeholder="Enter current password" />' +
      '</div>' +
      '<div class="swal-form-group">' +
        '<label>New Password</label>' +
        '<input id="swal-new-pw" type="password" class="swal2-input" style="margin:0;height:40px;font-size:13px;border-radius:8px;border:1px solid #e2e6ef;padding:0 14px;width:100%;box-sizing:border-box;background:#f8f9fb;" placeholder="Enter new password" />' +
      '</div>' +
      '<div class="swal-form-group">' +
        '<label>Confirm New Password</label>' +
        '<input id="swal-confirm-pw" type="password" class="swal2-input" style="margin:0;height:40px;font-size:13px;border-radius:8px;border:1px solid #e2e6ef;padding:0 14px;width:100%;box-sizing:border-box;background:#f8f9fb;" placeholder="Confirm new password" />' +
      '</div>',
    showCancelButton: true,
    confirmButtonText: 'Update Password',
    cancelButtonText: 'Cancel',
    confirmButtonColor: ' #172D3D',
    cancelButtonColor: '#8892a4',
    focusConfirm: false,
    didOpen: function () {
      document.querySelectorAll('.swal-form-group label').forEach(function (lbl) {
        lbl.style.cssText = 'display:block;font-size:12.5px;font-weight:600;color:#4a5568;margin-bottom:5px;text-align:left;';
      });
      document.querySelectorAll('.swal-form-group').forEach(function (grp) {
        grp.style.cssText = 'display:flex;flex-direction:column;margin-bottom:14px;text-align:left;';
      });
    },
    preConfirm: function () {
      var current = document.getElementById('swal-current-pw').value;
      var newPw   = document.getElementById('swal-new-pw').value;
      var confirm = document.getElementById('swal-confirm-pw').value;

      if (!current || !newPw || !confirm) {
        Swal.showValidationMessage('Please fill in all fields');
        return false;
      }
      if (newPw.length < 6) {
        Swal.showValidationMessage('New password must be at least 6 characters');
        return false;
      }
      if (newPw !== confirm) {
        Swal.showValidationMessage('New password and confirm password do not match');
        return false;
      }

      return true;
    }
  }).then(function (result) {
    if (result.isConfirmed) {
      Swal.fire({
        title: 'Password Updated!',
        text: 'Your password has been changed successfully.',
        icon: 'success',
        confirmButtonColor: '#2bb5a0',
        timer: 2000,
        timerProgressBar: true
      });
    }
  });
}

/* ══════════════════════════════════════════════════════════
   ROW CLICK EVENTS
   ══════════════════════════════════════════════════════════ */

if (editProfileRow) {
  editProfileRow.addEventListener('click', openEditProfile);
}

if (changePasswordRow) {
  changePasswordRow.addEventListener('click', openChangePassword);
}

/* ══════════════════════════════════════════════════════════
   HAMBURGER / SIDEBAR TOGGLE (mobile)
   ══════════════════════════════════════════════════════════ */

function openSidebar() {
  if (sidebar) sidebar.classList.add('open');
  if (sidebarOverlay) {
    sidebarOverlay.style.display = 'block';
    setTimeout(function () { sidebarOverlay.classList.add('active'); }, 10);
  }
  document.body.style.overflow = 'hidden';
}

function closeSidebar() {
  if (sidebar) sidebar.classList.remove('open');
  if (sidebarOverlay) {
    sidebarOverlay.classList.remove('active');
    setTimeout(function () { sidebarOverlay.style.display = 'none'; }, 280);
  }
  document.body.style.overflow = '';
}

if (hamburgerBtn) {
  hamburgerBtn.addEventListener('click', function () {
    sidebar && sidebar.classList.contains('open') ? closeSidebar() : openSidebar();
  });
}

if (sidebarOverlay) {
  sidebarOverlay.addEventListener('click', closeSidebar);
}

document.querySelectorAll('.nav-item').forEach(function (item) {
  item.addEventListener('click', function (e) {
    var href = item.getAttribute('href');
    if (!href || href === '#') {
      e.preventDefault(); // only block placeholder links
    }
    if (window.innerWidth <= 768) closeSidebar();
  });
});