/* ============================================================
   JNEC Club Management – Feature Control Page
   feature.js
   ============================================================ */
'use strict';

/* ══════════════════════════════════════════════════════════
   DATA
   ══════════════════════════════════════════════════════════ */

var CLUBS = [
  { name: 'Media Club',     category: 'Entertainment',  feedback: true,  imageUpload: true,  vlog: true  },
  { name: 'Integrity Club', category: 'Social Service', feedback: true,  imageUpload: false, vlog: false },
  { name: 'Karate Club',    category: 'Sports',         feedback: true,  imageUpload: true,  vlog: false },
  { name: 'Music Club',     category: 'Entertainment',  feedback: false, imageUpload: true,  vlog: true  },
  { name: 'Rover Scout',    category: 'Volunteer',      feedback: true,  imageUpload: false, vlog: false },
  { name: 'Red Cross',      category: 'Volunteer',      feedback: true,  imageUpload: true,  vlog: true  }
];

var PAGE_META = {
  'dashboard':       { title: 'Dashboard',        subtitle: 'Club overview' },
  'feature-control': { title: 'Feature Control',  subtitle: 'Manage platform features' },
  'all-club':        { title: 'All Clubs',         subtitle: 'Browse and manage clubs' },
  'reports':         { title: 'Submitted Reports', subtitle: 'View all submitted reports' },
  'announcements':   { title: 'Announcements',     subtitle: 'System announcements' },
  'settings':        { title: 'Settings',          subtitle: 'Application settings' }
};

/* Working copy — changes are staged here until Save is clicked */
var state = CLUBS.map(function (c) { return Object.assign({}, c); });

/* ══════════════════════════════════════════════════════════
   DOM REFERENCES
   ══════════════════════════════════════════════════════════ */

var tableBody      = document.getElementById('club-table-body');
var searchInput    = document.getElementById('club-search');
var saveBtn        = document.getElementById('save-btn');
var notifBadge     = document.getElementById('notif-badge');
var topbarTitle    = document.getElementById('topbar-title');
var topbarSubtitle = document.getElementById('topbar-subtitle');
var hamburgerBtn   = document.getElementById('hamburger-btn');
var sidebar        = document.getElementById('sidebar');
var sidebarOverlay = document.getElementById('sidebar-overlay');

/* ══════════════════════════════════════════════════════════
   RENDER TABLE
   ══════════════════════════════════════════════════════════ */

function renderTable(filter) {
  filter = (filter || '').toLowerCase().trim();

  var filtered = state.filter(function (c) {
    return (
      c.name.toLowerCase().indexOf(filter) !== -1 ||
      c.category.toLowerCase().indexOf(filter) !== -1
    );
  });

  if (!filtered.length) {
    tableBody.innerHTML =
      '<tr><td colspan="4" style="text-align:center;padding:32px;color:#b0b8cc;font-size:13px;">No clubs found</td></tr>';
    return;
  }

  var html = '';
  filtered.forEach(function (club) {
    var realIdx = state.indexOf(club);
    html +=
      '<tr>' +
        '<td class="club-name-cell">' +
          '<div class="club-name">' + club.name + '</div>' +
          '<div class="club-cat">'  + club.category + '</div>' +
        '</td>' +
        '<td class="toggle-cell">' + makeToggle(realIdx, 'feedback',    club.feedback)    + '</td>' +
        '<td class="toggle-cell">' + makeToggle(realIdx, 'imageUpload', club.imageUpload) + '</td>' +
        '<td class="toggle-cell">' + makeToggle(realIdx, 'vlog',        club.vlog)        + '</td>' +
      '</tr>';
  });

  tableBody.innerHTML = html;
  attachToggleEvents();
}

/* ══════════════════════════════════════════════════════════
   BUILD TOGGLE HTML
   ══════════════════════════════════════════════════════════ */

function makeToggle(idx, feature, checked) {
  var id = 'tog-' + idx + '-' + feature;
  return (
    '<label class="toggle-wrap" for="' + id + '">' +
      '<div class="toggle-switch">' +
        '<input type="checkbox"' +
          ' id="'        + id      + '"' +
          ' data-idx="'  + idx     + '"' +
          ' data-feat="' + feature + '"' +
          (checked ? ' checked' : '') +
        '>' +
        '<span class="toggle-track"></span>' +
      '</div>' +
      '<span class="toggle-label">' + (checked ? 'On' : 'Off') + '</span>' +
    '</label>'
  );
}

/* ══════════════════════════════════════════════════════════
   TOGGLE CHANGE EVENTS
   ══════════════════════════════════════════════════════════ */

function attachToggleEvents() {
  tableBody.querySelectorAll('input[type="checkbox"]').forEach(function (chk) {
    chk.addEventListener('change', function () {
      var i    = parseInt(chk.dataset.idx, 10);
      var feat = chk.dataset.feat;
      state[i][feat] = chk.checked;

      /* Update On/Off label */
      var lbl = chk.closest('.toggle-wrap').querySelector('.toggle-label');
      if (lbl) lbl.textContent = chk.checked ? 'On' : 'Off';
    });
  });
}

/* ══════════════════════════════════════════════════════════
   SEARCH
   ══════════════════════════════════════════════════════════ */

if (searchInput) {
  searchInput.addEventListener('input', function () {
    renderTable(searchInput.value);
  });
}

/* ══════════════════════════════════════════════════════════
   SAVE CHANGES
   ══════════════════════════════════════════════════════════ */

if (saveBtn) {
  saveBtn.addEventListener('click', function () {
    /* Commit staged state back to the source array */
    state.forEach(function (s, i) { Object.assign(CLUBS[i], s); });
    showToast('Changes saved successfully!');
  });
}

/* ══════════════════════════════════════════════════════════
   HAMBURGER / SIDEBAR TOGGLE (mobile)
   ══════════════════════════════════════════════════════════ */

function openSidebar() {
  if (sidebar)        sidebar.classList.add('open');
  if (sidebarOverlay) {
    sidebarOverlay.style.display = 'block';
    /* Small delay so the display:block triggers the CSS opacity transition */
    setTimeout(function () {
      sidebarOverlay.classList.add('active');
    }, 10);
  }
  document.body.style.overflow = 'hidden'; /* Prevent background scroll */
}

function closeSidebar() {
  if (sidebar)        sidebar.classList.remove('open');
  if (sidebarOverlay) {
    sidebarOverlay.classList.remove('active');
    /* Hide after transition completes */
    setTimeout(function () {
      sidebarOverlay.style.display = 'none';
    }, 280);
  }
  document.body.style.overflow = '';
}

if (hamburgerBtn) {
  hamburgerBtn.addEventListener('click', function () {
    if (sidebar && sidebar.classList.contains('open')) {
      closeSidebar();
    } else {
      openSidebar();
    }
  });
}

if (sidebarOverlay) {
  sidebarOverlay.addEventListener('click', function () {
    closeSidebar();
  });
}

/* ══════════════════════════════════════════════════════════
   NAVIGATION
   ══════════════════════════════════════════════════════════ */

document.querySelectorAll('.nav-item').forEach(function (item) {
  item.addEventListener('click', function (e) {
  if (item.getAttribute('href') === '#') {
    e.preventDefault();
  }

  /* Remove active from all, set on clicked */

    /* Remove active from all, set on clicked */
    document.querySelectorAll('.nav-item').forEach(function (n) {
      n.classList.remove('active');
    });
    item.classList.add('active');

    /* Update topbar */
    var p = item.dataset.page;
    var m = PAGE_META[p] || PAGE_META['dashboard'];
    if (topbarTitle)    topbarTitle.textContent    = m.title;
    if (topbarSubtitle) topbarSubtitle.textContent = m.subtitle;

    /* Close sidebar on mobile after nav click */
    if (window.innerWidth <= 768) {
      closeSidebar();
    }
  });
});

/* ══════════════════════════════════════════════════════════
   TOAST NOTIFICATION
   ══════════════════════════════════════════════════════════ */

function showToast(msg) {
  var t = document.getElementById('app-toast');
  if (!t) {
    t = document.createElement('div');
    t.id = 'app-toast';
    Object.assign(t.style, {
      position:   'fixed',
      bottom:     '24px',
      right:      '28px',
      background: '#172D3D',
      color:      '#fff',
      padding:    '10px 18px',
      borderRadius: '8px',
      fontSize:   '12.5px',
      fontWeight: '500',
      boxShadow:  '0 4px 14px rgba(0,0,0,0.18)',
      zIndex:     '9999',
      opacity:    '0',
      transform:  'translateY(8px)',
      transition: 'opacity 0.2s, transform 0.2s',
      pointerEvents: 'none',
      maxWidth:   '280px'
    });
    document.body.appendChild(t);
  }

  clearTimeout(t._timer);
  t.textContent      = msg;
  t.style.opacity    = '1';
  t.style.transform  = 'translateY(0)';

  t._timer = setTimeout(function () {
    t.style.opacity   = '0';
    t.style.transform = 'translateY(8px)';
  }, 2200);
}

/* ══════════════════════════════════════════════════════════
   INIT
   ══════════════════════════════════════════════════════════ */

document.addEventListener('DOMContentLoaded', function () {
  renderTable();
  if (notifBadge) notifBadge.style.display = 'block';
});