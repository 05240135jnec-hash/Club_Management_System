/* ============================================================
   JNEC Club Management – Announcements Page
   announcement.js
   ============================================================ */
'use strict';

/* ══════════════════════════════════════════════════════════
   DATA — pre-loaded history
   ══════════════════════════════════════════════════════════ */

var ANNOUNCEMENTS = [
  {
    id: 1,
    title: 'Campus Maintenance Notice',
    content: 'Please be informed that the main library will be closed for maintenance from Oct 25 to Oct 27, 2023. All students and staff are advised to plan accordingly.',
    recipients: 'Both',
    dateSent: 'Oct 24, 2023 09:15 AM',
    attachments: []
  },
  {
    id: 2,
    title: 'End of Term Club Reports',
    content: 'All club advisers are required to submit their annual club reports by Nov 1, 2023. Please use the standard report template available on the portal.',
    recipients: 'Club Advisers',
    dateSent: 'Oct 20, 2023 02:30 PM',
    attachments: []
  },
  {
    id: 3,
    title: 'Club Registration Open',
    content: 'New student club registrations are now open for the upcoming semester. Students interested in forming new clubs should submit their proposals to the admin office.',
    recipients: 'Students',
    dateSent: 'Oct 15, 2023 10:00 AM',
    attachments: []
  }
];

var nextId = 4;

/* ══════════════════════════════════════════════════════════
   DOM REFS
   ══════════════════════════════════════════════════════════ */

var annTitle      = document.getElementById('ann-title');
var annContent    = document.getElementById('ann-content');
var chkAdvisers   = document.getElementById('chk-advisers');
var chkStudents   = document.getElementById('chk-students');
var postBtn       = document.getElementById('post-btn');
var historySearch = document.getElementById('history-search');
var historyBody   = document.getElementById('history-table-body');
var fileInput     = document.getElementById('file-input');
var fileDropZone  = document.getElementById('file-drop-zone');
var fileList      = document.getElementById('file-list');
var hamburgerBtn  = document.getElementById('hamburger-btn');
var sidebar       = document.getElementById('sidebar');
var sidebarOverlay= document.getElementById('sidebar-overlay');

/* Attached files array */
var attachedFiles = [];

/* ══════════════════════════════════════════════════════════
   FILE ATTACHMENT
   ══════════════════════════════════════════════════════════ */

function renderFileList() {
  if (!attachedFiles.length) {
    fileList.innerHTML = '';
    return;
  }

  var html = '';
  attachedFiles.forEach(function (f, i) {
    html +=
      '<div class="file-item">' +
        '<span class="file-item-name">' +
          '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>' +
          f.name +
        '</span>' +
        '<button class="file-remove-btn" data-idx="' + i + '" title="Remove">' +
          '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>' +
        '</button>' +
      '</div>';
  });

  fileList.innerHTML = html;

  fileList.querySelectorAll('.file-remove-btn').forEach(function (btn) {
    btn.addEventListener('click', function () {
      var idx = parseInt(btn.dataset.idx, 10);
      attachedFiles.splice(idx, 1);
      renderFileList();
    });
  });
}

if (fileInput) {
  fileInput.addEventListener('change', function () {
    Array.from(fileInput.files).forEach(function (f) {
      attachedFiles.push(f);
    });
    fileInput.value = '';
    renderFileList();
  });
}

/* Drag and drop */
if (fileDropZone) {
  fileDropZone.addEventListener('dragover', function (e) {
    e.preventDefault();
    fileDropZone.classList.add('dragover');
  });
  fileDropZone.addEventListener('dragleave', function () {
    fileDropZone.classList.remove('dragover');
  });
  fileDropZone.addEventListener('drop', function (e) {
    e.preventDefault();
    fileDropZone.classList.remove('dragover');
    Array.from(e.dataTransfer.files).forEach(function (f) {
      attachedFiles.push(f);
    });
    renderFileList();
  });
}
/* ── Click anywhere on drop zone opens file picker ── */
if (fileDropZone) {
  fileDropZone.addEventListener('click', function (e) {
    /* Don't double-trigger — the <label for="file-input"> already handles the browse link */
    if (e.target.tagName === 'LABEL' || e.target.closest('label')) return;
    fileInput.click();
  });
}
/* ══════════════════════════════════════════════════════════
   RENDER HISTORY TABLE
   ══════════════════════════════════════════════════════════ */

function renderHistory(filter) {
  filter = (filter || '').toLowerCase().trim();

  var filtered = ANNOUNCEMENTS.filter(function (a) {
    return (
      a.title.toLowerCase().indexOf(filter) !== -1 ||
      a.content.toLowerCase().indexOf(filter) !== -1 ||
      a.recipients.toLowerCase().indexOf(filter) !== -1
    );
  });

  if (!filtered.length) {
    historyBody.innerHTML =
      '<tr class="empty-row"><td colspan="4">No announcements found</td></tr>';
    return;
  }

  var html = '';
  filtered.forEach(function (ann) {
    var preview = ann.content.length > 60 ? ann.content.substring(0, 60) + '...' : ann.content;
    html +=
      '<tr>' +
        '<td>' +
          '<div class="ann-title-text">' + ann.title + '</div>' +
          '<div class="ann-preview">' + preview + '</div>' +
        '</td>' +
        '<td>' +
          '<div class="action-cell">' +
            '<button class="view-btn" data-id="' + ann.id + '">View</button>' +
            '<button class="remove-btn" data-id="' + ann.id + '">Remove</button>' +
          '</div>' +
        '</td>' +
        '<td>' + ann.dateSent + '</td>' +
        '<td><span class="recipient-badge">' + ann.recipients + '</span></td>' +
      '</tr>';
  });

  historyBody.innerHTML = html;
  attachHistoryEvents();
}

/* ══════════════════════════════════════════════════════════
   VIEW & REMOVE EVENTS
   ══════════════════════════════════════════════════════════ */

function attachHistoryEvents() {

  /* View */
  historyBody.querySelectorAll('.view-btn').forEach(function (btn) {
    btn.addEventListener('click', function () {
      var id  = parseInt(btn.dataset.id, 10);
      var ann = ANNOUNCEMENTS.find(function (a) { return a.id === id; });
      if (!ann) return;

      var attachHTML = ann.attachments && ann.attachments.length
        ? '<div style="margin-top:12px;font-size:12px;color:#8892a4;">Attachments: ' + ann.attachments.join(', ') + '</div>'
        : '';

      Swal.fire({
        title: ann.title,
        html:
          '<div style="text-align:left;">' +
            '<div style="font-size:12px;color:#8892a4;margin-bottom:10px;">To: <strong>' + ann.recipients + '</strong> &nbsp;|&nbsp; Sent: ' + ann.dateSent + '</div>' +
            '<div style="font-size:13.5px;color:#4a5568;line-height:1.7;">' + ann.content + '</div>' +
            attachHTML +
          '</div>',
        confirmButtonColor: '#2d5be3',
        confirmButtonText: 'Close',
        width: '520px'
      });
    });
  });

  /* Remove */
  historyBody.querySelectorAll('.remove-btn').forEach(function (btn) {
    btn.addEventListener('click', function () {
      var id  = parseInt(btn.dataset.id, 10);
      var ann = ANNOUNCEMENTS.find(function (a) { return a.id === id; });
      if (!ann) return;

      Swal.fire({
        title: 'Remove Announcement?',
        text: 'Are you sure you want to remove "' + ann.title + '"? This cannot be undone.',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#e53e3e',
        cancelButtonColor: '#8892a4',
        confirmButtonText: 'Yes, remove it',
        cancelButtonText: 'Cancel'
      }).then(function (result) {
        if (result.isConfirmed) {
          var idx = ANNOUNCEMENTS.findIndex(function (a) { return a.id === id; });
          if (idx !== -1) ANNOUNCEMENTS.splice(idx, 1);
          renderHistory(historySearch.value);
          Swal.fire({
            title: 'Removed!',
            text: '"' + ann.title + '" has been removed.',
            icon: 'success',
            confirmButtonColor: '#2bb5a0',
            timer: 2000,
            timerProgressBar: true
          });
        }
      });
    });
  });
}

/* ══════════════════════════════════════════════════════════
   POST ANNOUNCEMENT
   ══════════════════════════════════════════════════════════ */

if (postBtn) {
  postBtn.addEventListener('click', function () {
    var title   = (annTitle.value || '').trim();
    var content = (annContent.value || '').trim();
    var toAdvisers = chkAdvisers.checked;
    var toStudents = chkStudents.checked;

    /* Validation */
    if (!title) {
      Swal.fire({ icon: 'warning', title: 'Title required', text: 'Please enter an announcement title.', confirmButtonColor: '#2d5be3' });
      return;
    }
    if (!content) {
      Swal.fire({ icon: 'warning', title: 'Content required', text: 'Please enter the announcement content.', confirmButtonColor: '#2d5be3' });
      return;
    }
    if (!toAdvisers && !toStudents) {
      Swal.fire({ icon: 'warning', title: 'Select recipients', text: 'Please select at least one recipient group.', confirmButtonColor: '#2d5be3' });
      return;
    }

    var recipients = toAdvisers && toStudents ? 'Both' : toAdvisers ? 'Club Advisers' : 'Students';

    var now = new Date();
    var months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
    var hours = now.getHours();
    var ampm  = hours >= 12 ? 'PM' : 'AM';
    hours = hours % 12 || 12;
    var mins  = now.getMinutes().toString().padStart(2, '0');
    var dateSent = months[now.getMonth()] + ' ' + now.getDate() + ', ' + now.getFullYear() + ' ' + hours + ':' + mins + ' ' + ampm;

    ANNOUNCEMENTS.unshift({
      id: nextId++,
      title: title,
      content: content,
      recipients: recipients,
      dateSent: dateSent,
      attachments: attachedFiles.map(function (f) { return f.name; })
    });

    /* Reset form */
    annTitle.value    = '';
    annContent.value  = '';
    chkAdvisers.checked = false;
    chkStudents.checked = false;
    attachedFiles = [];
    renderFileList();

    renderHistory(historySearch.value);

    Swal.fire({
      title: 'Announcement Posted!',
      text: '"' + title + '" has been sent to ' + recipients + '.',
      icon: 'success',
      confirmButtonColor: '#2bb5a0',
      timer: 2500,
      timerProgressBar: true
    });
  });
}

/* ══════════════════════════════════════════════════════════
   SEARCH
   ══════════════════════════════════════════════════════════ */

if (historySearch) {
  historySearch.addEventListener('input', function () {
    renderHistory(historySearch.value);
  });
}

/* ══════════════════════════════════════════════════════════
   HAMBURGER / SIDEBAR TOGGLE (mobile)
   ══════════════════════════════════════════════════════════ */

function openSidebar() {
  if (sidebar) sidebar.classList.add('open');
  if (sidebarOverlay) {
    sidebarOverlay.style.display = 'block';
    setTimeout(function () { sidebarOverlay.classList.add('active'); }, 10);
  }
  document.body.style.overflow = 'hidden';
}

function closeSidebar() {
  if (sidebar) sidebar.classList.remove('open');
  if (sidebarOverlay) {
    sidebarOverlay.classList.remove('active');
    setTimeout(function () { sidebarOverlay.style.display = 'none'; }, 280);
  }
  document.body.style.overflow = '';
}

if (hamburgerBtn) {
  hamburgerBtn.addEventListener('click', function () {
    sidebar && sidebar.classList.contains('open') ? closeSidebar() : openSidebar();
  });
}

if (sidebarOverlay) {
  sidebarOverlay.addEventListener('click', closeSidebar);
}

document.querySelectorAll('.nav-item').forEach(function (item) {
  item.addEventListener('click', function (e) {
    if (item.getAttribute('href') === '#') e.preventDefault();
    if (window.innerWidth <= 768) closeSidebar();
  });
});

/* ══════════════════════════════════════════════════════════
   INIT
   ══════════════════════════════════════════════════════════ */

document.addEventListener('DOMContentLoaded', function () {
  renderHistory();
});