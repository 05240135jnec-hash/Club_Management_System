/* ============================================================
   JNEC Club Management – Super Admin Panel  |  index.js
   ============================================================ */
'use strict';

/* ── DATA ─────────────────────────────────────────────────── */
var DASHBOARD_DATA = {
  totalClubs: 14,
  totalStudents: 312,
  categories: [
    { name: 'Volunteer',        clubs: ['Y-Peer', 'Rover Scout', 'Red Cross', 'JNEC Clean Toilet Initiative'] },
    { name: 'Maintenance',      clubs: ['Mechanical Maintenance', 'Civil Maintenance', 'DIT Maintenance', 'Maintenance Hobby Club', 'Electrical Maintenance'] },
    { name: 'Social Service',   clubs: ['Helping Hand Club', 'JNEC GNH', 'JNEC Salon', 'Thakor Namsung Tshokpa', 'Integrity Club'] },
    { name: 'Entrepreneurship', clubs: ['Entrepreneurship Club'] },
    { name: 'Entertainment',    clubs: ['JNEC Music Club', 'Culture Club', 'Media Club', 'Radio Club'] },
    { name: 'Sports',           clubs: ['JNEC Karate'] },
    { name: 'Cultural',         clubs: [] }
  ]
};

var PAGE_META = {
  'dashboard':       { title: 'Dashboard',        subtitle: 'Club overview' },
  'feature-control': { title: 'Feature Control',  subtitle: 'Manage platform features' },
  'all-club':        { title: 'All Clubs',         subtitle: 'Browse and manage clubs' },
  'reports':         { title: 'Submitted Reports', subtitle: 'View all submitted reports' },
  'announcements':   { title: 'Announcements',     subtitle: 'System announcements' },
  'settings':        { title: 'Settings',          subtitle: 'Application settings' }
};

/* ── DOM REFS ─────────────────────────────────────────────── */
var categoriesGrid   = document.getElementById('categories-grid');
var categorySearch   = document.getElementById('category-search');
var topbarTitle      = document.getElementById('topbar-title');
var topbarSubtitle   = document.getElementById('topbar-subtitle');
var totalClubsCount  = document.getElementById('total-clubs-count');
var notifBtn         = document.getElementById('notif-btn');
var notifBadge       = document.getElementById('notif-badge');
var profileBtn       = document.getElementById('profile-btn');
var navItems         = document.querySelectorAll('.nav-item');
var hamburgerBtn     = document.getElementById('hamburger-btn');
var sidebar          = document.getElementById('sidebar');
var sidebarOverlay   = document.getElementById('sidebar-overlay');

/* Modal refs */
var addCategoryBtn   = document.getElementById('add-category-btn');
var modalOverlay     = document.getElementById('modal-overlay');
var modalClose       = document.getElementById('modal-close');
var modalCancel      = document.getElementById('modal-cancel');
var modalConfirm     = document.getElementById('modal-confirm');
var categoryInput    = document.getElementById('category-name-input');
var modalError       = document.getElementById('modal-error');

var activeCard = null;

/* ── RENDER CATEGORIES ────────────────────────────────────── */
function renderCategories(filter) {
  filter = filter || '';
  closeAllDropdowns();

  var filtered = DASHBOARD_DATA.categories.filter(function(cat) {
    return cat.name.toLowerCase().indexOf(filter.toLowerCase()) !== -1;
  });

  if (!filtered.length) {
    categoriesGrid.innerHTML =
      '<div style="grid-column:1/-1;text-align:center;padding:40px;color:#8892a4;font-size:13px;">' +
      'No categories found for "<strong>' + filter + '</strong>"</div>';
    return;
  }

  var chevronSVG = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 12 15 18 9"/></svg>';

  var html = '';
  filtered.forEach(function(cat) {
    var count = cat.clubs.length;
    var listHTML = '';
    if (count > 0) {
      cat.clubs.forEach(function(club, i) {
        listHTML += '<li><span class="club-num">' + (i + 1) + '</span><span class="club-nm">' + club + '</span></li>';
      });
      listHTML = '<ul class="club-list-dropdown">' + listHTML + '</ul>';
    } else {
      listHTML = '<div class="dropdown-empty">No clubs yet</div>';
    }

    html +=
      '<div class="category-card" data-name="' + cat.name + '">' +
        '<div class="category-info">' +
          '<div class="category-name">' + cat.name + '</div>' +
          '<div class="category-count">' +
            '<span class="category-count-badge">' + count + ' club' + (count !== 1 ? 's' : '') + '</span>' +
          '</div>' +
        '</div>' +
        '<button class="chevron-btn" aria-label="Show clubs">' + chevronSVG + '</button>' +
        '<div class="club-dropdown">' +
          '<div class="dropdown-header">' +
            '<span class="dropdown-header-title">' + cat.name + '</span>' +
            '<span class="dropdown-header-count">' + count + ' club' + (count !== 1 ? 's' : '') + '</span>' +
          '</div>' +
          listHTML +
        '</div>' +
      '</div>';
  });

  categoriesGrid.innerHTML = html;

  categoriesGrid.querySelectorAll('.category-card').forEach(function(card) {
    card.addEventListener('click', function(e) {
      e.stopPropagation();
      var dropdown = card.querySelector('.club-dropdown');
      var isOpen   = card.classList.contains('open');
      closeAllDropdowns();
      if (!isOpen) {
        card.classList.add('open');
        dropdown.classList.add('visible');
        activeCard = card;
      }
    });
  });
}

/* ── CLOSE DROPDOWNS ──────────────────────────────────────── */
function closeAllDropdowns() {
  if (!categoriesGrid) return;
  categoriesGrid.querySelectorAll('.category-card.open').forEach(function(card) {
    card.classList.remove('open');
    var dd = card.querySelector('.club-dropdown');
    if (dd) dd.classList.remove('visible');
  });
  activeCard = null;
}

document.addEventListener('click', function() { closeAllDropdowns(); });

/* ── STATS ────────────────────────────────────────────────── */
function animateCount(el, from, to, dur) {
  var start = performance.now();
  function step(now) {
    var p = Math.min((now - start) / dur, 1);
    el.textContent = Math.round(from + (to - from) * (1 - Math.pow(1 - p, 3)));
    if (p < 1) requestAnimationFrame(step);
  }
  requestAnimationFrame(step);
}

function renderStats() {
  if (totalClubsCount) animateCount(totalClubsCount, 0, DASHBOARD_DATA.totalClubs, 700);
  var el = document.getElementById('total-students-label');
  if (el) el.innerHTML =
    '<div style="text-align:left;">' +
      '<div style="font-size:30px;font-weight:800;color:#1a1a2e;line-height:1;">' + DASHBOARD_DATA.totalStudents + '</div>' +
      '<div style="font-size:14px;font-weight:500;color:#4a5568;margin-top:6px;">Total Student Registered</div>' +
    '</div>';
}

/* ── MODAL ────────────────────────────────────────────────── */
function openModal() {
  categoryInput.value = '';
  modalError.textContent = '';
  categoryInput.classList.remove('error');
  modalOverlay.classList.add('open');
  setTimeout(function() { categoryInput.focus(); }, 100);
}

function closeModal() {
  modalOverlay.classList.remove('open');
  categoryInput.value = '';
  modalError.textContent = '';
  categoryInput.classList.remove('error');
}

function addCategory() {
  var name = categoryInput.value.trim();

  /* Validate empty */
  if (!name) {
    modalError.textContent = 'Please enter a category name.';
    categoryInput.classList.add('error');
    categoryInput.focus();
    return;
  }

  /* Validate duplicate */
  var exists = DASHBOARD_DATA.categories.some(function(cat) {
    return cat.name.toLowerCase() === name.toLowerCase();
  });
  if (exists) {
    modalError.textContent = 'This category already exists.';
    categoryInput.classList.add('error');
    categoryInput.focus();
    return;
  }

  /* Add to data */
  DASHBOARD_DATA.categories.push({ name: name, clubs: [] });

  /* Update total clubs count display */
  closeModal();
  renderCategories(categorySearch ? categorySearch.value : '');
  showToast('Category "' + name + '" added successfully!');
}

/* Modal event listeners */
if (addCategoryBtn) addCategoryBtn.addEventListener('click', function(e) { e.stopPropagation(); openModal(); });
if (modalClose)     modalClose.addEventListener('click', closeModal);
if (modalCancel)    modalCancel.addEventListener('click', closeModal);
if (modalConfirm)   modalConfirm.addEventListener('click', addCategory);

/* Close modal on overlay click */
if (modalOverlay) {
  modalOverlay.addEventListener('click', function(e) {
    if (e.target === modalOverlay) closeModal();
  });
}

/* Enter key submits */
if (categoryInput) {
  categoryInput.addEventListener('keydown', function(e) {
    if (e.key === 'Enter') addCategory();
    if (e.key === 'Escape') closeModal();
  });
  /* Clear error on typing */
  categoryInput.addEventListener('input', function() {
    modalError.textContent = '';
    categoryInput.classList.remove('error');
  });
}

/* ── NAVIGATION ───────────────────────────────────────────── */
function setActivePage(key) {
  navItems.forEach(function(item) { item.classList.toggle('active', item.dataset.page === key); });
  var m = PAGE_META[key] || PAGE_META['dashboard'];
  if (topbarTitle)    topbarTitle.textContent    = m.title;
  if (topbarSubtitle) topbarSubtitle.textContent = m.subtitle;
}

navItems.forEach(function(item) {
  item.addEventListener('click', function(e) {
    var p = item.dataset.page;
    if (item.getAttribute('href') === '#') e.preventDefault();
    setActivePage(p);
    if (p !== 'dashboard') showToast('Navigated to: ' + (PAGE_META[p] ? PAGE_META[p].title : p));
    if (window.innerWidth <= 768) closeSidebar();
  });
});

/* ── SEARCH ───────────────────────────────────────────────── */
if (categorySearch) {
  categorySearch.addEventListener('input', function() { renderCategories(categorySearch.value); });
}

/* ── NOTIFICATION ─────────────────────────────────────────── */
var notifOpen = false;
if (notifBtn) {
  notifBtn.addEventListener('click', function(e) {
    e.stopPropagation();
    notifOpen = !notifOpen;
    if (notifOpen && notifBadge) notifBadge.style.display = 'none';
    showToast(notifOpen ? 'Notifications (demo)' : 'Notifications closed');
  });
}

/* ── PROFILE ──────────────────────────────────────────────── */
if (profileBtn) {
  profileBtn.addEventListener('click', function(e) { e.stopPropagation(); showToast('Profile menu (demo)'); });
}

/* ── SIDEBAR MOBILE ───────────────────────────────────────── */
function openSidebar() {
  if (sidebar) sidebar.classList.add('open');
  if (sidebarOverlay) {
    sidebarOverlay.style.display = 'block';
    setTimeout(function() { sidebarOverlay.classList.add('active'); }, 10);
  }
  document.body.style.overflow = 'hidden';
}

function closeSidebar() {
  if (sidebar) sidebar.classList.remove('open');
  if (sidebarOverlay) {
    sidebarOverlay.classList.remove('active');
    setTimeout(function() { sidebarOverlay.style.display = 'none'; }, 280);
  }
  document.body.style.overflow = '';
}

if (hamburgerBtn) {
  hamburgerBtn.addEventListener('click', function() {
    sidebar && sidebar.classList.contains('open') ? closeSidebar() : openSidebar();
  });
}
if (sidebarOverlay) sidebarOverlay.addEventListener('click', closeSidebar);

/* ── TOAST ────────────────────────────────────────────────── */
function showToast(msg) {
  var t = document.getElementById('app-toast');
  if (!t) {
    t = document.createElement('div');
    t.id = 'app-toast';
    Object.assign(t.style, {
      position:'fixed', bottom:'24px', right:'28px',
      background:'#172D3D', color:'#fff', padding:'10px 18px',
      borderRadius:'8px', fontSize:'12.5px', fontWeight:'500',
      boxShadow:'0 4px 14px rgba(0,0,0,0.18)', zIndex:'9999',
      opacity:'0', transform:'translateY(8px)',
      transition:'opacity 0.2s, transform 0.2s',
      pointerEvents:'none', maxWidth:'280px'
    });
    document.body.appendChild(t);
  }
  clearTimeout(t._timer);
  t.textContent = msg;
  t.style.opacity = '1'; t.style.transform = 'translateY(0)';
  t._timer = setTimeout(function() {
    t.style.opacity = '0'; t.style.transform = 'translateY(8px)';
  }, 2500);
}

/* ── INIT ─────────────────────────────────────────────────── */
document.addEventListener('DOMContentLoaded', function() {
  renderStats();
  renderCategories();
  if (notifBadge) notifBadge.style.display = 'block';
});